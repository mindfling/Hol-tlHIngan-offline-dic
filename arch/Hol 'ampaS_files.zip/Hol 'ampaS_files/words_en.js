var wordList = [
   {
      id: 0,
      word: "'I'",
      name: "'I' (n.) armpit"
   }, 
   {
      id: 1,
      word: "'I' ghew",
      name: "'I' ghew (n.) beetlelike bug"
   }, 
   {
      id: 2,
      word: "'I'SeghIm",
      name: "'I'SeghIm (n.) curmudgeon"
   }, 
   {
      id: 3,
      word: "'I'ran",
      name: "'I'ran (n.) Iran"
   }, 
   {
      id: 4,
      word: "'IDnar",
      name: "'IDnar (n.) magic, wizardry"
   }, 
   {
      id: 5,
      word: "'IDnar lIl",
      name: "'IDnar lIl (v.) perform magic (referring to a stage magician)"
   }, 
   {
      id: 6,
      word: "'IDnar lIlwI'",
      name: "'IDnar lIlwI' (n.) stage magician"
   }, 
   {
      id: 7,
      word: "'IDnar pIn'a'",
      name: "'IDnar pIn'a' (n.) wizard, sorcerer"
   }, 
   {
      id: 8,
      word: "'IH",
      name: "'IH (v.) be beautiful, be handsome"
   }, 
   {
      id: 9,
      word: "'IQ",
      name: "'IQ (v.) be sad"
   }, 
   {
      id: 10,
      word: "'IQDoy'",
      name: "'IQDoy' (n.) parody, caricature"
   }, 
   {
      id: 11,
      word: "'ISQIm",
      name: "'ISQIm (n.) harmony"
   }, 
   {
      id: 12,
      word: "'ISjaH",
      name: "'ISjaH (n.) calendar"
   }, 
   {
      id: 13,
      word: "'ISla'am lalDan",
      name: "'ISla'am lalDan (n.) Islam"
   }, 
   {
      id: 14,
      word: "'ISlan",
      name: "'ISlan (n.) Iceland"
   }, 
   {
      id: 15,
      word: "'IStanbul",
      name: "'IStanbul (n.) Istanbul"
   }, 
   {
      id: 16,
      word: "'IStegh",
      name: "'IStegh (n.) instruction, order"
   }, 
   {
      id: 17,
      word: "'ISyar",
      name: "'ISyar (n.) legacy"
   }, 
   {
      id: 18,
      word: "'Ib",
      name: "'Ib (n.) tub"
   }, 
   {
      id: 19,
      word: "'Ich",
      name: "'Ich (v.) be slippery"
   }, 
   {
      id: 20,
      word: "'Igh",
      name: "'Igh (v.) be cursed (slang), be jinxed (slang)"
   }, 
   {
      id: 21,
      word: "'Igh'aDmegh",
      name: "'Igh'aDmegh (n.) antibody"
   }, 
   {
      id: 22,
      word: "'Ighbo Hol",
      name: "'Ighbo Hol (n.) Igbo"
   }, 
   {
      id: 23,
      word: "'IghvaH",
      name: "'IghvaH (n.) igvah, type of animal"
   }, 
   {
      id: 24,
      word: "'Ij",
      name: "'Ij (v.) listen"
   }, 
   {
      id: 25,
      word: "'Il",
      name: "'Il (v.) be sincere"
   }, 
   {
      id: 26,
      word: "'IlHa'",
      name: "'IlHa' (v.) be insincere"
   }, 
   {
      id: 27,
      word: "'Ilyaw'",
      name: "'Ilyaw' (n.) epitome"
   }, 
   {
      id: 28,
      word: "'Im",
      name: "'Im (v.) render, boil fat"
   }, 
   {
      id: 29,
      word: "'ImSIng",
      name: "'ImSIng (n.) sewer"
   }, 
   {
      id: 30,
      word: "'Impey'",
      name: "'Impey' (n.) pyramid"
   }, 
   {
      id: 31,
      word: "'ImtIy",
      name: "'ImtIy (n.) camel-like animal without a hump"
   }, 
   {
      id: 32,
      word: "'Imyagh",
      name: "'Imyagh (exclamation) sound made by a vIghro' or ghISnar"
   }, 
   {
      id: 33,
      word: "'In",
      name: "'In (n.) percussion instrument (drum, bell)"
   }, 
   {
      id: 34,
      word: "'InDIye'na'",
      name: "'InDIye'na' (n.) Indiana"
   }, 
   {
      id: 35,
      word: "'InDIyene'palIS",
      name: "'InDIyene'palIS (p.n.) Indianapolis"
   }, 
   {
      id: 36,
      word: "'InDogh",
      name: "'InDogh (n.) syllable"
   }, 
   {
      id: 37,
      word: "'InDogh ngutlh qol",
      name: "'InDogh ngutlh qol (n.) syllabary"
   }, 
   {
      id: 38,
      word: "'InDoneSya'",
      name: "'InDoneSya' (n.) Indonesia"
   }, 
   {
      id: 39,
      word: "'InSep",
      name: "'InSep (n.) penis"
   }, 
   {
      id: 40,
      word: "'InSong",
      name: "'InSong (n.) flower (bright part of plant)"
   }, 
   {
      id: 41,
      word: "'Ing",
      name: "'Ing (v.) move clockwise"
   }, 
   {
      id: 42,
      word: "'IngSav",
      name: "'IngSav (n.) melody"
   }, 
   {
      id: 43,
      word: "'Inglan",
      name: "'Inglan (n.) England"
   }, 
   {
      id: 44,
      word: "'InterlIngwa' Hol",
      name: "'InterlIngwa' Hol (n.) Interlingua"
   }, 
   {
      id: 45,
      word: "'Internet",
      name: "'Internet (n.) the internet"
   }, 
   {
      id: 46,
      word: "'InuwIt Hol",
      name: "'InuwIt Hol (n.) Inuit"
   }, 
   {
      id: 47,
      word: "'Inyam",
      name: "'Inyam (n.) ego, the self"
   }, 
   {
      id: 48,
      word: "'Ip",
      name: "'Ip (n.) oath"
   }, 
   {
      id: 49,
      word: "'Ip",
      name: "'Ip (v.) vow, swear"
   }, 
   {
      id: 50,
      word: "'Ipnal",
      name: "'Ipnal (n.) spouse (gender-neutral term)"
   }, 
   {
      id: 51,
      word: "'Iptay",
      name: "'Iptay (n.) honorific epetai"
   }, 
   {
      id: 52,
      word: "'Iq",
      name: "'Iq (v.) be too much, be too many"
   }, 
   {
      id: 53,
      word: "'IqnaH",
      name: "'IqnaH (n.) mucus"
   }, 
   {
      id: 54,
      word: "'IqnaH QaD",
      name: "'IqnaH QaD (n.) dry mucus, booger"
   }, 
   {
      id: 55,
      word: "'IqngIl",
      name: "'IqngIl (n.) coil, spring"
   }, 
   {
      id: 56,
      word: "'Ir",
      name: "'Ir (v.) be creamy, pasty"
   }, 
   {
      id: 57,
      word: "'Ir",
      name: "'Ir (v.) guess, suppose, imagine"
   }, 
   {
      id: 58,
      word: "'Irgh",
      name: "'Irgh (v.) bully, intimidate, pick on, harass"
   }, 
   {
      id: 59,
      word: "'IrmeD",
      name: "'IrmeD (n.) eddy"
   }, 
   {
      id: 60,
      word: "'IrneH",
      name: "'IrneH (n.) uncle, mother's brother"
   }, 
   {
      id: 61,
      word: "'IrneHnal",
      name: "'IrneHnal (n.) uncle, mother's sister's husband"
   }, 
   {
      id: 62,
      word: "'It",
      name: "'It (v.) be depressed"
   }, 
   {
      id: 63,
      word: "'Italya'",
      name: "'Italya' (p.n.) Italy"
   }, 
   {
      id: 64,
      word: "'Itlh",
      name: "'Itlh (v.) be advanced, be highly developed"
   }, 
   {
      id: 65,
      word: "'Ityop'Iya",
      name: "'Ityop'Iya (n.) Ethiopia"
   }, 
   {
      id: 66,
      word: "'Iv",
      name: "'Iv (n.) altitude"
   }, 
   {
      id: 67,
      word: "'Iv",
      name: "'Iv (question) who?"
   }, 
   {
      id: 68,
      word: "'IventoH",
      name: "'IventoH (n.) pineapple-like fruit"
   }, 
   {
      id: 69,
      word: "'IvtIH",
      name: "'IvtIH (n.) hip"
   }, 
   {
      id: 70,
      word: "'Iw",
      name: "'Iw (n.) blood"
   }, 
   {
      id: 71,
      word: "'Iw 'Ip ghomey",
      name: "'Iw 'Ip ghomey (p.n.) blood oath circles - the name of a well known sculpture by mIStaq"
   }, 
   {
      id: 72,
      word: "'Iw HIq",
      name: "'Iw HIq (n.) bloodwine"
   }, 
   {
      id: 73,
      word: "'Iw remwI'",
      name: "'Iw remwI' (n.) vampire"
   }, 
   {
      id: 74,
      word: "'Iwghargh",
      name: "'Iwghargh (n.) bloodworm, type of animal"
   }, 
   {
      id: 75,
      word: "'IyDo Hol",
      name: "'IyDo Hol (n.) Ido"
   }, 
   {
      id: 76,
      word: "'a",
      name: "'a (conjunction) but, nevertheless, even so, however"
   }, 
   {
      id: 77,
      word: "'a'",
      name: "'a' (ns1) augmentative"
   }, 
   {
      id: 78,
      word: "'a'",
      name: "'a' (vs9) interrogative"
   }, 
   {
      id: 79,
      word: "'a'baqa'",
      name: "'a'baqa' (n.) dossier, portfolio, file"
   }, 
   {
      id: 80,
      word: "'a'ghen",
      name: "'a'ghen (n.) master teacher, professor"
   }, 
   {
      id: 81,
      word: "'a'leghen'I'",
      name: "'a'leghen'I' (n.) Allegheny (River, Mountains; US)"
   }, 
   {
      id: 82,
      word: "'a'ren",
      name: "'a'ren (n.) present, present time"
   }, 
   {
      id: 83,
      word: "'aD",
      name: "'aD (v.) have a length of, measure"
   }, 
   {
      id: 84,
      word: "'aD",
      name: "'aD (n.) vein, artery, blood vessel"
   }, 
   {
      id: 85,
      word: "'aDHom",
      name: "'aDHom (n.) capillary"
   }, 
   {
      id: 86,
      word: "'aDanjI'",
      name: "'aDanjI' (n.) Adanji, a type of Klingon incense used only in the Mauk-to'Vor ritual"
   }, 
   {
      id: 87,
      word: "'aH",
      name: "'aH (n.) paraphernalia"
   }, 
   {
      id: 88,
      word: "'aHDuH",
      name: "'aHDuH (n.) prototype"
   }, 
   {
      id: 89,
      word: "'aHra'",
      name: "'aHra' (n.) harness"
   }, 
   {
      id: 90,
      word: "'aQlo'",
      name: "'aQlo' (n.) forehead (regional)"
   }, 
   {
      id: 91,
      word: "'aQvoH",
      name: "'aQvoH (n.) act of watching over a fallen warrior's body"
   }, 
   {
      id: 92,
      word: "'aSralya'",
      name: "'aSralya' (n.) Australia"
   }, 
   {
      id: 93,
      word: "'aSteD",
      name: "'aSteD (n.) occupation, job"
   }, 
   {
      id: 94,
      word: "'aSya'",
      name: "'aSya' (n.) Asia"
   }, 
   {
      id: 95,
      word: "'ab",
      name: "'ab (v.) have a length/height of (object is length)"
   }, 
   {
      id: 96,
      word: "'ach",
      name: "'ach (conjunction) but, nevertheless, even so, however, whereas"
   }, 
   {
      id: 97,
      word: "'achghej",
      name: "'achghej (n.) void"
   }, 
   {
      id: 98,
      word: "'achler",
      name: "'achler (n.) nape, scruff, back of neck"
   }, 
   {
      id: 99,
      word: "'achme'",
      name: "'achme' (n.) anvil"
   }, 
   {
      id: 100,
      word: "'agh",
      name: "'agh (v.) show, demonstrate, display"
   }, 
   {
      id: 101,
      word: "'aghnIDnem",
      name: "'aghnIDnem (n.) fuse"
   }, 
   {
      id: 102,
      word: "'aj",
      name: "'aj (n.) admiral"
   }, 
   {
      id: 103,
      word: "'al",
      name: "'al (v.) float (in/on air)"
   }, 
   {
      id: 104,
      word: "'al'Imarat",
      name: "'al'Imarat (n.) United Arab Emirates"
   }, 
   {
      id: 105,
      word: "'al'arabyatSawDI'ya",
      name: "'al'arabyatSawDI'ya (n.) Saudi Arabia"
   }, 
   {
      id: 106,
      word: "'al'ay'raq",
      name: "'al'ay'raq (n.) Iraq"
   }, 
   {
      id: 107,
      word: "'al'on",
      name: "'al'on (n.) glass (material)"
   }, 
   {
      id: 108,
      word: "'al'uqSur",
      name: "'al'uqSur (n.) Luxor"
   }, 
   {
      id: 109,
      word: "'al'urDun",
      name: "'al'urDun (n.) Jordan"
   }, 
   {
      id: 110,
      word: "'alghuQ",
      name: "'alghuQ (n.) bastard, illegitimate"
   }, 
   {
      id: 111,
      word: "'aljayIr",
      name: "'aljayIr (n.) Algeria"
   }, 
   {
      id: 112,
      word: "'alnIl",
      name: "'alnIl (n.) belt buckle"
   }, 
   {
      id: 113,
      word: "'alngegh",
      name: "'alngegh (n.) axe with spike at end"
   }, 
   {
      id: 114,
      word: "'alnum",
      name: "'alnum (n.) freckle(s)"
   }, 
   {
      id: 115,
      word: "'altlhIq",
      name: "'altlhIq (n.) exclamation"
   }, 
   {
      id: 116,
      word: "'alwI'",
      name: "'alwI' (n.) floater"
   }, 
   {
      id: 117,
      word: "'alya'man",
      name: "'alya'man (n.) Yemen"
   }, 
   {
      id: 118,
      word: "'ambay",
      name: "'ambay (n.) island"
   }, 
   {
      id: 119,
      word: "'amerI'qa' SepjIjQa'",
      name: "'amerI'qa' SepjIjQa' (n.) United States of America"
   }, 
   {
      id: 120,
      word: "'amerI'qa' vutbal",
      name: "'amerI'qa' vutbal (n.) American football"
   }, 
   {
      id: 121,
      word: "'ampaS",
      name: "'ampaS (n.) academy, specialized school"
   }, 
   {
      id: 122,
      word: "'amrI'",
      name: "'amrI' (n.) balcony"
   }, 
   {
      id: 123,
      word: "'amuS",
      name: "'amuS (n.) garishness, gaudiness, ostentatiousness"
   }, 
   {
      id: 124,
      word: "'an",
      name: "'an (v.) be a waste"
   }, 
   {
      id: 125,
      word: "'an",
      name: "'an (v.) be petrified"
   }, 
   {
      id: 126,
      word: "'an'or",
      name: "'an'or (n.) fossil"
   }, 
   {
      id: 127,
      word: "'an'orQeD",
      name: "'an'orQeD (n.) paleontology"
   }, 
   {
      id: 128,
      word: "'an'ortej",
      name: "'an'ortej (n.) paleontologist"
   }, 
   {
      id: 129,
      word: "'anDo'ra'",
      name: "'anDo'ra' (n.) Andorra"
   }, 
   {
      id: 130,
      word: "'anDorya'ngan",
      name: "'anDorya'ngan (n.) Andorian"
   }, 
   {
      id: 131,
      word: "'anISyum",
      name: "'anISyum (n.) anicium (explosive)"
   }, 
   {
      id: 132,
      word: "'anSa'ra",
      name: "'anSa'ra (p.n.) Ansara"
   }, 
   {
      id: 133,
      word: "'ang",
      name: "'ang (v.) show, reveal"
   }, 
   {
      id: 134,
      word: "'angghal",
      name: "'angghal (p.n.) Dr. Lawrence M. Schoen"
   }, 
   {
      id: 135,
      word: "'anggho'la",
      name: "'anggho'la (n.) Angola"
   }, 
   {
      id: 136,
      word: "'angwIl",
      name: "'angwIl (n.) Kos'Karii (single)"
   }, 
   {
      id: 137,
      word: "'angweD",
      name: "'angweD (n.) museum"
   }, 
   {
      id: 138,
      word: "'anmoH",
      name: "'anmoH (v.) sacrifice"
   }, 
   {
      id: 139,
      word: "'antartIq",
      name: "'antartIq (n.) Antarctica"
   }, 
   {
      id: 140,
      word: "'anyan 'oQqar",
      name: "'anyan 'oQqar (n.) onion"
   }, 
   {
      id: 141,
      word: "'ap",
      name: "'ap (v.) be dented"
   }, 
   {
      id: 142,
      word: "'ap",
      name: "'ap (n.) dues, toll"
   }, 
   {
      id: 143,
      word: "'aplo'",
      name: "'aplo' (n.) container, box"
   }, 
   {
      id: 144,
      word: "'aplom",
      name: "'aplom (n.) pellet"
   }, 
   {
      id: 145,
      word: "'apmoH",
      name: "'apmoH (v.) dent"
   }, 
   {
      id: 146,
      word: "'apraQ",
      name: "'apraQ (n.) calcium"
   }, 
   {
      id: 147,
      word: "'apuStoQ",
      name: "'apuStoQ (n.) hawk-like bird that flies particularly fast"
   }, 
   {
      id: 148,
      word: "'aq",
      name: "'aq (v.) predict, prognosticate"
   }, 
   {
      id: 149,
      word: "'aqSIl",
      name: "'aqSIl (n.) torque"
   }, 
   {
      id: 150,
      word: "'aqleH",
      name: "'aqleH (n.) type of weapon (half ax, half bat'leth)"
   }, 
   {
      id: 151,
      word: "'aqnaw",
      name: "'aqnaw (n.) all-purpose knife that seems to cut through anything"
   }, 
   {
      id: 152,
      word: "'aqroS",
      name: "'aqroS (n.) maximum, ceiling, bottom surface (underside) of a table"
   }, 
   {
      id: 153,
      word: "'aqroS patlh",
      name: "'aqroS patlh (n.) record, maximum rank"
   }, 
   {
      id: 154,
      word: "'aqtu'",
      name: "'aqtu' (p.n.) Aktuh - proper name from Klingon opera"
   }, 
   {
      id: 155,
      word: "'aquta'",
      name: "'aquta' (n.) gourd, squash, pumpkin"
   }, 
   {
      id: 156,
      word: "'ar",
      name: "'ar (question) how many? how much?"
   }, 
   {
      id: 157,
      word: "'arDeH",
      name: "'arDeH (n.) ivy-like plant"
   }, 
   {
      id: 158,
      word: "'arHentInya'",
      name: "'arHentInya' (n.) Argentina"
   }, 
   {
      id: 159,
      word: "'argh",
      name: "'argh (v.) worsen"
   }, 
   {
      id: 160,
      word: "'arlogh",
      name: "'arlogh (question) how many times?"
   }, 
   {
      id: 161,
      word: "'at",
      name: "'at (v.) inherit"
   }, 
   {
      id: 162,
      word: "'atlhetbur",
      name: "'atlhetbur (p.n.) Azetbur"
   }, 
   {
      id: 163,
      word: "'atlhqam",
      name: "'atlhqam (n.) type of fungus"
   }, 
   {
      id: 164,
      word: "'atlhqam tun",
      name: "'atlhqam tun (n.) a type of mold"
   }, 
   {
      id: 165,
      word: "'atray",
      name: "'atray (n.) siege"
   }, 
   {
      id: 166,
      word: "'atrom",
      name: "'atrom (p.n.) A'trom"
   }, 
   {
      id: 167,
      word: "'av",
      name: "'av (v.) guard"
   }, 
   {
      id: 168,
      word: "'avghanIStan",
      name: "'avghanIStan (n.) Afghanistan"
   }, 
   {
      id: 169,
      word: "'avrI'qa'",
      name: "'avrI'qa' (n.) Africa"
   }, 
   {
      id: 170,
      word: "'avrIHI'lI' Hol",
      name: "'avrIHI'lI' Hol (n.) Afrihili"
   }, 
   {
      id: 171,
      word: "'avrIqaS Hol",
      name: "'avrIqaS Hol (n.) Afrikaans"
   }, 
   {
      id: 172,
      word: "'avwI'",
      name: "'avwI' (n.) guard"
   }, 
   {
      id: 173,
      word: "'aw",
      name: "'aw (v.) go through, pass through (matter)"
   }, 
   {
      id: 174,
      word: "'aw'",
      name: "'aw' (v.) sting"
   }, 
   {
      id: 175,
      word: "'awje'",
      name: "'awje' (n.) type of beverage (root beer)"
   }, 
   {
      id: 176,
      word: "'awtIr",
      name: "'awtIr (n.) musical note, musical tone"
   }, 
   {
      id: 177,
      word: "'ay",
      name: "'ay (v.) float"
   }, 
   {
      id: 178,
      word: "'ay'",
      name: "'ay' (n.) section, part, component, piece, element"
   }, 
   {
      id: 179,
      word: "'ayItI",
      name: "'ayItI (n.) Haiti"
   }, 
   {
      id: 180,
      word: "'ayIvlaS",
      name: "'ayIvlaS (n.) moss"
   }, 
   {
      id: 181,
      word: "'e'",
      name: "'e' (pronoun) that (previous topic)"
   }, 
   {
      id: 182,
      word: "'e'",
      name: "'e' (ns5) topic"
   }, 
   {
      id: 183,
      word: "'e'",
      name: "'e' (vs5) topic (noun suffix on verb acting as adjective)"
   }, 
   {
      id: 184,
      word: "'e'levan",
      name: "'e'levan (n.) elephant"
   }, 
   {
      id: 185,
      word: "'e'mam",
      name: "'e'mam (n.) aunt, father's sister"
   }, 
   {
      id: 186,
      word: "'e'mamnal",
      name: "'e'mamnal (n.) aunt, father's brother's wife"
   }, 
   {
      id: 187,
      word: "'e'nal",
      name: "'e'nal (n.) someone who married into the family"
   }, 
   {
      id: 188,
      word: "'e'qIn",
      name: "'e'qIn (n.) rustling sound"
   }, 
   {
      id: 189,
      word: "'eD",
      name: "'eD (v.) crawl"
   }, 
   {
      id: 190,
      word: "'eDSeHcha",
      name: "'eDSeHcha (n.) Take-Off/Landing Thrusters (plural word)"
   }, 
   {
      id: 191,
      word: "'eDjen",
      name: "'eDjen (n.) an arrogant or haughty person"
   }, 
   {
      id: 192,
      word: "'eH",
      name: "'eH (exclamation) ready"
   }, 
   {
      id: 193,
      word: "'eQ",
      name: "'eQ (adverb) just now, a moment ago"
   }, 
   {
      id: 194,
      word: "'eQway",
      name: "'eQway (n.) belly button"
   }, 
   {
      id: 195,
      word: "'eQway'",
      name: "'eQway' (n.) mouse (computer)"
   }, 
   {
      id: 196,
      word: "'eQway' 'echlet",
      name: "'eQway' 'echlet (n.) mouse pad"
   }, 
   {
      id: 197,
      word: "'eS",
      name: "'eS (v.) be low"
   }, 
   {
      id: 198,
      word: "'eSpanya'",
      name: "'eSpanya' (n.) Spain"
   }, 
   {
      id: 199,
      word: "'eSpeD",
      name: "'eSpeD (n.) spade (suit)"
   }, 
   {
      id: 200,
      word: "'eSperanto Hol",
      name: "'eSperanto Hol (n.) Esperanto"
   }, 
   {
      id: 201,
      word: "'eSqIl",
      name: "'eSqIl (p.n.) Eskil Heyn Olsen"
   }, 
   {
      id: 202,
      word: "'eSqa'",
      name: "'eSqa' (n.) religious garb, the robe worn by a judge"
   }, 
   {
      id: 203,
      word: "'eSqenDerIyya'",
      name: "'eSqenDerIyya' (n.) Alexandria"
   }, 
   {
      id: 204,
      word: "'eSreH",
      name: "'eSreH (n.) dew"
   }, 
   {
      id: 205,
      word: "'eStIy",
      name: "'eStIy (n.) Estonia"
   }, 
   {
      id: 206,
      word: "'eSwat'I'nI",
      name: "'eSwat'I'nI (n.) Swaziland"
   }, 
   {
      id: 207,
      word: "'eb",
      name: "'eb (n.) opportunity, chance, opening"
   }, 
   {
      id: 208,
      word: "'ebHIv",
      name: "'ebHIv (n.) apparatus used to distill various concoctions into an acceptable form of"
   }, 
   {
      id: 209,
      word: "'ebHIv pa'",
      name: "'ebHIv pa' (n.) distillery"
   }, 
   {
      id: 210,
      word: "'ebHIv qach",
      name: "'ebHIv qach (n.) distillery"
   }, 
   {
      id: 211,
      word: "'ebraH",
      name: "'ebraH (n.) climax (sexual)"
   }, 
   {
      id: 212,
      word: "'ech",
      name: "'ech (n.) brigadier"
   }, 
   {
      id: 213,
      word: "'echlet",
      name: "'echlet (n.) board"
   }, 
   {
      id: 214,
      word: "'echletHom",
      name: "'echletHom (n.) card"
   }, 
   {
      id: 215,
      word: "'echletHom vey",
      name: "'echletHom vey (n.) deck of cards"
   }, 
   {
      id: 216,
      word: "'egh",
      name: "'egh (vs1) oneself"
   }, 
   {
      id: 217,
      word: "'egh",
      name: "'egh (n.) third tone of nonatonic musical scale"
   }, 
   {
      id: 218,
      word: "'ej",
      name: "'ej (conjunction) and (joining sentences)"
   }, 
   {
      id: 219,
      word: "'ej De' vIchel",
      name: "'ej De' vIchel (adverb) by the way, parenthetically"
   }, 
   {
      id: 220,
      word: "'ejDo'",
      name: "'ejDo' (n.) starship, starship class"
   }, 
   {
      id: 221,
      word: "'ejtlhal",
      name: "'ejtlhal (n.) tumor"
   }, 
   {
      id: 222,
      word: "'ejvoH",
      name: "'ejvoH (n.) stripe"
   }, 
   {
      id: 223,
      word: "'ejyaH",
      name: "'ejyaH (number) infinity"
   }, 
   {
      id: 224,
      word: "'ejyo'",
      name: "'ejyo' (n.) Starfleet"
   }, 
   {
      id: 225,
      word: "'ejyo' ra'ghomquv",
      name: "'ejyo' ra'ghomquv (n.) Starfleet Command"
   }, 
   {
      id: 226,
      word: "'ejyo'SeH yaHnIv",
      name: "'ejyo'SeH yaHnIv (n.) Starfleet Command"
   }, 
   {
      id: 227,
      word: "'ejyo'waw'",
      name: "'ejyo'waw' (n.) star base"
   }, 
   {
      id: 228,
      word: "'el",
      name: "'el (v.) enter, go in"
   }, 
   {
      id: 229,
      word: "'elI'jaH",
      name: "'elI'jaH (n.) Unexpected visitor, uninvited guest"
   }, 
   {
      id: 230,
      word: "'elaDya'",
      name: "'elaDya' (n.) Greece"
   }, 
   {
      id: 231,
      word: "'elaS",
      name: "'elaS (n.) Elas"
   }, 
   {
      id: 232,
      word: "'elbaHren",
      name: "'elbaHren (n.) Bahrain"
   }, 
   {
      id: 233,
      word: "'elmaQ",
      name: "'elmaQ (n.) serotonin"
   }, 
   {
      id: 234,
      word: "'elmeH chaw'",
      name: "'elmeH chaw' (n.) ticket, pass"
   }, 
   {
      id: 235,
      word: "'elpI'",
      name: "'elpI' (n.) serving platter"
   }, 
   {
      id: 236,
      word: "'elquwet",
      name: "'elquwet (n.) Kuwait"
   }, 
   {
      id: 237,
      word: "'em",
      name: "'em (n.) behind, area behind"
   }, 
   {
      id: 238,
      word: "'em",
      name: "'em (v.) vomit"
   }, 
   {
      id: 239,
      word: "'emrIgh",
      name: "'emrIgh (n.) ancestor (direct)"
   }, 
   {
      id: 240,
      word: "'emvI'",
      name: "'emvI' (n.) pin (straight)"
   }, 
   {
      id: 241,
      word: "'en",
      name: "'en (v.) be not something, non-"
   }, 
   {
      id: 242,
      word: "'enDeq",
      name: "'enDeq (n.) bladder"
   }, 
   {
      id: 243,
      word: "'eng",
      name: "'eng (n.) cloud"
   }, 
   {
      id: 244,
      word: "'engDay",
      name: "'engDay (n.) flap"
   }, 
   {
      id: 245,
      word: "'enno",
      name: "'enno (n.) lens"
   }, 
   {
      id: 246,
      word: "'enteD",
      name: "'enteD (n.) drug"
   }, 
   {
      id: 247,
      word: "'entepray'",
      name: "'entepray' (p.n.) Enterprise (name of ship)"
   }, 
   {
      id: 248,
      word: "'ep",
      name: "'ep (v.) consume soup, Human-style kiss (slang)"
   }, 
   {
      id: 249,
      word: "'epIl naH",
      name: "'epIl naH (n.) apple"
   }, 
   {
      id: 250,
      word: "'epIl naHmey",
      name: "'epIl naHmey (n.) apples"
   }, 
   {
      id: 251,
      word: "'epIn",
      name: "'epIn (n.) peach"
   }, 
   {
      id: 252,
      word: "'eq",
      name: "'eq (v.) be early"
   }, 
   {
      id: 253,
      word: "'eqwaDor",
      name: "'eqwaDor (n.) Ecuador"
   }, 
   {
      id: 254,
      word: "'er",
      name: "'er (n.) air, type of animal"
   }, 
   {
      id: 255,
      word: "'er'In",
      name: "'er'In (n.) end (of stick, rope, etc.), other end from {megh'an}"
   }, 
   {
      id: 256,
      word: "'erItraya'",
      name: "'erItraya' (n.) Eritrea"
   }, 
   {
      id: 257,
      word: "'ergh",
      name: "'ergh (v.) hallucinate"
   }, 
   {
      id: 258,
      word: "'erwI'Daq",
      name: "'erwI'Daq (n.) telepathy"
   }, 
   {
      id: 259,
      word: "'et",
      name: "'et (v.) bounce, rebound, ricochet"
   }, 
   {
      id: 260,
      word: "'et",
      name: "'et (n.) fore"
   }, 
   {
      id: 261,
      word: "'etlh",
      name: "'etlh (n.) sword, blade"
   }, 
   {
      id: 262,
      word: "'etlh waq",
      name: "'etlh waq (n.) ice skate"
   }, 
   {
      id: 263,
      word: "'etlhqengwI'",
      name: "'etlhqengwI' (p.n.) Garrett Michael Hayes"
   }, 
   {
      id: 264,
      word: "'etwI' tlhIm",
      name: "'etwI' tlhIm (n.) trampoline"
   }, 
   {
      id: 265,
      word: "'ev",
      name: "'ev (v.) applaud"
   }, 
   {
      id: 266,
      word: "'ev",
      name: "'ev (n.) northwestward, area to the northwest (320 degrees on terran 360 degree compass counted clockwise wit"
   }, 
   {
      id: 267,
      word: "'evnagh",
      name: "'evnagh (n.) subspace"
   }, 
   {
      id: 268,
      word: "'evta'",
      name: "'evta' (n.) evta, newt, salamander, type of animal"
   }, 
   {
      id: 269,
      word: "'evtlhev",
      name: "'evtlhev (n.) base (chemical)"
   }, 
   {
      id: 270,
      word: "'ewSIqaDIy",
      name: "'ewSIqaDIy (p.n.) Basque Country"
   }, 
   {
      id: 271,
      word: "'ewro",
      name: "'ewro (n.) Euro"
   }, 
   {
      id: 272,
      word: "'ewrop",
      name: "'ewrop (p.n.) Europe"
   }, 
   {
      id: 273,
      word: "'ey",
      name: "'ey (v.) be good, be delicious, be tasty, be harmonious"
   }, 
   {
      id: 274,
      word: "'eyawaDIy",
      name: "'eyawaDIy (p.n.) Irrawaddy (River in Burma/Myanmar)"
   }, 
   {
      id: 275,
      word: "'eyre'",
      name: "'eyre' (n.) Ireland"
   }, 
   {
      id: 276,
      word: "'o",
      name: "'o (exclamation) O"
   }, 
   {
      id: 277,
      word: "'o'",
      name: "'o' (n.) aft"
   }, 
   {
      id: 278,
      word: "'o'lav",
      name: "'o'lav (n.) type of drum"
   }, 
   {
      id: 279,
      word: "'o'lav'a'",
      name: "'o'lav'a' (n.) bass drum"
   }, 
   {
      id: 280,
      word: "'o'mat ghIrI'",
      name: "'o'mat ghIrI' (n.) a meat and pasta-like concoction"
   }, 
   {
      id: 281,
      word: "'o'megh",
      name: "'o'megh (n.) end (of a song)"
   }, 
   {
      id: 282,
      word: "'o'nI'",
      name: "'o'nI' (n.) foam, froth"
   }, 
   {
      id: 283,
      word: "'o'nI' 'atlhqam",
      name: "'o'nI' 'atlhqam (n.) yeast"
   }, 
   {
      id: 284,
      word: "'o'nI' Sub",
      name: "'o'nI' Sub (n.) solid foam (like styrofoam)"
   }, 
   {
      id: 285,
      word: "'o'rIS",
      name: "'o'rIS (n.) molecule"
   }, 
   {
      id: 286,
      word: "'o'raylIy",
      name: "'o'raylIy (p.n.) O'Reilly"
   }, 
   {
      id: 287,
      word: "'o'roy'",
      name: "'o'roy' (n.) chalk"
   }, 
   {
      id: 288,
      word: "'o'wen",
      name: "'o'wen (n.) someone or something of ambiguous status"
   }, 
   {
      id: 289,
      word: "'oD",
      name: "'oD (v.) arbitrate, mediate"
   }, 
   {
      id: 290,
      word: "'oDtu'",
      name: "'oDtu' (n.) spot, splotch, blemish, blotch"
   }, 
   {
      id: 291,
      word: "'oDwI'",
      name: "'oDwI' (n.) arbitrator"
   }, 
   {
      id: 292,
      word: "'oH",
      name: "'oH (pronoun) it"
   }, 
   {
      id: 293,
      word: "'oQqar",
      name: "'oQqar (n.) root, tuber"
   }, 
   {
      id: 294,
      word: "'oS",
      name: "'oS (v.) represent"
   }, 
   {
      id: 295,
      word: "'oSHeQ",
      name: "'oSHeQ (n.) spleen"
   }, 
   {
      id: 296,
      word: "'oSIya'nIya",
      name: "'oSIya'nIya (n.) Oceania"
   }, 
   {
      id: 297,
      word: "'oSrIq",
      name: "'oSrIq (p.n.) Osric"
   }, 
   {
      id: 298,
      word: "'oStIn",
      name: "'oStIn (n.) Austin"
   }, 
   {
      id: 299,
      word: "'oSteray'",
      name: "'oSteray' (n.) Austria"
   }, 
   {
      id: 300,
      word: "'oSwI'",
      name: "'oSwI' (n.) emissary"
   }, 
   {
      id: 301,
      word: "'ob",
      name: "'ob (v.) be curved, arced"
   }, 
   {
      id: 302,
      word: "'obe'",
      name: "'obe' (n.) order, group officially recognized by government"
   }, 
   {
      id: 303,
      word: "'obmaQ",
      name: "'obmaQ (n.) ax, axe"
   }, 
   {
      id: 304,
      word: "'obray'wal",
      name: "'obray'wal (n.) scorpionlike bug"
   }, 
   {
      id: 305,
      word: "'och",
      name: "'och (n.) tunnel, conduit"
   }, 
   {
      id: 306,
      word: "'och mutlhwI'",
      name: "'och mutlhwI' (n.) plumber"
   }, 
   {
      id: 307,
      word: "'ogh",
      name: "'ogh (v.) invent, devise"
   }, 
   {
      id: 308,
      word: "'oj",
      name: "'oj (v.) be thirsty"
   }, 
   {
      id: 309,
      word: "'ol",
      name: "'ol (v.) verify, check if (something) is true, make sure that (something) is true"
   }, 
   {
      id: 310,
      word: "'olDop",
      name: "'olDop (n.) pedal"
   }, 
   {
      id: 311,
      word: "'olImpIya' qaD",
      name: "'olImpIya' qaD (n.) Olympics"
   }, 
   {
      id: 312,
      word: "'olQan",
      name: "'olQan (n.) gap"
   }, 
   {
      id: 313,
      word: "'om",
      name: "'om (v.) resist, fend off"
   }, 
   {
      id: 314,
      word: "'omwI'",
      name: "'omwI' (n.) resistor"
   }, 
   {
      id: 315,
      word: "'on'aS",
      name: "'on'aS (n.) health"
   }, 
   {
      id: 316,
      word: "'on'aSQeD",
      name: "'on'aSQeD (n.) medicine"
   }, 
   {
      id: 317,
      word: "'onDu'raS",
      name: "'onDu'raS (n.) Honduras"
   }, 
   {
      id: 318,
      word: "'ong",
      name: "'ong (v.) be cunning, be sly"
   }, 
   {
      id: 319,
      word: "'onroS",
      name: "'onroS (n.) drop"
   }, 
   {
      id: 320,
      word: "'onteryo",
      name: "'onteryo (n.) Ontario"
   }, 
   {
      id: 321,
      word: "'op",
      name: "'op (n.) some, an unknown or unspecified quantity"
   }, 
   {
      id: 322,
      word: "'opDIch",
      name: "'opDIch (number) n-th"
   }, 
   {
      id: 323,
      word: "'opleS",
      name: "'opleS (n.) one day"
   }, 
   {
      id: 324,
      word: "'oplogh",
      name: "'oplogh (number) several times"
   }, 
   {
      id: 325,
      word: "'opuHwI'",
      name: "'opuHwI' (n.) prostitute"
   }, 
   {
      id: 326,
      word: "'oq",
      name: "'oq (v.) be submerged, be under water, sink"
   }, 
   {
      id: 327,
      word: "'oqe'",
      name: "'oqe' (n.) coral"
   }, 
   {
      id: 328,
      word: "'oqmoH",
      name: "'oqmoH (v.) submerge"
   }, 
   {
      id: 329,
      word: "'or",
      name: "'or (v.) pilot, operate (an aircraft)"
   }, 
   {
      id: 330,
      word: "'or'eq",
      name: "'or'eq (p.n.) Or'eq"
   }, 
   {
      id: 331,
      word: "'orayngan",
      name: "'orayngan (n.) Orion"
   }, 
   {
      id: 332,
      word: "'orayya'ngan",
      name: "'orayya'ngan (n.) Orion"
   }, 
   {
      id: 333,
      word: "'orgh",
      name: "'orgh (v.) skitter"
   }, 
   {
      id: 334,
      word: "'orghen",
      name: "'orghen (n.) Organia"
   }, 
   {
      id: 335,
      word: "'orghen rojmab",
      name: "'orghen rojmab (n.) Organian Peace Treaty"
   }, 
   {
      id: 336,
      word: "'orghengan",
      name: "'orghengan (n.) Organian"
   }, 
   {
      id: 337,
      word: "'orghenya'",
      name: "'orghenya' (n.) Organia"
   }, 
   {
      id: 338,
      word: "'orghenya' rojmab",
      name: "'orghenya' rojmab (n.) Organian Peace Treaty"
   }, 
   {
      id: 339,
      word: "'orghenya'ngan",
      name: "'orghenya'ngan (n.) Organian"
   }, 
   {
      id: 340,
      word: "'orwI'",
      name: "'orwI' (n.) pilot, one who operates (an aircraft)"
   }, 
   {
      id: 341,
      word: "'ot",
      name: "'ot (v.) withhold (information)"
   }, 
   {
      id: 342,
      word: "'ot tIr",
      name: "'ot tIr (n.) oat"
   }, 
   {
      id: 343,
      word: "'otHa'",
      name: "'otHa' (v.) disclose, divulge"
   }, 
   {
      id: 344,
      word: "'otHel",
      name: "'otHel (n.) dock"
   }, 
   {
      id: 345,
      word: "'otlh",
      name: "'otlh (n.) photon"
   }, 
   {
      id: 346,
      word: "'otlh poH",
      name: "'otlh poH (n.) Planck time"
   }, 
   {
      id: 347,
      word: "'otlhQeD",
      name: "'otlhQeD (n.) quantum physics"
   }, 
   {
      id: 348,
      word: "'otlhtej",
      name: "'otlhtej (n.) quantum physicist"
   }, 
   {
      id: 349,
      word: "'ov",
      name: "'ov (v.) compete"
   }, 
   {
      id: 350,
      word: "'ovelya",
      name: "'ovelya (p.n.) Ophelia"
   }, 
   {
      id: 351,
      word: "'ovjeq'IS",
      name: "'ovjeq'IS (n.) professional"
   }, 
   {
      id: 352,
      word: "'ovmay",
      name: "'ovmay (n.) direct object"
   }, 
   {
      id: 353,
      word: "'oy'",
      name: "'oy' (v.) ache, hurt, be sore"
   }, 
   {
      id: 354,
      word: "'oy'",
      name: "'oy' (n.) ache, pain, sore"
   }, 
   {
      id: 355,
      word: "'oy'naQ",
      name: "'oy'naQ (n.) painstick, painstik"
   }, 
   {
      id: 356,
      word: "'oynot",
      name: "'oynot (n.) unspecified flesh (of an animal)"
   }, 
   {
      id: 357,
      word: "'u'",
      name: "'u' (n.) universe"
   }, 
   {
      id: 358,
      word: "'uD",
      name: "'uD (n.) laser"
   }, 
   {
      id: 359,
      word: "'uD Haqtaj",
      name: "'uD Haqtaj (n.) laser scalpel"
   }, 
   {
      id: 360,
      word: "'uH",
      name: "'uH (v.) have a hangover, be hung over"
   }, 
   {
      id: 361,
      word: "'uQ",
      name: "'uQ (n.) dinner"
   }, 
   {
      id: 362,
      word: "'uQ'a'",
      name: "'uQ'a' (n.) banquet, feast"
   }, 
   {
      id: 363,
      word: "'uS",
      name: "'uS (n.) leg"
   }, 
   {
      id: 364,
      word: "'uS tutren",
      name: "'uS tutren (n.) knee pit, hollow of the knee, popliteal fossa"
   }, 
   {
      id: 365,
      word: "'uSgheb",
      name: "'uSgheb (n.) a noisy bird known to make a ruckus at dawn, likened to a rooster"
   }, 
   {
      id: 366,
      word: "'uSqan",
      name: "'uSqan (n.) iron (element)"
   }, 
   {
      id: 367,
      word: "'uSu'",
      name: "'uSu' (n.) sauce for gladst"
   }, 
   {
      id: 368,
      word: "'ub",
      name: "'ub (v.) be lonely"
   }, 
   {
      id: 369,
      word: "'uch",
      name: "'uch (v.) hold, grasp"
   }, 
   {
      id: 370,
      word: "'uch",
      name: "'uch (v.) keep (in the combination of change)"
   }, 
   {
      id: 371,
      word: "'uch",
      name: "'uch (v.) lock on (a target)"
   }, 
   {
      id: 372,
      word: "'uchgha'",
      name: "'uchgha' (n.) RNA"
   }, 
   {
      id: 373,
      word: "'ugh",
      name: "'ugh (v.) be heavy"
   }, 
   {
      id: 374,
      word: "'ughanDa",
      name: "'ughanDa (n.) Uganda"
   }, 
   {
      id: 375,
      word: "'uj",
      name: "'uj (n.) uj, unit of linear measure (about 35 centimeters or 13.5 inches)"
   }, 
   {
      id: 376,
      word: "'uj'a'",
      name: "'uj'a' (n.) unit of measurement, 9 'uj"
   }, 
   {
      id: 377,
      word: "'ujIllI'",
      name: "'ujIllI' (p.n.) Ujilli"
   }, 
   {
      id: 378,
      word: "'ul",
      name: "'ul (n.) electricity"
   }, 
   {
      id: 379,
      word: "'ul 'aplo'mey",
      name: "'ul 'aplo'mey (n.) batteries"
   }, 
   {
      id: 380,
      word: "'ul Sech",
      name: "'ul Sech (n.) flashlight, electric torch"
   }, 
   {
      id: 381,
      word: "'ul gho",
      name: "'ul gho (n.) circuit"
   }, 
   {
      id: 382,
      word: "'ul ghom'oH",
      name: "'ul ghom'oH (n.) electrical outlet"
   }, 
   {
      id: 383,
      word: "'ul le'mIS",
      name: "'ul le'mIS (n.) insulator"
   }, 
   {
      id: 384,
      word: "'ul pat mutlhwI'",
      name: "'ul pat mutlhwI' (n.) electrician"
   }, 
   {
      id: 385,
      word: "'um",
      name: "'um (v.) be qualified"
   }, 
   {
      id: 386,
      word: "'uma'",
      name: "'uma' (n.) petal"
   }, 
   {
      id: 387,
      word: "'umber",
      name: "'umber (n.) ecosystem, environment"
   }, 
   {
      id: 388,
      word: "'umyotlh",
      name: "'umyotlh (n.) profit"
   }, 
   {
      id: 389,
      word: "'un",
      name: "'un (n.) pot (for food preparation, general term)"
   }, 
   {
      id: 390,
      word: "'un naQ",
      name: "'un naQ (n.) stirring stick, mixing stick"
   }, 
   {
      id: 391,
      word: "'un quD",
      name: "'un quD (n.) artificially produced qud"
   }, 
   {
      id: 392,
      word: "'ung",
      name: "'ung (v.) squat  (down)"
   }, 
   {
      id: 393,
      word: "'unqal",
      name: "'unqal (n.) kettle"
   }, 
   {
      id: 394,
      word: "'unwat",
      name: "'unwat (n.) basket"
   }, 
   {
      id: 395,
      word: "'unyan 'oQqar",
      name: "'unyan 'oQqar (n.) onion"
   }, 
   {
      id: 396,
      word: "'up",
      name: "'up (v.) be unsavory, be disgusting, be repugnant, be loathsome, be icky"
   }, 
   {
      id: 397,
      word: "'uppol",
      name: "'uppol (n.) stunt, feat"
   }, 
   {
      id: 398,
      word: "'uq",
      name: "'uq (v.) whistle"
   }, 
   {
      id: 399,
      word: "'uqrayI'na",
      name: "'uqrayI'na (n.) Ukraine"
   }, 
   {
      id: 400,
      word: "'ur",
      name: "'ur (v.) commit treason"
   }, 
   {
      id: 401,
      word: "'urgh",
      name: "'urgh (v.) jab, poke"
   }, 
   {
      id: 402,
      word: "'urgh neH",
      name: "'urgh neH (v.) tinker (slang)"
   }, 
   {
      id: 403,
      word: "'urghwI'",
      name: "'urghwI' (n.) poker"
   }, 
   {
      id: 404,
      word: "'urmang",
      name: "'urmang (n.) treason"
   }, 
   {
      id: 405,
      word: "'urughway'",
      name: "'urughway' (n.) Uruguay"
   }, 
   {
      id: 406,
      word: "'urwI'",
      name: "'urwI' (n.) traitor"
   }, 
   {
      id: 407,
      word: "'ut",
      name: "'ut (v.) be essential, be necessary"
   }, 
   {
      id: 408,
      word: "'ut'at",
      name: "'ut'at (n.) chest of drawers"
   }, 
   {
      id: 409,
      word: "'utlh",
      name: "'utlh (n.) officer"
   }, 
   {
      id: 410,
      word: "'uy",
      name: "'uy (v.) press down"
   }, 
   {
      id: 411,
      word: "'uy'",
      name: "'uy' (number) million"
   }, 
   {
      id: 412,
      word: "-",
      name: "- (exclamation) bye, bye-bye, good-bye, goodbye (Klingons do not say good-bye, they simply leave the conversation)"
   }, 
   {
      id: 413,
      word: "-",
      name: "- (exclamation) hello (Klingons do not say hello, they just start talking about the topic at hand))"
   }, 
   {
      id: 414,
      word: "0",
      name: "0 (vp) he/she/it/they, he/she/it/-he/she/it/they, they-they"
   }, 
   {
      id: 415,
      word: "Brussels sprouts",
      name: "Brussels sprouts (n.) tera' majajHom"
   }, 
   {
      id: 416,
      word: "DI",
      name: "DI (n.) litter, rubble, debris"
   }, 
   {
      id: 417,
      word: "DI",
      name: "DI (vp) we-them"
   }, 
   {
      id: 418,
      word: "DI'",
      name: "DI' (vs9) as soon as, when"
   }, 
   {
      id: 419,
      word: "DI'",
      name: "DI' (v.) edit, revise, correct, modify"
   }, 
   {
      id: 420,
      word: "DI'bI'war",
      name: "DI'bI'war (n.) semiconductor"
   }, 
   {
      id: 421,
      word: "DI'on",
      name: "DI'on (n.) characteristic, trait"
   }, 
   {
      id: 422,
      word: "DI'raq",
      name: "DI'raq (n.) dirak, sheep, type of animal"
   }, 
   {
      id: 423,
      word: "DI'ruj",
      name: "DI'ruj (n.) reality"
   }, 
   {
      id: 424,
      word: "DI'ruj QeD",
      name: "DI'ruj QeD (n.) metaphysics"
   }, 
   {
      id: 425,
      word: "DI'ruj velqa' nIqHom",
      name: "DI'ruj velqa' nIqHom (n.) virtual reality software"
   }, 
   {
      id: 426,
      word: "DID",
      name: "DID (v.) be sterotypical"
   }, 
   {
      id: 427,
      word: "DIS",
      name: "DIS (n.) cave"
   }, 
   {
      id: 428,
      word: "DIS",
      name: "DIS (v.) confess"
   }, 
   {
      id: 429,
      word: "DIS",
      name: "DIS (n.) year (Klingon)"
   }, 
   {
      id: 430,
      word: "DIS'oS",
      name: "DIS'oS (n.) fern"
   }, 
   {
      id: 431,
      word: "DISjaj",
      name: "DISjaj (n.) anniversary measured in years"
   }, 
   {
      id: 432,
      word: "DISqa'vI'rIy",
      name: "DISqa'vI'rIy (p.n.) Discovery (starship)"
   }, 
   {
      id: 433,
      word: "DIb",
      name: "DIb (n.) right, privilege"
   }, 
   {
      id: 434,
      word: "DIch",
      name: "DIch (n.) certainty"
   }, 
   {
      id: 435,
      word: "DIch",
      name: "DIch (number) ordinal number suffix"
   }, 
   {
      id: 436,
      word: "DIgh",
      name: "DIgh (v.) undertake, deal with, take care of"
   }, 
   {
      id: 437,
      word: "DIghna'",
      name: "DIghna' (n.) poppy-like plant"
   }, 
   {
      id: 438,
      word: "DIghna'",
      name: "DIghna' (n.) type of plant"
   }, 
   {
      id: 439,
      word: "DIj",
      name: "DIj (v.) slide sword blade along opponent's blade"
   }, 
   {
      id: 440,
      word: "DIj",
      name: "DIj (v.) use a pigment stick, paint with pigment stick"
   }, 
   {
      id: 441,
      word: "DIl",
      name: "DIl (v.) pay for"
   }, 
   {
      id: 442,
      word: "DIl'on",
      name: "DIl'on (n.) saltpeter"
   }, 
   {
      id: 443,
      word: "DIlyum",
      name: "DIlyum (n.) trillium"
   }, 
   {
      id: 444,
      word: "DIn",
      name: "DIn (n.) open entryway (to corridor, tunnel, conduit, Jeffries tube, branch of sewer, bag)"
   }, 
   {
      id: 445,
      word: "DIng",
      name: "DIng (v.) spin"
   }, 
   {
      id: 446,
      word: "DIngwI'",
      name: "DIngwI' (n.) turntable (slang)"
   }, 
   {
      id: 447,
      word: "DIp",
      name: "DIp (n.) noun"
   }, 
   {
      id: 448,
      word: "DIr",
      name: "DIr (n.) skin"
   }, 
   {
      id: 449,
      word: "DIr 'In",
      name: "DIr 'In (n.) drum (percussion instrument with a stretched animal skin)"
   }, 
   {
      id: 450,
      word: "DIr paH bID",
      name: "DIr paH bID (n.) kilt-like garment"
   }, 
   {
      id: 451,
      word: "DIr tutlh",
      name: "DIr tutlh (n.) tattoo"
   }, 
   {
      id: 452,
      word: "DIreS'en",
      name: "DIreS'en (n.) Dresden"
   }, 
   {
      id: 453,
      word: "DIron",
      name: "DIron (n.) bagpipes (instrument)"
   }, 
   {
      id: 454,
      word: "DItlh",
      name: "DItlh (v.) be unavenged"
   }, 
   {
      id: 455,
      word: "DItlhHa'",
      name: "DItlhHa' (v.) be avenged"
   }, 
   {
      id: 456,
      word: "DItlhon",
      name: "DItlhon (n.) ruby"
   }, 
   {
      id: 457,
      word: "DItroy'",
      name: "DItroy' (n.) Detroit"
   }, 
   {
      id: 458,
      word: "DIv",
      name: "DIv (v.) be guilty"
   }, 
   {
      id: 459,
      word: "DIvI'",
      name: "DIvI' (n.) federation, organization,"
   }, 
   {
      id: 460,
      word: "DIvI' vutbal",
      name: "DIvI' vutbal (n.) soccer, football"
   }, 
   {
      id: 461,
      word: "DIvI'may'Duj",
      name: "DIvI'may'Duj (n.) Federation battle cruiser"
   }, 
   {
      id: 462,
      word: "DIy",
      name: "DIy (v.) be stuck (like a door that won't open)"
   }, 
   {
      id: 463,
      word: "Da",
      name: "Da (v.) behave as"
   }, 
   {
      id: 464,
      word: "Da",
      name: "Da (vp) you-him/her/it/them"
   }, 
   {
      id: 465,
      word: "Da'",
      name: "Da' (n.) corporal (rank)"
   }, 
   {
      id: 466,
      word: "Da'ar",
      name: "Da'ar (n.) Dahar (master)"
   }, 
   {
      id: 467,
      word: "Da'lar",
      name: "Da'lar (n.) dollar"
   }, 
   {
      id: 468,
      word: "Da'nal",
      name: "Da'nal (n.) a bird characterized by erratic, unpredictable behavior"
   }, 
   {
      id: 469,
      word: "Da'vI'",
      name: "Da'vI' (n.) a bird characterized by erratic, unpredictable behavior"
   }, 
   {
      id: 470,
      word: "DaH",
      name: "DaH (adverb) now, currently"
   }, 
   {
      id: 471,
      word: "DaH",
      name: "DaH (n.) weapons array, bank (of weapons)"
   }, 
   {
      id: 472,
      word: "DaHjaj",
      name: "DaHjaj (n.) today"
   }, 
   {
      id: 473,
      word: "DaHjaj gheD",
      name: "DaHjaj gheD (n.) dish in a restaurant (catch of the day)"
   }, 
   {
      id: 474,
      word: "DaHram",
      name: "DaHram (n.) tonight"
   }, 
   {
      id: 475,
      word: "DaQ",
      name: "DaQ (n.) ponytail"
   }, 
   {
      id: 476,
      word: "DaQtIq",
      name: "DaQtIq (p.n.) Bart Barker"
   }, 
   {
      id: 477,
      word: "DaS",
      name: "DaS (n.) boot"
   }, 
   {
      id: 478,
      word: "DaS",
      name: "DaS (v.) pinch"
   }, 
   {
      id: 479,
      word: "DaSjaj",
      name: "DaSjaj (n.) Monday"
   }, 
   {
      id: 480,
      word: "DaSpu'",
      name: "DaSpu' (n.) boot spike"
   }, 
   {
      id: 481,
      word: "Dab",
      name: "Dab (v.) dwell in/at, reside in/at"
   }, 
   {
      id: 482,
      word: "DabaHa'maS",
      name: "DabaHa'maS (n.) Bahamas"
   }, 
   {
      id: 483,
      word: "DabqI'",
      name: "DabqI' (n.) mud, clay, putty"
   }, 
   {
      id: 484,
      word: "Dach",
      name: "Dach (v.) be absent, be not attentive (slang), be distracted (slang), be lacking focus (slang)"
   }, 
   {
      id: 485,
      word: "DaghambIya'",
      name: "DaghambIya' (n.) Gambia"
   }, 
   {
      id: 486,
      word: "Daghor tuq",
      name: "Daghor tuq (p.n.) House of D'Ghor"
   }, 
   {
      id: 487,
      word: "Daghtuj",
      name: "Daghtuj (n.) mixture of animal parts, animal parts mixed together"
   }, 
   {
      id: 488,
      word: "Daj",
      name: "Daj (v.) be interesting"
   }, 
   {
      id: 489,
      word: "Daj",
      name: "Daj (ns4) his/hers/its"
   }, 
   {
      id: 490,
      word: "Daj",
      name: "Daj (v.) test inconclusively"
   }, 
   {
      id: 491,
      word: "Dal",
      name: "Dal (v.) be boring"
   }, 
   {
      id: 492,
      word: "Dam",
      name: "Dam (v.) regard as, view as, consider (treat somebody like)"
   }, 
   {
      id: 493,
      word: "DamSayrotlh",
      name: "DamSayrotlh (n.) hippopotamus, hippo"
   }, 
   {
      id: 494,
      word: "Damu'",
      name: "Damu' (n.) crease"
   }, 
   {
      id: 495,
      word: "Dan",
      name: "Dan (v.) occupy (military term)"
   }, 
   {
      id: 496,
      word: "Dang",
      name: "Dang (v.) focus"
   }, 
   {
      id: 497,
      word: "DannI'",
      name: "DannI' (n.) headphones"
   }, 
   {
      id: 498,
      word: "Dap",
      name: "Dap (n.) nonsense"
   }, 
   {
      id: 499,
      word: "Dap bom",
      name: "Dap bom (n.) nonsense song"
   }, 
   {
      id: 500,
      word: "Daq",
      name: "Daq (v.) eavesdrop"
   }, 
   {
      id: 501,
      word: "Daq",
      name: "Daq (vs5) location (noun suffix on verb acting as adjective)"
   }, 
   {
      id: 502,
      word: "Daq",
      name: "Daq (ns5) locative (to, in, at, on)"
   }, 
   {
      id: 503,
      word: "Daq",
      name: "Daq (n.) site"
   }, 
   {
      id: 504,
      word: "Daq noy",
      name: "Daq noy (n.) landmark (not a building)"
   }, 
   {
      id: 505,
      word: "DaqQeD",
      name: "DaqQeD (n.) parapsychology"
   }, 
   {
      id: 506,
      word: "Daqav",
      name: "Daqav (n.) bay, inlet, cove"
   }, 
   {
      id: 507,
      word: "Daqba'",
      name: "Daqba' (n.) tuft, tussock"
   }, 
   {
      id: 508,
      word: "Daqrab",
      name: "Daqrab (n.) well"
   }, 
   {
      id: 509,
      word: "Daqtagh",
      name: "Daqtagh (n.) common knife know as a d'k tahg"
   }, 
   {
      id: 510,
      word: "Daqturaq",
      name: "Daqturaq (n.) d'akturak"
   }, 
   {
      id: 511,
      word: "DarDogh",
      name: "DarDogh (n.) clone"
   }, 
   {
      id: 512,
      word: "DarSeq",
      name: "DarSeq (n.) darsek, unit of currency"
   }, 
   {
      id: 513,
      word: "DaraQ",
      name: "DaraQ (p.n.) David Barron"
   }, 
   {
      id: 514,
      word: "Dargh",
      name: "Dargh (n.) tea"
   }, 
   {
      id: 515,
      word: "Dargh HIvje'",
      name: "Dargh HIvje' (n.) teacup"
   }, 
   {
      id: 516,
      word: "Dat",
      name: "Dat (n.) everywhere"
   }, 
   {
      id: 517,
      word: "Dav",
      name: "Dav (v.) sidestep, sway"
   }, 
   {
      id: 518,
      word: "DavHam",
      name: "DavHam (n.) false honor"
   }, 
   {
      id: 519,
      word: "Daw",
      name: "Daw (v.) blow, blow at"
   }, 
   {
      id: 520,
      word: "Daw'",
      name: "Daw' (v.) revolt"
   }, 
   {
      id: 521,
      word: "Daw'",
      name: "Daw' (n.) revolt, revolution"
   }, 
   {
      id: 522,
      word: "DawI'",
      name: "DawI' (n.) actor, actress"
   }, 
   {
      id: 523,
      word: "Day",
      name: "Day (v.) compare"
   }, 
   {
      id: 524,
      word: "Day'muS",
      name: "Day'muS (n.) traffic"
   }, 
   {
      id: 525,
      word: "DayabI’tIS rop",
      name: "DayabI’tIS rop (n.) diabetes"
   }, 
   {
      id: 526,
      word: "DaynguH",
      name: "DaynguH (n.) testicle"
   }, 
   {
      id: 527,
      word: "DayqIr",
      name: "DayqIr (n.) honey"
   }, 
   {
      id: 528,
      word: "DayquS",
      name: "DayquS (n.) type of plant, dikus plant"
   }, 
   {
      id: 529,
      word: "Daytlhay",
      name: "Daytlhay (n.) microphone"
   }, 
   {
      id: 530,
      word: "De'",
      name: "De' (n.) data, information"
   }, 
   {
      id: 531,
      word: "De' QulwI'",
      name: "De' QulwI' (n.) research librarian"
   }, 
   {
      id: 532,
      word: "De' jengva'",
      name: "De' jengva' (n.) compact disc, CD"
   }, 
   {
      id: 533,
      word: "De'chaq",
      name: "De'chaq (p.n.) Tara Aiken"
   }, 
   {
      id: 534,
      word: "De'chel",
      name: "De'chel (adverb) by the way, parenthetically (slang)"
   }, 
   {
      id: 535,
      word: "De'lor",
      name: "De'lor (n.) stalactite, stalagmite"
   }, 
   {
      id: 536,
      word: "De'wI'",
      name: "De'wI' (n.) computer"
   }, 
   {
      id: 537,
      word: "DeH",
      name: "DeH (v.) be ripe, be overripe (fruit, vegetable)"
   }, 
   {
      id: 538,
      word: "DeQ",
      name: "DeQ (n.) credit (monetary unit)"
   }, 
   {
      id: 539,
      word: "DeS",
      name: "DeS (n.) arm (body part)"
   }, 
   {
      id: 540,
      word: "DeS",
      name: "DeS (n.) handle, axe handle"
   }, 
   {
      id: 541,
      word: "DeS",
      name: "DeS (n.) two shorter sides of right-angled triangle, cathetus"
   }, 
   {
      id: 542,
      word: "DeS tutren",
      name: "DeS tutren (n.) elbow pit, cubital fossa"
   }, 
   {
      id: 543,
      word: "DeSHay",
      name: "DeSHay (n.) pedal"
   }, 
   {
      id: 544,
      word: "DeSlay",
      name: "DeSlay (n.) pedal"
   }, 
   {
      id: 545,
      word: "DeSqIv",
      name: "DeSqIv (n.) elbow"
   }, 
   {
      id: 546,
      word: "DeSwar",
      name: "DeSwar (n.) closet, cupboard, cabinet, fixed storage device"
   }, 
   {
      id: 547,
      word: "DeSwar bIr",
      name: "DeSwar bIr (n.) refrigerator"
   }, 
   {
      id: 548,
      word: "Deb",
      name: "Deb (n.) desert"
   }, 
   {
      id: 549,
      word: "Dech",
      name: "Dech (v.) surround"
   }, 
   {
      id: 550,
      word: "Degh",
      name: "Degh (v.) act without a plan, improvise (slang)"
   }, 
   {
      id: 551,
      word: "Degh",
      name: "Degh (n.) helm"
   }, 
   {
      id: 552,
      word: "Degh",
      name: "Degh (n.) medal, emblem, symbol, insignia"
   }, 
   {
      id: 553,
      word: "DeghwI'",
      name: "DeghwI' (n.) helmsman"
   }, 
   {
      id: 554,
      word: "Dej",
      name: "Dej (v.) collapse"
   }, 
   {
      id: 555,
      word: "Del",
      name: "Del (v.) describe"
   }, 
   {
      id: 556,
      word: "Deltan",
      name: "Deltan (n.) molybdenum"
   }, 
   {
      id: 557,
      word: "Dem",
      name: "Dem (v.) be clear, transparent, uncolored, colorless"
   }, 
   {
      id: 558,
      word: "Dem'ot",
      name: "Dem'ot (n.) flow"
   }, 
   {
      id: 559,
      word: "Dem'ot mIr",
      name: "Dem'ot mIr (n.) direct current/DC"
   }, 
   {
      id: 560,
      word: "Den",
      name: "Den (v.) attract (magnetically)"
   }, 
   {
      id: 561,
      word: "DenHa'",
      name: "DenHa' (v.) repel (magnetically)"
   }, 
   {
      id: 562,
      word: "DenIb",
      name: "DenIb (n.) Denebia"
   }, 
   {
      id: 563,
      word: "DenIb Qatlh",
      name: "DenIb Qatlh (n.) Denebian slime devil"
   }, 
   {
      id: 564,
      word: "DenIbngan",
      name: "DenIbngan (n.) Denebian"
   }, 
   {
      id: 565,
      word: "DenIbya'",
      name: "DenIbya' (n.) Denebia"
   }, 
   {
      id: 566,
      word: "DenIbya' Qatlh",
      name: "DenIbya' Qatlh (n.) Denebian slime devil"
   }, 
   {
      id: 567,
      word: "DenIbya'ngan",
      name: "DenIbya'ngan (n.) Denebian"
   }, 
   {
      id: 568,
      word: "Denmargh",
      name: "Denmargh (n.) Denmark"
   }, 
   {
      id: 569,
      word: "DennaS",
      name: "DennaS (p.n.) Dennas"
   }, 
   {
      id: 570,
      word: "Dep",
      name: "Dep (n.) being (nonhumanoid)"
   }, 
   {
      id: 571,
      word: "Deq",
      name: "Deq (v.) be erstwhile, former, prior, ex-"
   }, 
   {
      id: 572,
      word: "Der",
      name: "Der (v.) veer (to the left or right), yaw (aircraft nose points left or right)"
   }, 
   {
      id: 573,
      word: "Dergh",
      name: "Dergh (v.) surrender, relinquish, give away, let go of"
   }, 
   {
      id: 574,
      word: "DerlIq",
      name: "DerlIq (n.) chest, crate, trunk"
   }, 
   {
      id: 575,
      word: "Deryat",
      name: "Deryat (n.) program, agenda, schedule"
   }, 
   {
      id: 576,
      word: "Dev",
      name: "Dev (v.) lead, guide"
   }, 
   {
      id: 577,
      word: "DevwI'",
      name: "DevwI' (n.) leader"
   }, 
   {
      id: 578,
      word: "Do",
      name: "Do (n.) velocity"
   }, 
   {
      id: 579,
      word: "Do QIn",
      name: "Do QIn (n.) Instant Message (IM)"
   }, 
   {
      id: 580,
      word: "Do Qe'",
      name: "Do Qe' (n.) fast food resturant"
   }, 
   {
      id: 581,
      word: "Do qaD",
      name: "Do qaD (n.) race (contest of speed)"
   }, 
   {
      id: 582,
      word: "Do'",
      name: "Do' (v.) be fortunate, be lucky"
   }, 
   {
      id: 583,
      word: "Do'",
      name: "Do' (adverb) luckily"
   }, 
   {
      id: 584,
      word: "Do'Ha'",
      name: "Do'Ha' (v.) be unfortunate"
   }, 
   {
      id: 585,
      word: "Do'Ha'",
      name: "Do'Ha' (adverb) unfortunately"
   }, 
   {
      id: 586,
      word: "Do'ghI'",
      name: "Do'ghI' (n.) calf (body part)"
   }, 
   {
      id: 587,
      word: "Do'natu vagh",
      name: "Do'natu vagh (n.) Donatu V"
   }, 
   {
      id: 588,
      word: "Do'ol",
      name: "Do'ol (n.) sand"
   }, 
   {
      id: 589,
      word: "Do'ol HuD",
      name: "Do'ol HuD (n.) dune"
   }, 
   {
      id: 590,
      word: "Do'ol raS'IS",
      name: "Do'ol raS'IS (n.) grain of sand"
   }, 
   {
      id: 591,
      word: "Do'rIn",
      name: "Do'rIn (p.n.) Dorn"
   }, 
   {
      id: 592,
      word: "Do'val",
      name: "Do'val (p.n.) Matt Whiteacre"
   }, 
   {
      id: 593,
      word: "DoD",
      name: "DoD (n.) mark (in coordinates)"
   }, 
   {
      id: 594,
      word: "DoH",
      name: "DoH (v.) back away from, back off, get away from"
   }, 
   {
      id: 595,
      word: "DoQ",
      name: "DoQ (v.) claim (territory)"
   }, 
   {
      id: 596,
      word: "DoQmIv",
      name: "DoQmIv (n.) sink for cleaning hands, face, food, etc"
   }, 
   {
      id: 597,
      word: "DoQmIv'a'",
      name: "DoQmIv'a' (n.) bathtub, swimming pool"
   }, 
   {
      id: 598,
      word: "DoS",
      name: "DoS (n.) target"
   }, 
   {
      id: 599,
      word: "DoS chIl",
      name: "DoS chIl (v.) expression to say"
   }, 
   {
      id: 600,
      word: "Doch",
      name: "Doch (v.) be rude"
   }, 
   {
      id: 601,
      word: "Doch",
      name: "Doch (n.) thing"
   }, 
   {
      id: 602,
      word: "Dogh",
      name: "Dogh (v.) be foolish, be silly"
   }, 
   {
      id: 603,
      word: "Doghjey",
      name: "Doghjey (n.) unconditional surrender"
   }, 
   {
      id: 604,
      word: "Doj",
      name: "Doj (n.) batch, pile, heap, accumulation"
   }, 
   {
      id: 605,
      word: "Doj",
      name: "Doj (v.) be impressive"
   }, 
   {
      id: 606,
      word: "Doj tlhum",
      name: "Doj tlhum (n.) bundle"
   }, 
   {
      id: 607,
      word: "Dojmey",
      name: "Dojmey (n.) mass, masses, multitude, a very large but indeterminate group of something (people or otherwise)"
   }, 
   {
      id: 608,
      word: "Dol",
      name: "Dol (n.) entity"
   }, 
   {
      id: 609,
      word: "Dol mI'",
      name: "Dol mI' (n.) integer"
   }, 
   {
      id: 610,
      word: "Doltop",
      name: "Doltop (n.) lapis lazuli"
   }, 
   {
      id: 611,
      word: "Dom",
      name: "Dom (n.) radan (crude dilithium crystal)"
   }, 
   {
      id: 612,
      word: "Don",
      name: "Don (v.) be parallel, go parallel to"
   }, 
   {
      id: 613,
      word: "Dop",
      name: "Dop (v.) be negative (literally be opposite)"
   }, 
   {
      id: 614,
      word: "Dop",
      name: "Dop (v.) be opposite, antithetical, contradictory"
   }, 
   {
      id: 615,
      word: "Dop",
      name: "Dop (n.) side"
   }, 
   {
      id: 616,
      word: "Doq",
      name: "Doq (p.n.) Althea Katz"
   }, 
   {
      id: 617,
      word: "Doq",
      name: "Doq (v.) be orange, be red"
   }, 
   {
      id: 618,
      word: "Doq 'ej wovbe'",
      name: "Doq 'ej wovbe' (v.) be brown"
   }, 
   {
      id: 619,
      word: "Dor",
      name: "Dor (v.) end"
   }, 
   {
      id: 620,
      word: "Dor",
      name: "Dor (v.) escort"
   }, 
   {
      id: 621,
      word: "Dotlh",
      name: "Dotlh (p.n.) Rens Duysens"
   }, 
   {
      id: 622,
      word: "Dotlh",
      name: "Dotlh (n.) status"
   }, 
   {
      id: 623,
      word: "Dotra'qIy Hol",
      name: "Dotra'qIy Hol (n.) Dothraki"
   }, 
   {
      id: 624,
      word: "Dotrar",
      name: "Dotrar (n.) constellation"
   }, 
   {
      id: 625,
      word: "Dov'agh",
      name: "Dov'agh (n.) flute, fife"
   }, 
   {
      id: 626,
      word: "Doy",
      name: "Doy (v.) smuggle (general term)"
   }, 
   {
      id: 627,
      word: "Doy'",
      name: "Doy' (v.) be tired"
   }, 
   {
      id: 628,
      word: "Doy'yuS",
      name: "Doy'yuS (n.) Troyius"
   }, 
   {
      id: 629,
      word: "DoyIchlan",
      name: "DoyIchlan (n.) Germany"
   }, 
   {
      id: 630,
      word: "DoylI'",
      name: "DoylI' (n.) cart"
   }, 
   {
      id: 631,
      word: "DoywI'",
      name: "DoywI' (n.) smuggler (general)"
   }, 
   {
      id: 632,
      word: "Du",
      name: "Du (vp) he/she/it-you"
   }, 
   {
      id: 633,
      word: "Du'",
      name: "Du' (n.) farm"
   }, 
   {
      id: 634,
      word: "Du'",
      name: "Du' (ns2) plural (body part)"
   }, 
   {
      id: 635,
      word: "Du' Ha'DIbaH(mey)",
      name: "Du' Ha'DIbaH(mey) (n.) livestock"
   }, 
   {
      id: 636,
      word: "Du' naH",
      name: "Du' naH (n.) produce"
   }, 
   {
      id: 637,
      word: "Du'Hom",
      name: "Du'Hom (n.) garden"
   }, 
   {
      id: 638,
      word: "Du'Qam",
      name: "Du'Qam (n.) type of flower"
   }, 
   {
      id: 639,
      word: "Du'QamHom",
      name: "Du'QamHom (n.) type of flower, sunflower"
   }, 
   {
      id: 640,
      word: "Du'ran",
      name: "Du'ran (n.) philtrum"
   }, 
   {
      id: 641,
      word: "DuD",
      name: "DuD (v.) mix"
   }, 
   {
      id: 642,
      word: "DuDwI'",
      name: "DuDwI' (n.) stirring stick, mixing stick"
   }, 
   {
      id: 643,
      word: "DuH",
      name: "DuH (v.) be possible"
   }, 
   {
      id: 644,
      word: "DuH",
      name: "DuH (n.) possibility, option"
   }, 
   {
      id: 645,
      word: "DuHSum",
      name: "DuHSum (n.) lobster-like creature"
   }, 
   {
      id: 646,
      word: "DuHmor",
      name: "DuHmor (n.) palace"
   }, 
   {
      id: 647,
      word: "DuQ",
      name: "DuQ (v.) stab"
   }, 
   {
      id: 648,
      word: "DuQ",
      name: "DuQ (v.) touch (emotionally)"
   }, 
   {
      id: 649,
      word: "DuQwI'",
      name: "DuQwI' (n.) spike"
   }, 
   {
      id: 650,
      word: "DuQwI'Hommey",
      name: "DuQwI'Hommey (n.) small spikes on the d'k tahg pommel"
   }, 
   {
      id: 651,
      word: "DuS",
      name: "DuS (n.) torpedo tube"
   }, 
   {
      id: 652,
      word: "DuSaQ",
      name: "DuSaQ (n.) school"
   }, 
   {
      id: 653,
      word: "DuSchoHer",
      name: "DuSchoHer (n.) enzyme"
   }, 
   {
      id: 654,
      word: "Dub",
      name: "Dub (n.) back (of body)"
   }, 
   {
      id: 655,
      word: "Dub",
      name: "Dub (v.) improve"
   }, 
   {
      id: 656,
      word: "Dugh",
      name: "Dugh (v.) be vigilant"
   }, 
   {
      id: 657,
      word: "DughrI'",
      name: "DughrI' (n.) skull"
   }, 
   {
      id: 658,
      word: "Duj",
      name: "Duj (n.) instincts"
   }, 
   {
      id: 659,
      word: "Duj",
      name: "Duj (n.) ship, vessel"
   }, 
   {
      id: 660,
      word: "Duj ngaDHa'",
      name: "Duj ngaDHa' (n.) irresponsible person, undisciplined person (slang)"
   }, 
   {
      id: 661,
      word: "DujtlhuQ",
      name: "DujtlhuQ (n.) star shaped polygon (not a star in space)"
   }, 
   {
      id: 662,
      word: "DujtlhuQ bIQDep",
      name: "DujtlhuQ bIQDep (n.) starfish"
   }, 
   {
      id: 663,
      word: "Dul",
      name: "Dul (v.) sigh"
   }, 
   {
      id: 664,
      word: "Dum",
      name: "Dum (v.) nap"
   }, 
   {
      id: 665,
      word: "Dun",
      name: "Dun (v.) be wonderful, be great"
   }, 
   {
      id: 666,
      word: "Dung",
      name: "Dung (n.) area above, area overhead"
   }, 
   {
      id: 667,
      word: "DungluQ",
      name: "DungluQ (n.) noon"
   }, 
   {
      id: 668,
      word: "Dup",
      name: "Dup (n.) strategy"
   }, 
   {
      id: 669,
      word: "Duq",
      name: "Duq (v.) be stunned, be shocked"
   }, 
   {
      id: 670,
      word: "Duq",
      name: "Duq (n.) bowl (small)"
   }, 
   {
      id: 671,
      word: "DuraS",
      name: "DuraS (p.n.) Duras"
   }, 
   {
      id: 672,
      word: "Duran lung DIr",
      name: "Duran lung DIr (n.) Durani lizard skins (food, never uses plural suffix)"
   }, 
   {
      id: 673,
      word: "Durghang",
      name: "Durghang (n.) lock"
   }, 
   {
      id: 674,
      word: "Durghang qung",
      name: "Durghang qung (n.) keyhole on a lock"
   }, 
   {
      id: 675,
      word: "Dut",
      name: "Dut (v.) slam down (object is the thing slammed down)"
   }, 
   {
      id: 676,
      word: "Dut",
      name: "Dut (v.) stress, emphasize"
   }, 
   {
      id: 677,
      word: "Duv",
      name: "Duv (v.) advance"
   }, 
   {
      id: 678,
      word: "Duy",
      name: "Duy (n.) agent, emissary"
   }, 
   {
      id: 679,
      word: "Duy'",
      name: "Duy' (v.) be defective"
   }, 
   {
      id: 680,
      word: "Duy'",
      name: "Duy' (n.) defect"
   }, 
   {
      id: 681,
      word: "Duy'a'",
      name: "Duy'a' (n.) ambassador"
   }, 
   {
      id: 682,
      word: "HI",
      name: "HI (vp) imp: you (s/pl)-me"
   }, 
   {
      id: 683,
      word: "HI'",
      name: "HI' (n.) dictator"
   }, 
   {
      id: 684,
      word: "HI'tuy",
      name: "HI'tuy (n.) dictatorship"
   }, 
   {
      id: 685,
      word: "HID",
      name: "HID (v.) sweat, perspire"
   }, 
   {
      id: 686,
      word: "HIDjolev",
      name: "HIDjolev (n.) menu"
   }, 
   {
      id: 687,
      word: "HIS",
      name: "HIS (v.) be compressed"
   }, 
   {
      id: 688,
      word: "HISlaH",
      name: "HISlaH (exclamation) yes, true (answer to yes/no question)"
   }, 
   {
      id: 689,
      word: "HIch",
      name: "HIch (n.) handgun"
   }, 
   {
      id: 690,
      word: "HIchDal",
      name: "HIchDal (n.) airlock"
   }, 
   {
      id: 691,
      word: "HIgh",
      name: "HIgh (v.) fight dirty"
   }, 
   {
      id: 692,
      word: "HIj",
      name: "HIj (v.) deliver, transport goods"
   }, 
   {
      id: 693,
      word: "HIja'",
      name: "HIja' (exclamation) yes, true (answer to yes/no question)"
   }, 
   {
      id: 694,
      word: "HIjmeH 'ap",
      name: "HIjmeH 'ap (n.) fee paid when bringing certain commodities into a jurisdiction"
   }, 
   {
      id: 695,
      word: "HIjmeH 'ap pIn",
      name: "HIjmeH 'ap pIn (n.) customs officer"
   }, 
   {
      id: 696,
      word: "HIjnaj",
      name: "HIjnaj (n.) demon"
   }, 
   {
      id: 697,
      word: "HIjwI'",
      name: "HIjwI' (n.) delivery person"
   }, 
   {
      id: 698,
      word: "HIl",
      name: "HIl (v.) make someone's presence known"
   }, 
   {
      id: 699,
      word: "HIl'aD",
      name: "HIl'aD (n.) step-by-step instructions"
   }, 
   {
      id: 700,
      word: "HInDIy Hol",
      name: "HInDIy Hol (n.) Hindi"
   }, 
   {
      id: 701,
      word: "HIp",
      name: "HIp (n.) suit, business suit"
   }, 
   {
      id: 702,
      word: "HIp",
      name: "HIp (n.) uniform"
   }, 
   {
      id: 703,
      word: "HIq",
      name: "HIq (n.) liquor, ale, beer, wine"
   }, 
   {
      id: 704,
      word: "HIq mergh",
      name: "HIq mergh (n.) cocktail"
   }, 
   {
      id: 705,
      word: "HIq'aD",
      name: "HIq'aD (n.) drunkard, drunk person"
   }, 
   {
      id: 706,
      word: "HIr",
      name: "HIr (v.) be stuck (like a stamp)"
   }, 
   {
      id: 707,
      word: "HIt",
      name: "HIt (v.) think, talk to oneself"
   }, 
   {
      id: 708,
      word: "HItlh",
      name: "HItlh (v.) be brittle"
   }, 
   {
      id: 709,
      word: "HIv",
      name: "HIv (v.) attack"
   }, 
   {
      id: 710,
      word: "HIvDuj",
      name: "HIvDuj (n.) attack fighter, (vessel)"
   }, 
   {
      id: 711,
      word: "HIvchuq",
      name: "HIvchuq (n.) attack range"
   }, 
   {
      id: 712,
      word: "HIvje'",
      name: "HIvje' (n.) glass (tumbler)"
   }, 
   {
      id: 713,
      word: "HIvje' bom",
      name: "HIvje' bom (n.) drinking song"
   }, 
   {
      id: 714,
      word: "HIvje'He",
      name: "HIvje'He (n.) piano in a piano bar"
   }, 
   {
      id: 715,
      word: "Ha'",
      name: "Ha' (exclamation) let's go, come on"
   }, 
   {
      id: 716,
      word: "Ha'",
      name: "Ha' (v.) undo"
   }, 
   {
      id: 717,
      word: "Ha'",
      name: "Ha' (vsr) undo"
   }, 
   {
      id: 718,
      word: "Ha'DIbaH",
      name: "Ha'DIbaH (n.) animal, meat, dog (slang insult), cur (slang insult), inferior person (slang)"
   }, 
   {
      id: 719,
      word: "Ha'DIbaH ngogh",
      name: "Ha'DIbaH ngogh (n.) steak"
   }, 
   {
      id: 720,
      word: "Ha'DIbaH qoSta'",
      name: "Ha'DIbaH qoSta' (n.) bacon"
   }, 
   {
      id: 721,
      word: "Ha'DIbaH tIr ngogh",
      name: "Ha'DIbaH tIr ngogh (n.) meat sandwich"
   }, 
   {
      id: 722,
      word: "Ha'on",
      name: "Ha'on (n.) staple"
   }, 
   {
      id: 723,
      word: "Ha'on vevwI'",
      name: "Ha'on vevwI' (n.) stapler"
   }, 
   {
      id: 724,
      word: "Ha'quj",
      name: "Ha'quj (n.) baldric, Klingon sash"
   }, 
   {
      id: 725,
      word: "HaD",
      name: "HaD (v.) study"
   }, 
   {
      id: 726,
      word: "HaH",
      name: "HaH (v.) marinade, soak, drench"
   }, 
   {
      id: 727,
      word: "HaQchor",
      name: "HaQchor (n.) saccharin"
   }, 
   {
      id: 728,
      word: "HaS",
      name: "HaS (v.) squeak"
   }, 
   {
      id: 729,
      word: "HaSreH",
      name: "HaSreH (n.) pattern, design pattern, markings, motif"
   }, 
   {
      id: 730,
      word: "HaSta",
      name: "HaSta (n.) visual display, video"
   }, 
   {
      id: 731,
      word: "HaSta jIH",
      name: "HaSta jIH (n.) television"
   }, 
   {
      id: 732,
      word: "HaStay'",
      name: "HaStay' (n.) pixel"
   }, 
   {
      id: 733,
      word: "Hab",
      name: "Hab (v.) be smooth"
   }, 
   {
      id: 734,
      word: "HablI'",
      name: "HablI' (n.) data transceiving device"
   }, 
   {
      id: 735,
      word: "Habnagh",
      name: "Habnagh (n.) a type of stone indigenous to Qo'noS. Often used in statuary"
   }, 
   {
      id: 736,
      word: "Hach",
      name: "Hach (v.) be developed (civilization)"
   }, 
   {
      id: 737,
      word: "Hagh",
      name: "Hagh (v.) laugh"
   }, 
   {
      id: 738,
      word: "Haj",
      name: "Haj (v.) dread"
   }, 
   {
      id: 739,
      word: "HajDob",
      name: "HajDob (n.) leg (served as food)"
   }, 
   {
      id: 740,
      word: "Hajvav",
      name: "Hajvav (n.) hajvav, weasel, type of animal"
   }, 
   {
      id: 741,
      word: "Hajvav",
      name: "Hajvav (n.) badger-like creature, weasel-like creature"
   }, 
   {
      id: 742,
      word: "Hal",
      name: "Hal (v.) be porous"
   }, 
   {
      id: 743,
      word: "Hal",
      name: "Hal (n.) source"
   }, 
   {
      id: 744,
      word: "Halrov",
      name: "Halrov (n.) jam, jelly, preserves"
   }, 
   {
      id: 745,
      word: "Halrov",
      name: "Halrov (n.) treacle, syrup"
   }, 
   {
      id: 746,
      word: "Ham",
      name: "Ham (v.) be high (in pitch)"
   }, 
   {
      id: 747,
      word: "Hamburgh",
      name: "Hamburgh (n.) Hamburg"
   }, 
   {
      id: 748,
      word: "Hamlet",
      name: "Hamlet (p.n.) Hamlet"
   }, 
   {
      id: 749,
      word: "Hampong",
      name: "Hampong (n.) wound, sore"
   }, 
   {
      id: 750,
      word: "Hampong DIr",
      name: "Hampong DIr (n.) scab"
   }, 
   {
      id: 751,
      word: "Hampun",
      name: "Hampun (v.) yodel"
   }, 
   {
      id: 752,
      word: "Han",
      name: "Han (v.) be learned, be scholarly, be erudite"
   }, 
   {
      id: 753,
      word: "HanDI'",
      name: "HanDI' (n.) cell"
   }, 
   {
      id: 754,
      word: "HanDogh",
      name: "HanDogh (n.) nacelle"
   }, 
   {
      id: 755,
      word: "Hanghuq",
      name: "Hanghuq (n.) Korea"
   }, 
   {
      id: 756,
      word: "Hap",
      name: "Hap (n.) matter"
   }, 
   {
      id: 757,
      word: "Hap choHwI'",
      name: "Hap choHwI' (n.) replicator"
   }, 
   {
      id: 758,
      word: "HapQeD",
      name: "HapQeD (n.) physics"
   }, 
   {
      id: 759,
      word: "HapmaH",
      name: "HapmaH (n.) pea"
   }, 
   {
      id: 760,
      word: "Haq",
      name: "Haq (v.) intervene in (a situation) (slang)"
   }, 
   {
      id: 761,
      word: "Haq",
      name: "Haq (v.) perform surgery (on), tinker (slang)"
   }, 
   {
      id: 762,
      word: "Haq",
      name: "Haq (n.) surgery"
   }, 
   {
      id: 763,
      word: "Haqtaj",
      name: "Haqtaj (n.) scalpel"
   }, 
   {
      id: 764,
      word: "HaqwI'",
      name: "HaqwI' (n.) surgeon"
   }, 
   {
      id: 765,
      word: "Har",
      name: "Har (v.) believe"
   }, 
   {
      id: 766,
      word: "Har'ey",
      name: "Har'ey (n.) rainbow"
   }, 
   {
      id: 767,
      word: "Hargh",
      name: "Hargh (v.) fight, battle (major confrontation)"
   }, 
   {
      id: 768,
      word: "HarghwI'",
      name: "HarghwI' (p.n.) Paul J. Coffey"
   }, 
   {
      id: 769,
      word: "HarqIn",
      name: "HarqIn (n.) disorder, disability, syndrome, condition"
   }, 
   {
      id: 770,
      word: "Hat",
      name: "Hat (v.) be illegal"
   }, 
   {
      id: 771,
      word: "Hat",
      name: "Hat (n.) temperature"
   }, 
   {
      id: 772,
      word: "Hatlh",
      name: "Hatlh (n.) country, countryside"
   }, 
   {
      id: 773,
      word: "Haw",
      name: "Haw (v.) be random, arbitrary, unpredictable, fortuitous"
   }, 
   {
      id: 774,
      word: "Haw'",
      name: "Haw' (v.) flee, get out"
   }, 
   {
      id: 775,
      word: "HawSa Hol",
      name: "HawSa Hol (n.) Hausa"
   }, 
   {
      id: 776,
      word: "Hay",
      name: "Hay (n.) area beyond"
   }, 
   {
      id: 777,
      word: "Hay",
      name: "Hay (v.) somersault"
   }, 
   {
      id: 778,
      word: "Hay'",
      name: "Hay' (v.) duel"
   }, 
   {
      id: 779,
      word: "Hay'chu'",
      name: "Hay'chu' (v.) duel to the death"
   }, 
   {
      id: 780,
      word: "HaySIn",
      name: "HaySIn (n.) bucket"
   }, 
   {
      id: 781,
      word: "HayaStan",
      name: "HayaStan (n.) Armenia"
   }, 
   {
      id: 782,
      word: "He",
      name: "He (n.) course, route"
   }, 
   {
      id: 783,
      word: "He'",
      name: "He' (v.) smell, emit odor, emit a smell"
   }, 
   {
      id: 784,
      word: "He'So'",
      name: "He'So' (v.) stink"
   }, 
   {
      id: 785,
      word: "HeD",
      name: "HeD (v.) retreat"
   }, 
   {
      id: 786,
      word: "HeDon",
      name: "HeDon (n.) parallel course"
   }, 
   {
      id: 787,
      word: "HeH",
      name: "HeH (n.) edge"
   }, 
   {
      id: 788,
      word: "HeQ",
      name: "HeQ (v.) comply"
   }, 
   {
      id: 789,
      word: "HeS",
      name: "HeS (v.) commit (a crime)"
   }, 
   {
      id: 790,
      word: "HeS",
      name: "HeS (n.) crime"
   }, 
   {
      id: 791,
      word: "HeSwI'",
      name: "HeSwI' (n.) criminal"
   }, 
   {
      id: 792,
      word: "Hech",
      name: "Hech (v.) intend, mean to"
   }, 
   {
      id: 793,
      word: "Hegh",
      name: "Hegh (n.) death"
   }, 
   {
      id: 794,
      word: "Hegh",
      name: "Hegh (v.) die"
   }, 
   {
      id: 795,
      word: "Heghba'",
      name: "Heghba' (n.) ritual suicide"
   }, 
   {
      id: 796,
      word: "Heghbat",
      name: "Heghbat (n.) ritual suicide"
   }, 
   {
      id: 797,
      word: "HeghmoH",
      name: "HeghmoH (v.) be fatal"
   }, 
   {
      id: 798,
      word: "Heghtay",
      name: "Heghtay (n.) death ritual"
   }, 
   {
      id: 799,
      word: "Hej",
      name: "Hej (v.) rob"
   }, 
   {
      id: 800,
      word: "HejwI'",
      name: "HejwI' (n.) robber"
   }, 
   {
      id: 801,
      word: "Hem",
      name: "Hem (v.) be proud"
   }, 
   {
      id: 802,
      word: "Hen",
      name: "Hen (v.) be experienced"
   }, 
   {
      id: 803,
      word: "Heng",
      name: "Heng (v.) finger (holes, strings of instrument) to vary sound"
   }, 
   {
      id: 804,
      word: "Henjun",
      name: "Henjun (n.) whip"
   }, 
   {
      id: 805,
      word: "Henjun waq",
      name: "Henjun waq (n.) flip-flop, thong, zori"
   }, 
   {
      id: 806,
      word: "Heq",
      name: "Heq (v.) hail (weather)"
   }, 
   {
      id: 807,
      word: "HeqqIv",
      name: "HeqqIv (n.) cliché, trope"
   }, 
   {
      id: 808,
      word: "Her'IS",
      name: "Her'IS (n.) bird with a long neck and long legs"
   }, 
   {
      id: 809,
      word: "Hergh",
      name: "Hergh (n.) medicine"
   }, 
   {
      id: 810,
      word: "HerghQeD",
      name: "HerghQeD (n.) pharmacology"
   }, 
   {
      id: 811,
      word: "HerghwI'",
      name: "HerghwI' (n.) hypo, pneumatic hypo"
   }, 
   {
      id: 812,
      word: "Hervachqa",
      name: "Hervachqa (n.) Croatia"
   }, 
   {
      id: 813,
      word: "HetaQ",
      name: "HetaQ (p.n.) Chester Braun"
   }, 
   {
      id: 814,
      word: "Hev",
      name: "Hev (v.) receive"
   }, 
   {
      id: 815,
      word: "Hew",
      name: "Hew (n.) statue, sculpture"
   }, 
   {
      id: 816,
      word: "Hew chenmoHwI'",
      name: "Hew chenmoHwI' (n.) sculptor"
   }, 
   {
      id: 817,
      word: "Hey",
      name: "Hey (ns3) apparent"
   }, 
   {
      id: 818,
      word: "Hey",
      name: "Hey (v.) battle or fight against one's own group (not the supposed enemy)"
   }, 
   {
      id: 819,
      word: "Hey'",
      name: "Hey' (v.) censor"
   }, 
   {
      id: 820,
      word: "HeySel",
      name: "HeySel (n.) atom"
   }, 
   {
      id: 821,
      word: "HghHghHgh",
      name: "HghHghHgh (n.) onomatopoetic exclamation for laughing"
   }, 
   {
      id: 822,
      word: "Ho'",
      name: "Ho' (v.) admire"
   }, 
   {
      id: 823,
      word: "Ho'",
      name: "Ho' (n.) cog/sprocket teeth"
   }, 
   {
      id: 824,
      word: "Ho'",
      name: "Ho' (n.) idol (slang)"
   }, 
   {
      id: 825,
      word: "Ho'",
      name: "Ho' (n.) tooth"
   }, 
   {
      id: 826,
      word: "Ho' 'etlh",
      name: "Ho' 'etlh (n.) serrated blade (e.g., kut'luch)"
   }, 
   {
      id: 827,
      word: "Ho' SIryoD",
      name: "Ho' SIryoD (n.) dental braces"
   }, 
   {
      id: 828,
      word: "Ho' rutlh",
      name: "Ho' rutlh (n.) cog/sprocket wheel"
   }, 
   {
      id: 829,
      word: "Ho''oy'",
      name: "Ho''oy' (n.) toothache"
   }, 
   {
      id: 830,
      word: "Ho'DoS",
      name: "Ho'DoS (n.) system, method, manner, technique"
   }, 
   {
      id: 831,
      word: "Ho'latbeD",
      name: "Ho'latbeD (n.) main or principal purpose, ikigai, raison d’être"
   }, 
   {
      id: 832,
      word: "Ho'yI'",
      name: "Ho'yI' (n.) bow (for arrows)"
   }, 
   {
      id: 833,
      word: "HoD",
      name: "HoD (n.) captain"
   }, 
   {
      id: 834,
      word: "HoH",
      name: "HoH (v.) kill"
   }, 
   {
      id: 835,
      word: "HoH",
      name: "HoH (n.) killing"
   }, 
   {
      id: 836,
      word: "HoH'egh",
      name: "HoH'egh (v.) commit suicide"
   }, 
   {
      id: 837,
      word: "HoQ",
      name: "HoQ (v.) be honored falsely, be falsely honorable"
   }, 
   {
      id: 838,
      word: "HoS",
      name: "HoS (n.) amplitude"
   }, 
   {
      id: 839,
      word: "HoS",
      name: "HoS (v.) be strong"
   }, 
   {
      id: 840,
      word: "HoS",
      name: "HoS (n.) strength, energy, power"
   }, 
   {
      id: 841,
      word: "HoS choHwI'",
      name: "HoS choHwI' (n.) transtator"
   }, 
   {
      id: 842,
      word: "HoS voveng",
      name: "HoS voveng (n.) thyroid"
   }, 
   {
      id: 843,
      word: "HoS'etlh",
      name: "HoS'etlh (p.n.) Ben Warren"
   }, 
   {
      id: 844,
      word: "HoSDo'",
      name: "HoSDo' (n.) energy beings"
   }, 
   {
      id: 845,
      word: "HoSHal",
      name: "HoSHal (n.) power source"
   }, 
   {
      id: 846,
      word: "HoSchem",
      name: "HoSchem (n.) energy field"
   }, 
   {
      id: 847,
      word: "HoSghaj",
      name: "HoSghaj (v.) be powerful"
   }, 
   {
      id: 848,
      word: "Hob",
      name: "Hob (v.) yawn"
   }, 
   {
      id: 849,
      word: "Hoch",
      name: "Hoch (n.) everyone, all, everything"
   }, 
   {
      id: 850,
      word: "HochDIch",
      name: "HochDIch (number) allth, final, last"
   }, 
   {
      id: 851,
      word: "HochHom",
      name: "HochHom (n.) most, greater part"
   }, 
   {
      id: 852,
      word: "Hochlogh",
      name: "Hochlogh (adverb) all times, always (emphatic)"
   }, 
   {
      id: 853,
      word: "Hogh",
      name: "Hogh (n.) week (Klingon)"
   }, 
   {
      id: 854,
      word: "Hoghjaj",
      name: "Hoghjaj (n.) anniversary measured in weeks"
   }, 
   {
      id: 855,
      word: "Hoj",
      name: "Hoj (v.) be cautious"
   }, 
   {
      id: 856,
      word: "HojnIy",
      name: "HojnIy (n.) teen, teenager, adolescent, youth, young adult"
   }, 
   {
      id: 857,
      word: "Hol",
      name: "Hol (n.) language"
   }, 
   {
      id: 858,
      word: "Hol Sar",
      name: "Hol Sar (n.) dialect"
   }, 
   {
      id: 859,
      word: "Hol ghoQ",
      name: "Hol ghoQ (n.) slang, fresh language (mostly used by younger Klingons)"
   }, 
   {
      id: 860,
      word: "HolQeD",
      name: "HolQeD (n.) linguistics"
   }, 
   {
      id: 861,
      word: "HolQeD",
      name: "HolQeD (p.n.) the KLI journal"
   }, 
   {
      id: 862,
      word: "Holtej",
      name: "Holtej (p.n.) d'Armond Speers"
   }, 
   {
      id: 863,
      word: "Hom",
      name: "Hom (n.) bone"
   }, 
   {
      id: 864,
      word: "Hom",
      name: "Hom (ns1) diminutive"
   }, 
   {
      id: 865,
      word: "Hom",
      name: "Hom (v.) use the second toe"
   }, 
   {
      id: 866,
      word: "Hom",
      name: "Hom (n.) weakling (slang), runt (slang), scrawny one (slang), skinny one (slang)"
   }, 
   {
      id: 867,
      word: "HomDoq",
      name: "HomDoq (p.n.) Marc Ruehlaender"
   }, 
   {
      id: 868,
      word: "HomHap tun",
      name: "HomHap tun (n.) cartilage"
   }, 
   {
      id: 869,
      word: "HommaH",
      name: "HommaH (n.) appendix (of a book)"
   }, 
   {
      id: 870,
      word: "HomwI'",
      name: "HomwI' (n.) second toe"
   }, 
   {
      id: 871,
      word: "Hon",
      name: "Hon (v.) doubt"
   }, 
   {
      id: 872,
      word: "Hong",
      name: "Hong (n.) impulse power"
   }, 
   {
      id: 873,
      word: "Hong boq chuyDaH",
      name: "Hong boq chuyDaH (n.) impulse fusion thrusters"
   }, 
   {
      id: 874,
      word: "Hongghor",
      name: "Hongghor (n.) impulse drive"
   }, 
   {
      id: 875,
      word: "Hop",
      name: "Hop (v.) be remote, be far"
   }, 
   {
      id: 876,
      word: "Hoq",
      name: "Hoq (n.) expedition"
   }, 
   {
      id: 877,
      word: "Hoq",
      name: "Hoq (v.) pull"
   }, 
   {
      id: 878,
      word: "Hoqra'",
      name: "Hoqra' (n.) tricorder"
   }, 
   {
      id: 879,
      word: "Horey'So",
      name: "Horey'So (p.n.) Horatio"
   }, 
   {
      id: 880,
      word: "Hot",
      name: "Hot (v.) touch, feel"
   }, 
   {
      id: 881,
      word: "Hotlh",
      name: "Hotlh (v.) project, put on (screen)"
   }, 
   {
      id: 882,
      word: "Hotlh",
      name: "Hotlh (v.) scan"
   }, 
   {
      id: 883,
      word: "HotlhwI'",
      name: "HotlhwI' (n.) scanner"
   }, 
   {
      id: 884,
      word: "Hotnagh",
      name: "Hotnagh (n.) basalt"
   }, 
   {
      id: 885,
      word: "Hov",
      name: "Hov (n.) star"
   }, 
   {
      id: 886,
      word: "Hov tut",
      name: "Hov tut (n.) telescope"
   }, 
   {
      id: 887,
      word: "HovQeD",
      name: "HovQeD (n.) astronomy"
   }, 
   {
      id: 888,
      word: "Hovje'voH",
      name: "Hovje'voH (n.) evolution (Darwinian)"
   }, 
   {
      id: 889,
      word: "HovpoH",
      name: "HovpoH (n.) stardate"
   }, 
   {
      id: 890,
      word: "Hovtay'",
      name: "Hovtay' (n.) star system"
   }, 
   {
      id: 891,
      word: "Hovtej",
      name: "Hovtej (n.) astronomer"
   }, 
   {
      id: 892,
      word: "Hoy",
      name: "Hoy (v.) be refined, be fancy, be sophisticated"
   }, 
   {
      id: 893,
      word: "Hoy'",
      name: "Hoy' (v.) congratulate"
   }, 
   {
      id: 894,
      word: "HoyHa'",
      name: "HoyHa' (v.) be awkward (slang)"
   }, 
   {
      id: 895,
      word: "Hu",
      name: "Hu (n.) zoo"
   }, 
   {
      id: 896,
      word: "Hu'",
      name: "Hu' (n.) days ago"
   }, 
   {
      id: 897,
      word: "Hu'",
      name: "Hu' (v.) get up"
   }, 
   {
      id: 898,
      word: "Hu'ma",
      name: "Hu'ma (exclamation) uh, umm"
   }, 
   {
      id: 899,
      word: "Hu'tegh",
      name: "Hu'tegh (exclamation) (curse) general invective"
   }, 
   {
      id: 900,
      word: "HuD",
      name: "HuD (n.) mountain, hill"
   }, 
   {
      id: 901,
      word: "HuD beQ yoS",
      name: "HuD beQ yoS (n.) Flat Mountain district (in the Sakrej region)"
   }, 
   {
      id: 902,
      word: "HuDngech",
      name: "HuDngech (n.) sine (curve)"
   }, 
   {
      id: 903,
      word: "HuDngech Sum",
      name: "HuDngech Sum (n.) cosine"
   }, 
   {
      id: 904,
      word: "HuDqIj",
      name: "HuDqIj (p.n.) Black Hills"
   }, 
   {
      id: 905,
      word: "HuDyar",
      name: "HuDyar (n.) shed, shack"
   }, 
   {
      id: 906,
      word: "HuH",
      name: "HuH (n.) bile, slime, gall"
   }, 
   {
      id: 907,
      word: "HuQ'am",
      name: "HuQ'am (n.) gender"
   }, 
   {
      id: 908,
      word: "HuS",
      name: "HuS (v.) hang"
   }, 
   {
      id: 909,
      word: "HuS",
      name: "HuS (p.n.) Huss"
   }, 
   {
      id: 910,
      word: "Hub",
      name: "Hub (v.) defend"
   }, 
   {
      id: 911,
      word: "Hub",
      name: "Hub (n.) defense"
   }, 
   {
      id: 912,
      word: "Hubbeq",
      name: "Hubbeq (n.) Defense Force"
   }, 
   {
      id: 913,
      word: "Huch",
      name: "Huch (n.) money"
   }, 
   {
      id: 914,
      word: "Huch jengva'",
      name: "Huch jengva' (n.) coin"
   }, 
   {
      id: 915,
      word: "Huch ngop",
      name: "Huch ngop (n.) coins"
   }, 
   {
      id: 916,
      word: "HuchQeD",
      name: "HuchQeD (n.) economics"
   }, 
   {
      id: 917,
      word: "Hugh",
      name: "Hugh (n.) throat"
   }, 
   {
      id: 918,
      word: "Huj",
      name: "Huj (v.) be strange, unfamiliar"
   }, 
   {
      id: 919,
      word: "Huj",
      name: "Huj (v.) charge (up)"
   }, 
   {
      id: 920,
      word: "HujlIw",
      name: "HujlIw (n.) needle"
   }, 
   {
      id: 921,
      word: "Hum",
      name: "Hum (v.) be sticky"
   }, 
   {
      id: 922,
      word: "Human",
      name: "Human (n.) human"
   }, 
   {
      id: 923,
      word: "Humlaw'",
      name: "Humlaw' (n.) centipede or millipede like bug"
   }, 
   {
      id: 924,
      word: "Hun",
      name: "Hun (n.) Khrun, type of animal"
   }, 
   {
      id: 925,
      word: "Hung",
      name: "Hung (n.) security"
   }, 
   {
      id: 926,
      word: "Hup",
      name: "Hup (v.) punish"
   }, 
   {
      id: 927,
      word: "Huq",
      name: "Huq (v.) transact"
   }, 
   {
      id: 928,
      word: "HuqmeH 'ap",
      name: "HuqmeH 'ap (n.) excise tax, sales tax, VAT"
   }, 
   {
      id: 929,
      word: "Hur",
      name: "Hur (n.) outside"
   }, 
   {
      id: 930,
      word: "Hur",
      name: "Hur (v.) pull, tug"
   }, 
   {
      id: 931,
      word: "Hur'Iq",
      name: "Hur'Iq (n.) outsider, foreigner (slang)"
   }, 
   {
      id: 932,
      word: "Hur'Iqngan",
      name: "Hur'Iqngan (n.) Hur'q (person)"
   }, 
   {
      id: 933,
      word: "HurDagh",
      name: "HurDagh (n.) stringed instrument (general term)"
   }, 
   {
      id: 934,
      word: "HurDagh chuHwI'",
      name: "HurDagh chuHwI' (n.) bow (for arrows) (not a Klingon device), lit."
   }, 
   {
      id: 935,
      word: "Hurgh",
      name: "Hurgh (v.) be dark"
   }, 
   {
      id: 936,
      word: "Hurgh",
      name: "Hurgh (n.) pickle (cucumber)"
   }, 
   {
      id: 937,
      word: "Hurgh Duj",
      name: "Hurgh Duj (n.) submarine, blimp"
   }, 
   {
      id: 938,
      word: "HurwI'",
      name: "HurwI' (n.) bow (for arrows) (not a Klingon device) (short form)"
   }, 
   {
      id: 939,
      word: "Hut",
      name: "Hut (number) nine, 9"
   }, 
   {
      id: 940,
      word: "Hut'In",
      name: "Hut'In (n.) nail"
   }, 
   {
      id: 941,
      word: "Hut'In tIq",
      name: "Hut'In tIq (n.) stick used for weaving,"
   }, 
   {
      id: 942,
      word: "Hut'In vIl",
      name: "Hut'In vIl (n.) screw"
   }, 
   {
      id: 943,
      word: "Hut'on",
      name: "Hut'on (n.) byte"
   }, 
   {
      id: 944,
      word: "Hutlh",
      name: "Hutlh (v.) lack, be without, to not have"
   }, 
   {
      id: 945,
      word: "HutmaH",
      name: "HutmaH (n.) sexual climax (slang)"
   }, 
   {
      id: 946,
      word: "Hutvagh",
      name: "Hutvagh (n.) too many people or things in a place at once"
   }, 
   {
      id: 947,
      word: "Hutvav",
      name: "Hutvav (n.) nerve (anatomy, physiology)"
   }, 
   {
      id: 948,
      word: "Hutvav rarwI'",
      name: "Hutvav rarwI' (n.) neural synapse"
   }, 
   {
      id: 949,
      word: "Huv",
      name: "Huv (v.) be clear, be not obstructed"
   }, 
   {
      id: 950,
      word: "Huy",
      name: "Huy (v.) be spicy, be piquant, be hot, be randy (slang), be horny (slang)"
   }, 
   {
      id: 951,
      word: "Huy",
      name: "Huy (v.) hum"
   }, 
   {
      id: 952,
      word: "Huy",
      name: "Huy (v.) purr"
   }, 
   {
      id: 953,
      word: "Huy'",
      name: "Huy' (n.) eyebrow"
   }, 
   {
      id: 954,
      word: "Huy'Dung",
      name: "Huy'Dung (n.) forehead (regional)"
   }, 
   {
      id: 955,
      word: "K'Eertah",
      name: "K'Eertah (p.n.) Dona Bazley"
   }, 
   {
      id: 956,
      word: "QI",
      name: "QI (n.) bridge (over a river)"
   }, 
   {
      id: 957,
      word: "QI'",
      name: "QI' (n.) military"
   }, 
   {
      id: 958,
      word: "QI'lop",
      name: "QI'lop (n.) a holiday"
   }, 
   {
      id: 959,
      word: "QI'lop",
      name: "QI'lop (n.) holiday (name of a)"
   }, 
   {
      id: 960,
      word: "QI'tomer",
      name: "QI'tomer (n.) Khitomer"
   }, 
   {
      id: 961,
      word: "QI'tu'",
      name: "QI'tu' (n.) Paradise"
   }, 
   {
      id: 962,
      word: "QI'yaH",
      name: "QI'yaH (exclamation) (curse) general invective"
   }, 
   {
      id: 963,
      word: "QID",
      name: "QID (v.) wound"
   }, 
   {
      id: 964,
      word: "QIH",
      name: "QIH (v.) damage, cause damage"
   }, 
   {
      id: 965,
      word: "QIH",
      name: "QIH (n.) damage, destruction"
   }, 
   {
      id: 966,
      word: "QIH",
      name: "QIH (v.) wrong, treat unjustly, mistreat"
   }, 
   {
      id: 967,
      word: "QIS",
      name: "QIS (v.) stitch, sew"
   }, 
   {
      id: 968,
      word: "QIS",
      name: "QIS (n.) wavy-bladed knife"
   }, 
   {
      id: 969,
      word: "QIStaq",
      name: "QIStaq (p.n.) Kri'stak"
   }, 
   {
      id: 970,
      word: "QISten lalDan",
      name: "QISten lalDan (n.) Christianity"
   }, 
   {
      id: 971,
      word: "QIb",
      name: "QIb (v.) filter, strain, sieve, sift"
   }, 
   {
      id: 972,
      word: "QIb",
      name: "QIb (n.) shadow"
   }, 
   {
      id: 973,
      word: "QIch",
      name: "QIch (n.) speech (vocal sounds)"
   }, 
   {
      id: 974,
      word: "QIch wab",
      name: "QIch wab (n.) phoneme"
   }, 
   {
      id: 975,
      word: "QIch wab Sar",
      name: "QIch wab Sar (n.) allophone"
   }, 
   {
      id: 976,
      word: "QIghpej",
      name: "QIghpej (n.) Klingon agonizer"
   }, 
   {
      id: 977,
      word: "QIj",
      name: "QIj (v.) explain"
   }, 
   {
      id: 978,
      word: "QIl",
      name: "QIl (v.) be desperate"
   }, 
   {
      id: 979,
      word: "QIm",
      name: "QIm (n.) egg"
   }, 
   {
      id: 980,
      word: "QImHal",
      name: "QImHal (n.) ovary"
   }, 
   {
      id: 981,
      word: "QIn",
      name: "QIn (v.) inject"
   }, 
   {
      id: 982,
      word: "QIn",
      name: "QIn (n.) message"
   }, 
   {
      id: 983,
      word: "QIn",
      name: "QIn (n.) spear head, sharpened end of pencil"
   }, 
   {
      id: 984,
      word: "QIn 'echletHom",
      name: "QIn 'echletHom (n.) postcard"
   }, 
   {
      id: 985,
      word: "QIn pup",
      name: "QIn pup (n.) plain spearhead with single sharp point"
   }, 
   {
      id: 986,
      word: "QIn tum",
      name: "QIn tum (n.) postal service"
   }, 
   {
      id: 987,
      word: "QIn tum qach",
      name: "QIn tum qach (n.) post office (building)"
   }, 
   {
      id: 988,
      word: "QIn vagh",
      name: "QIn vagh (n.) spearhead with multiple points"
   }, 
   {
      id: 989,
      word: "QIncha'",
      name: "QIncha' (n.) Krincha, Krencha, type of animal"
   }, 
   {
      id: 990,
      word: "QIp",
      name: "QIp (v.) be stupid"
   }, 
   {
      id: 991,
      word: "QIq",
      name: "QIq (v.) draw, pull out (weapon, tool, instrument)"
   }, 
   {
      id: 992,
      word: "QIt",
      name: "QIt (adverb) slowly"
   }, 
   {
      id: 993,
      word: "QIv",
      name: "QIv (v.) be inferior"
   }, 
   {
      id: 994,
      word: "Qa",
      name: "Qa (v.) grow, increase in size"
   }, 
   {
      id: 995,
      word: "Qa'",
      name: "Qa' (n.) kkha, type of animal"
   }, 
   {
      id: 996,
      word: "Qa'Hom",
      name: "Qa'Hom (n.) kha'hom, type of little animal"
   }, 
   {
      id: 997,
      word: "Qa'raj",
      name: "Qa'raj (n.) ka'raj, type of animal"
   }, 
   {
      id: 998,
      word: "QaD",
      name: "QaD (v.) be dry, be dried out"
   }, 
   {
      id: 999,
      word: "QaD",
      name: "QaD (v.) be safe (slang), be protected (slang)"
   }, 
   {
      id: 1000,
      word: "QaH",
      name: "QaH (n.) help"
   }, 
   {
      id: 1001,
      word: "QaH",
      name: "QaH (v.) help, aid"
   }, 
   {
      id: 1002,
      word: "QaHa'",
      name: "QaHa' (v.) shrink, return to original size"
   }, 
   {
      id: 1003,
      word: "QaQ",
      name: "QaQ (v.) be good"
   }, 
   {
      id: 1004,
      word: "QaS",
      name: "QaS (p.n.) Kras"
   }, 
   {
      id: 1005,
      word: "QaS",
      name: "QaS (n.) troops"
   }, 
   {
      id: 1006,
      word: "QaS DevwI'",
      name: "QaS DevwI' (n.) troop commander, troop leader"
   }, 
   {
      id: 1007,
      word: "Qab",
      name: "Qab (n.) theragen"
   }, 
   {
      id: 1008,
      word: "Qach",
      name: "Qach (v.) wield, swing (a weapon)"
   }, 
   {
      id: 1009,
      word: "Qagh",
      name: "Qagh (v.) err, be mistaken, make a mistake"
   }, 
   {
      id: 1010,
      word: "Qagh",
      name: "Qagh (n.) error, mistake"
   }, 
   {
      id: 1011,
      word: "Qaj",
      name: "Qaj (n.) kradge, type of animal"
   }, 
   {
      id: 1012,
      word: "Qaj tlhuQ",
      name: "Qaj tlhuQ (n.) type of food, kradge tail"
   }, 
   {
      id: 1013,
      word: "Qajnav",
      name: "Qajnav (n.) diaper, nappy"
   }, 
   {
      id: 1014,
      word: "Qal",
      name: "Qal (v.) swim"
   }, 
   {
      id: 1015,
      word: "QalwI' Sut",
      name: "QalwI' Sut (n.) swimsuit"
   }, 
   {
      id: 1016,
      word: "Qam",
      name: "Qam (v.) stand"
   }, 
   {
      id: 1017,
      word: "Qan",
      name: "Qan (v.) protect"
   }, 
   {
      id: 1018,
      word: "Qang",
      name: "Qang (n.) chancellor"
   }, 
   {
      id: 1019,
      word: "Qanqor",
      name: "Qanqor (p.n.) Krankor"
   }, 
   {
      id: 1020,
      word: "Qap",
      name: "Qap (v.) operate, be in operation"
   }, 
   {
      id: 1021,
      word: "Qap",
      name: "Qap (v.) work, function, succeed, win"
   }, 
   {
      id: 1022,
      word: "Qapla'",
      name: "Qapla' (n.) success"
   }, 
   {
      id: 1023,
      word: "QaplaStep",
      name: "QaplaStep (n.) spool, reel, spindle"
   }, 
   {
      id: 1024,
      word: "QapmIw",
      name: "QapmIw (n.) career"
   }, 
   {
      id: 1025,
      word: "QapwI' mIr",
      name: "QapwI' mIr (n.) winning streak"
   }, 
   {
      id: 1026,
      word: "Qaq",
      name: "Qaq (v.) behave falsely honorably, behave in a falsely honorable manner"
   }, 
   {
      id: 1027,
      word: "Qargh",
      name: "Qargh (n.) fissure"
   }, 
   {
      id: 1028,
      word: "Qat",
      name: "Qat (v.) be popular"
   }, 
   {
      id: 1029,
      word: "Qatlh",
      name: "Qatlh (v.) be complex"
   }, 
   {
      id: 1030,
      word: "Qatlh",
      name: "Qatlh (v.) be difficult"
   }, 
   {
      id: 1031,
      word: "Qav",
      name: "Qav (v.) be final, be last"
   }, 
   {
      id: 1032,
      word: "Qaw",
      name: "Qaw (v.) rub"
   }, 
   {
      id: 1033,
      word: "Qaw'",
      name: "Qaw' (v.) destroy"
   }, 
   {
      id: 1034,
      word: "Qay",
      name: "Qay (v.) transfer"
   }, 
   {
      id: 1035,
      word: "Qay'",
      name: "Qay' (v.) blow one's top"
   }, 
   {
      id: 1036,
      word: "Qay'",
      name: "Qay' (v.) use the little toe"
   }, 
   {
      id: 1037,
      word: "Qay'mol",
      name: "Qay'mol (n.) puzzle"
   }, 
   {
      id: 1038,
      word: "Qay'mol teSra'",
      name: "Qay'mol teSra' (n.) puzzle piece (referring to a jigsaw puzzle)"
   }, 
   {
      id: 1039,
      word: "Qay'wI'",
      name: "Qay'wI' (n.) little toe, fifth toe"
   }, 
   {
      id: 1040,
      word: "Qe'",
      name: "Qe' (n.) restaurant"
   }, 
   {
      id: 1041,
      word: "Qe' much",
      name: "Qe' much (n.) cabaret (show)"
   }, 
   {
      id: 1042,
      word: "Qe'jIj",
      name: "Qe'jIj (n.) catalyst"
   }, 
   {
      id: 1043,
      word: "QeD",
      name: "QeD (n.) science"
   }, 
   {
      id: 1044,
      word: "QeDpIn",
      name: "QeDpIn (n.) science officer"
   }, 
   {
      id: 1045,
      word: "QeH",
      name: "QeH (n.) anger"
   }, 
   {
      id: 1046,
      word: "QeH",
      name: "QeH (v.) be angry, be mad"
   }, 
   {
      id: 1047,
      word: "Qeb",
      name: "Qeb (n.) ponytail holder (slang)"
   }, 
   {
      id: 1048,
      word: "Qeb",
      name: "Qeb (n.) ring (for finger, jewelry)"
   }, 
   {
      id: 1049,
      word: "Qechjem",
      name: "Qechjem (n.) stem, stalk"
   }, 
   {
      id: 1050,
      word: "Qechjem'a'",
      name: "Qechjem'a' (n.) trunk (of tree)"
   }, 
   {
      id: 1051,
      word: "Qej",
      name: "Qej (v.) cherish, value"
   }, 
   {
      id: 1052,
      word: "Qel",
      name: "Qel (n.) doctor, physician"
   }, 
   {
      id: 1053,
      word: "Qel",
      name: "Qel (p.n.) Krell"
   }, 
   {
      id: 1054,
      word: "Qem",
      name: "Qem (v.) holster, sheathe, pocket (weapon, tool, instrument)"
   }, 
   {
      id: 1055,
      word: "QemjIq",
      name: "QemjIq (n.) hole"
   }, 
   {
      id: 1056,
      word: "Qen",
      name: "Qen (v.) be naked, nude"
   }, 
   {
      id: 1057,
      word: "Qenno'",
      name: "Qenno' (n.) pulp (of a plant)"
   }, 
   {
      id: 1058,
      word: "Qenvob",
      name: "Qenvob (n.) ground-up, dried-up mixture for brewing tea, tea-brewing mixture"
   }, 
   {
      id: 1059,
      word: "Qep",
      name: "Qep (v.) be anxious (about)"
   }, 
   {
      id: 1060,
      word: "Qep'It",
      name: "Qep'It (n.) any gas produced by a body"
   }, 
   {
      id: 1061,
      word: "Qeq",
      name: "Qeq (v.) aim"
   }, 
   {
      id: 1062,
      word: "Qeq",
      name: "Qeq (v.) aim (at)"
   }, 
   {
      id: 1063,
      word: "Qer",
      name: "Qer (v.) revert (to)"
   }, 
   {
      id: 1064,
      word: "QermoH",
      name: "QermoH (v.) recycle"
   }, 
   {
      id: 1065,
      word: "Qev",
      name: "Qev (v.) stew"
   }, 
   {
      id: 1066,
      word: "Qey",
      name: "Qey (v.) be tight"
   }, 
   {
      id: 1067,
      word: "Qey'",
      name: "Qey' (v.) be cool (temperature)"
   }, 
   {
      id: 1068,
      word: "QeyHa'",
      name: "QeyHa' (v.) be loose"
   }, 
   {
      id: 1069,
      word: "QeyHa'moH",
      name: "QeyHa'moH (v.) loosen"
   }, 
   {
      id: 1070,
      word: "Qeygh",
      name: "Qeygh (p.n.) Craig Altenburg"
   }, 
   {
      id: 1071,
      word: "QeymoH",
      name: "QeymoH (v.) tighten"
   }, 
   {
      id: 1072,
      word: "QlojmIt",
      name: "QlojmIt (p.n.) Adam Winnington"
   }, 
   {
      id: 1073,
      word: "Qo",
      name: "Qo (n.) tendency, propensity"
   }, 
   {
      id: 1074,
      word: "Qo'",
      name: "Qo' (vsr) don't!, won't"
   }, 
   {
      id: 1075,
      word: "Qo'",
      name: "Qo' (exclamation) no, I won't, I refuse, I disagree"
   }, 
   {
      id: 1076,
      word: "Qo'noS",
      name: "Qo'noS (n.) Kronos"
   }, 
   {
      id: 1077,
      word: "QoD",
      name: "QoD (v.) maneuver (engines)"
   }, 
   {
      id: 1078,
      word: "QoH",
      name: "QoH (v.) tap"
   }, 
   {
      id: 1079,
      word: "QoQ",
      name: "QoQ (n.) music"
   }, 
   {
      id: 1080,
      word: "QoQ jan",
      name: "QoQ jan (n.) musical instrument"
   }, 
   {
      id: 1081,
      word: "QoS",
      name: "QoS (v.) be sorry"
   }, 
   {
      id: 1082,
      word: "Qob",
      name: "Qob (v.) be dangerous"
   }, 
   {
      id: 1083,
      word: "Qob",
      name: "Qob (p.n.) Bill Willmerdinger/Bill Hedrick"
   }, 
   {
      id: 1084,
      word: "Qob",
      name: "Qob (n.) danger"
   }, 
   {
      id: 1085,
      word: "Qoch",
      name: "Qoch (v.) disagree"
   }, 
   {
      id: 1086,
      word: "Qochbe'",
      name: "Qochbe' (v.) agree"
   }, 
   {
      id: 1087,
      word: "Qogh",
      name: "Qogh (n.) kkhog, type of animal"
   }, 
   {
      id: 1088,
      word: "Qogh",
      name: "Qogh (p.n.) Adam Walker's old name"
   }, 
   {
      id: 1089,
      word: "QoghIj",
      name: "QoghIj (n.) brain (organ)"
   }, 
   {
      id: 1090,
      word: "Qoghogh",
      name: "Qoghogh (v.) snort"
   }, 
   {
      id: 1091,
      word: "Qoj",
      name: "Qoj (v.) make war"
   }, 
   {
      id: 1092,
      word: "Qol",
      name: "Qol (v.) beam away"
   }, 
   {
      id: 1093,
      word: "Qom",
      name: "Qom (v.) be hazardous (slang), be perilous (slang), be treacherous (slang)"
   }, 
   {
      id: 1094,
      word: "Qom",
      name: "Qom (v.) experience an earthquake or tremor"
   }, 
   {
      id: 1095,
      word: "Qong",
      name: "Qong (v.) sleep"
   }, 
   {
      id: 1096,
      word: "QongDaq",
      name: "QongDaq (n.) bed"
   }, 
   {
      id: 1097,
      word: "QongDaq 'echlet tun",
      name: "QongDaq 'echlet tun (n.) mattress"
   }, 
   {
      id: 1098,
      word: "QongDaq buq'a'",
      name: "QongDaq buq'a' (n.) sleeping bag"
   }, 
   {
      id: 1099,
      word: "QongDaq buqHom",
      name: "QongDaq buqHom (n.) pillow"
   }, 
   {
      id: 1100,
      word: "QongDaqDaq",
      name: "QongDaqDaq (n.) in bed"
   }, 
   {
      id: 1101,
      word: "QongmoH",
      name: "QongmoH (v.) extinguish fire, lit. put to sleep, cause to sleep"
   }, 
   {
      id: 1102,
      word: "QonoS",
      name: "QonoS (n.) journal, log"
   }, 
   {
      id: 1103,
      word: "Qop",
      name: "Qop (v.) be dead (referring to food) (slang)"
   }, 
   {
      id: 1104,
      word: "Qop",
      name: "Qop (v.) be worn out"
   }, 
   {
      id: 1105,
      word: "QopmoH",
      name: "QopmoH (v.) wear out"
   }, 
   {
      id: 1106,
      word: "Qor",
      name: "Qor (v.) fight, battle (very minor fight)"
   }, 
   {
      id: 1107,
      word: "Qorgh",
      name: "Qorgh (v.) take care of, care for"
   }, 
   {
      id: 1108,
      word: "Qorwagh",
      name: "Qorwagh (n.) window"
   }, 
   {
      id: 1109,
      word: "Qot",
      name: "Qot (v.) lie, recline"
   }, 
   {
      id: 1110,
      word: "Qotlh",
      name: "Qotlh (v.) disable"
   }, 
   {
      id: 1111,
      word: "Qotmagh",
      name: "Qotmagh (p.n.) Krotmag"
   }, 
   {
      id: 1112,
      word: "Qotmagh Sep",
      name: "Qotmagh Sep (n.) Krotmag region"
   }, 
   {
      id: 1113,
      word: "Qov",
      name: "Qov (p.n.) Robyn Stewart"
   }, 
   {
      id: 1114,
      word: "Qovpatlh",
      name: "Qovpatlh (exclamation) (curse) epithet, insult"
   }, 
   {
      id: 1115,
      word: "Qoy",
      name: "Qoy (v.) hear, listen to"
   }, 
   {
      id: 1116,
      word: "Qoy'",
      name: "Qoy' (v.) spill"
   }, 
   {
      id: 1117,
      word: "Qoyje'",
      name: "Qoyje' (n.) certificate, diploma"
   }, 
   {
      id: 1118,
      word: "QoylaHbe'",
      name: "QoylaHbe' (v.) deaf, is not able to hear"
   }, 
   {
      id: 1119,
      word: "Qoylu'taH",
      name: "Qoylu'taH (v.) the clock is ticking (idiomatically)"
   }, 
   {
      id: 1120,
      word: "Qu",
      name: "Qu (v.) cast (cast metal)"
   }, 
   {
      id: 1121,
      word: "Qu'",
      name: "Qu' (n.) duty, quest, mission, task, chore"
   }, 
   {
      id: 1122,
      word: "Qu' poH",
      name: "Qu' poH (n.) work/duty shift"
   }, 
   {
      id: 1123,
      word: "Qu'Hom",
      name: "Qu'Hom (n.) errand"
   }, 
   {
      id: 1124,
      word: "Qu'vatlh",
      name: "Qu'vatlh (exclamation) (curse) general invective"
   }, 
   {
      id: 1125,
      word: "QuD",
      name: "QuD (n.) insurrection"
   }, 
   {
      id: 1126,
      word: "QuH",
      name: "QuH (v.) attract"
   }, 
   {
      id: 1127,
      word: "QuHHa'",
      name: "QuHHa' (v.) repel"
   }, 
   {
      id: 1128,
      word: "QuQ",
      name: "QuQ (n.) engine"
   }, 
   {
      id: 1129,
      word: "QuS",
      name: "QuS (n.) conspiracy"
   }, 
   {
      id: 1130,
      word: "QuS",
      name: "QuS (v.) conspire"
   }, 
   {
      id: 1131,
      word: "Qub",
      name: "Qub (v.) think"
   }, 
   {
      id: 1132,
      word: "Quch",
      name: "Quch (v.) be happy"
   }, 
   {
      id: 1133,
      word: "Quch",
      name: "Quch (n.) forehead"
   }, 
   {
      id: 1134,
      word: "QuchHa'",
      name: "QuchHa' (v.) be unhappy"
   }, 
   {
      id: 1135,
      word: "Qugh",
      name: "Qugh (n.) disaster"
   }, 
   {
      id: 1136,
      word: "Qugh",
      name: "Qugh (p.n.) Kruge"
   }, 
   {
      id: 1137,
      word: "Quj",
      name: "Quj (n.) game"
   }, 
   {
      id: 1138,
      word: "Quj",
      name: "Quj (v.) play (a game)"
   }, 
   {
      id: 1139,
      word: "QujwI' lIw",
      name: "QujwI' lIw (n.) game token, player piece (lit. player stand-in)"
   }, 
   {
      id: 1140,
      word: "Qul",
      name: "Qul (v.) research"
   }, 
   {
      id: 1141,
      word: "Qulpa'",
      name: "Qulpa' (n.) research lab"
   }, 
   {
      id: 1142,
      word: "Qum",
      name: "Qum (v.) communicate"
   }, 
   {
      id: 1143,
      word: "Qum",
      name: "Qum (n.) communications, communication related technology"
   }, 
   {
      id: 1144,
      word: "QumeH ngaSwI'",
      name: "QumeH ngaSwI' (n.) mold (for casting)"
   }, 
   {
      id: 1145,
      word: "QumpIn",
      name: "QumpIn (n.) communications officer"
   }, 
   {
      id: 1146,
      word: "Qumran",
      name: "Qumran (n.) scroll (writing surface/paper)"
   }, 
   {
      id: 1147,
      word: "QumwI'",
      name: "QumwI' (n.) communicator, communications device"
   }, 
   {
      id: 1148,
      word: "Qun",
      name: "Qun (n.) god, supernatural being"
   }, 
   {
      id: 1149,
      word: "Qung",
      name: "Qung (v.) be rounded, blunt"
   }, 
   {
      id: 1150,
      word: "Qup",
      name: "Qup (v.) be young"
   }, 
   {
      id: 1151,
      word: "Qur",
      name: "Qur (n.) structure, organization, anatomy"
   }, 
   {
      id: 1152,
      word: "Qut",
      name: "Qut (v.) be vulgar"
   }, 
   {
      id: 1153,
      word: "Qutlh",
      name: "Qutlh (v.) support"
   }, 
   {
      id: 1154,
      word: "Quv",
      name: "Quv (n.) coordinates"
   }, 
   {
      id: 1155,
      word: "SID",
      name: "SID (n.) patient"
   }, 
   {
      id: 1156,
      word: "SIH",
      name: "SIH (v.) bend"
   }, 
   {
      id: 1157,
      word: "SIQ",
      name: "SIQ (v.) endure, bear"
   }, 
   {
      id: 1158,
      word: "SIQab'el",
      name: "SIQab'el (n.) Scrabble (the game)"
   }, 
   {
      id: 1159,
      word: "SIQwI'",
      name: "SIQwI' (n.) celebrant, recipient"
   }, 
   {
      id: 1160,
      word: "SIS",
      name: "SIS (v.) rain"
   }, 
   {
      id: 1161,
      word: "SIS yoD",
      name: "SIS yoD (n.) umbrella"
   }, 
   {
      id: 1162,
      word: "SIbDoH",
      name: "SIbDoH (n.) satellite"
   }, 
   {
      id: 1163,
      word: "SIbI'",
      name: "SIbI' (adverb) immediately"
   }, 
   {
      id: 1164,
      word: "SIbI'Ha'",
      name: "SIbI'Ha' (adverb) later, eventually"
   }, 
   {
      id: 1165,
      word: "SIch",
      name: "SIch (v.) reach"
   }, 
   {
      id: 1166,
      word: "SIchIyparIy",
      name: "SIchIyparIy (n.) Albania"
   }, 
   {
      id: 1167,
      word: "SIgh",
      name: "SIgh (v.) influence"
   }, 
   {
      id: 1168,
      word: "SIj",
      name: "SIj (v.) slit, be insightful (slang), be clever (slang)"
   }, 
   {
      id: 1169,
      word: "SIjwI'",
      name: "SIjwI' (n.) knife used for food preparation"
   }, 
   {
      id: 1170,
      word: "SIl",
      name: "SIl (v.) divert"
   }, 
   {
      id: 1171,
      word: "SIla'",
      name: "SIla' (n.) large mirror"
   }, 
   {
      id: 1172,
      word: "SIlove'nIya",
      name: "SIlove'nIya (n.) Slovenia"
   }, 
   {
      id: 1173,
      word: "SIlovenISqa'",
      name: "SIlovenISqa' (n.) Slovakia"
   }, 
   {
      id: 1174,
      word: "SIlreq",
      name: "SIlreq (p.n.) Silrek"
   }, 
   {
      id: 1175,
      word: "SIm",
      name: "SIm (v.) calculate"
   }, 
   {
      id: 1176,
      word: "SImbabwe",
      name: "SImbabwe (n.) Zimbabwe"
   }, 
   {
      id: 1177,
      word: "SImmIQ",
      name: "SImmIQ (n.) leaf salad"
   }, 
   {
      id: 1178,
      word: "SImroD",
      name: "SImroD (n.) power (physics)"
   }, 
   {
      id: 1179,
      word: "SImyon",
      name: "SImyon (n.) degree, unit of measure for temperature"
   }, 
   {
      id: 1180,
      word: "SInDarIn Hol",
      name: "SInDarIn Hol (n.) Sindarin"
   }, 
   {
      id: 1181,
      word: "SInan",
      name: "SInan (n.) compass"
   }, 
   {
      id: 1182,
      word: "SIngapor",
      name: "SIngapor (n.) Singapore"
   }, 
   {
      id: 1183,
      word: "SIntlher",
      name: "SIntlher (n.) ancient extinct animal, dinosaur"
   }, 
   {
      id: 1184,
      word: "SIp",
      name: "SIp (n.) gas"
   }, 
   {
      id: 1185,
      word: "SIp",
      name: "SIp (v.) infiltrate"
   }, 
   {
      id: 1186,
      word: "SIpoq",
      name: "SIpoq (p.n.) Spock"
   }, 
   {
      id: 1187,
      word: "SIprat",
      name: "SIprat (n.) bristle, stiff hair or filament"
   }, 
   {
      id: 1188,
      word: "SIq",
      name: "SIq (v.) use the first (index) finger"
   }, 
   {
      id: 1189,
      word: "SIqanDInavya'",
      name: "SIqanDInavya' (n.) Scandinavia"
   }, 
   {
      id: 1190,
      word: "SIqnaSwaq",
      name: "SIqnaSwaq (n.) elf, gnome, a type of small person"
   }, 
   {
      id: 1191,
      word: "SIqotlan",
      name: "SIqotlan (p.n.) Scotland"
   }, 
   {
      id: 1192,
      word: "SIqral",
      name: "SIqral (p.n.) Skral"
   }, 
   {
      id: 1193,
      word: "SIqwI'",
      name: "SIqwI' (n.) first finger, index finger"
   }, 
   {
      id: 1194,
      word: "SIr",
      name: "SIr (v.) be unique, be unprecedented"
   }, 
   {
      id: 1195,
      word: "SIr'eq",
      name: "SIr'eq (n.) unit of radioactive decay"
   }, 
   {
      id: 1196,
      word: "SIr'o'",
      name: "SIr'o' (n.) network, web, mesh, lattice, nexus"
   }, 
   {
      id: 1197,
      word: "SIrHagh",
      name: "SIrHagh (n.) slang form of buffon, laughingstock"
   }, 
   {
      id: 1198,
      word: "SIrHugh",
      name: "SIrHugh (n.) buffon, laughingstock"
   }, 
   {
      id: 1199,
      word: "SIrIl",
      name: "SIrIl (n.) hook"
   }, 
   {
      id: 1200,
      word: "SIrIylangqa",
      name: "SIrIylangqa (n.) Sri Lanka"
   }, 
   {
      id: 1201,
      word: "SIrbIya'",
      name: "SIrbIya' (n.) Serbia"
   }, 
   {
      id: 1202,
      word: "SIrgh",
      name: "SIrgh (n.) string, thread, filament"
   }, 
   {
      id: 1203,
      word: "SIrgh 'aplom",
      name: "SIrgh 'aplom (n.) bead"
   }, 
   {
      id: 1204,
      word: "SIrgh 'o'lav",
      name: "SIrgh 'o'lav (n.) snare drum"
   }, 
   {
      id: 1205,
      word: "SIrgh raghghan",
      name: "SIrgh raghghan (n.) puppet"
   }, 
   {
      id: 1206,
      word: "SIrlIy",
      name: "SIrlIy (n.) silver (element)"
   }, 
   {
      id: 1207,
      word: "SIrlop",
      name: "SIrlop (n.) constant"
   }, 
   {
      id: 1208,
      word: "SIryoD",
      name: "SIryoD (n.) body armor (old form) (prefered by Maltz)"
   }, 
   {
      id: 1209,
      word: "SIv",
      name: "SIv (v.) wonder"
   }, 
   {
      id: 1210,
      word: "SIvan",
      name: "SIvan (p.n.) Siobhan Gormley"
   }, 
   {
      id: 1211,
      word: "SIye'ralIyon",
      name: "SIye'ralIyon (n.) Sierra Leone"
   }, 
   {
      id: 1212,
      word: "SIyech",
      name: "SIyech (n.) cane, reed"
   }, 
   {
      id: 1213,
      word: "SIylaw'",
      name: "SIylaw' (n.) hypha"
   }, 
   {
      id: 1214,
      word: "Sa",
      name: "Sa (vp) I-you (pl)"
   }, 
   {
      id: 1215,
      word: "Sa",
      name: "Sa (v.) rhyme with"
   }, 
   {
      id: 1216,
      word: "Sa'",
      name: "Sa' (n.) general (rank)"
   }, 
   {
      id: 1217,
      word: "Sa'Hut",
      name: "Sa'Hut (n.) ass, rear end, buttocks, trunk/boot of vehicle"
   }, 
   {
      id: 1218,
      word: "Sa'Qej Sep",
      name: "Sa'Qej Sep (n.) Sakrej region"
   }, 
   {
      id: 1219,
      word: "SaD",
      name: "SaD (number) thousand"
   }, 
   {
      id: 1220,
      word: "SaDSaghan",
      name: "SaDSaghan (number) trillion"
   }, 
   {
      id: 1221,
      word: "SaDbIp",
      name: "SaDbIp (number) 100 million"
   }, 
   {
      id: 1222,
      word: "SaH",
      name: "SaH (v.) be present (not absent)"
   }, 
   {
      id: 1223,
      word: "SaH",
      name: "SaH (v.) care (about)"
   }, 
   {
      id: 1224,
      word: "SaHHa'",
      name: "SaHHa' (v.) be unconcerned (about)"
   }, 
   {
      id: 1225,
      word: "SaHHa'ghach",
      name: "SaHHa'ghach (n.) disinterest"
   }, 
   {
      id: 1226,
      word: "SaHa'ra'",
      name: "SaHa'ra' (n.) Sahara (Earth desert)"
   }, 
   {
      id: 1227,
      word: "SaQ",
      name: "SaQ (v.) cry"
   }, 
   {
      id: 1228,
      word: "SaQatvelo'",
      name: "SaQatvelo' (n.) Georgia"
   }, 
   {
      id: 1229,
      word: "SaS",
      name: "SaS (v.) be horizontal, be shallow (slang), be superficial (slang), be uncritical (slang), be unfortunate (slang), be not good (slang)"
   }, 
   {
      id: 1230,
      word: "Sab",
      name: "Sab (v.) decline, deteriorate"
   }, 
   {
      id: 1231,
      word: "Sach",
      name: "Sach (v.) be amplified, fleshed out, elaborated, increased in scope, etc."
   }, 
   {
      id: 1232,
      word: "Sach",
      name: "Sach (v.) expand"
   }, 
   {
      id: 1233,
      word: "Sagh",
      name: "Sagh (v.) be serious"
   }, 
   {
      id: 1234,
      word: "Saghan",
      name: "Saghan (number) billion"
   }, 
   {
      id: 1235,
      word: "Saj",
      name: "Saj (n.) pet"
   }, 
   {
      id: 1236,
      word: "Sal",
      name: "Sal (v.) ascend"
   }, 
   {
      id: 1237,
      word: "Sam",
      name: "Sam (v.) locate, seek and find"
   }, 
   {
      id: 1238,
      word: "Sam",
      name: "Sam (n.) shawm"
   }, 
   {
      id: 1239,
      word: "SambIya",
      name: "SambIya (n.) Zambia"
   }, 
   {
      id: 1240,
      word: "SambaSa Hol",
      name: "SambaSa Hol (n.) Sambahsa"
   }, 
   {
      id: 1241,
      word: "SammarI'no",
      name: "SammarI'no (n.) San Marino"
   }, 
   {
      id: 1242,
      word: "Sammowa",
      name: "Sammowa (n.) Samoa"
   }, 
   {
      id: 1243,
      word: "San",
      name: "San (n.) fate, destiny"
   }, 
   {
      id: 1244,
      word: "San'emDer",
      name: "San'emDer (n.) plant"
   }, 
   {
      id: 1245,
      word: "San'on",
      name: "San'on (n.) bit"
   }, 
   {
      id: 1246,
      word: "SanDIy",
      name: "SanDIy (n.) scar (result of a wound received in the course of fighting/battling)"
   }, 
   {
      id: 1247,
      word: "SanID",
      name: "SanID (number) thousand"
   }, 
   {
      id: 1248,
      word: "SanIDSaghan",
      name: "SanIDSaghan (number) trillion"
   }, 
   {
      id: 1249,
      word: "SanIDbIp",
      name: "SanIDbIp (number) 100 million"
   }, 
   {
      id: 1250,
      word: "SanQIb",
      name: "SanQIb (p.n.) Christine Tschoegl"
   }, 
   {
      id: 1251,
      word: "Sang",
      name: "Sang (v.) obliterate"
   }, 
   {
      id: 1252,
      word: "SanmIr",
      name: "SanmIr (n.) spore"
   }, 
   {
      id: 1253,
      word: "Santay",
      name: "Santay (n.) honorific zantai"
   }, 
   {
      id: 1254,
      word: "Santlhar",
      name: "Santlhar (n.) silicon"
   }, 
   {
      id: 1255,
      word: "Sap",
      name: "Sap (v.) volunteer"
   }, 
   {
      id: 1256,
      word: "Saq",
      name: "Saq (v.) land"
   }, 
   {
      id: 1257,
      word: "SaqDaq",
      name: "SaqDaq (n.) landing site"
   }, 
   {
      id: 1258,
      word: "SaqSub",
      name: "SaqSub (p.n.) Saq'sub"
   }, 
   {
      id: 1259,
      word: "SaqSubngan",
      name: "SaqSubngan (p.n.) Inhabitant of Saq'sub"
   }, 
   {
      id: 1260,
      word: "Saqghom",
      name: "Saqghom (n.) landing party"
   }, 
   {
      id: 1261,
      word: "Saqjan",
      name: "Saqjan (n.) landing gear"
   }, 
   {
      id: 1262,
      word: "Sar",
      name: "Sar (v.) be varied, be various"
   }, 
   {
      id: 1263,
      word: "Sar",
      name: "Sar (n.) variety"
   }, 
   {
      id: 1264,
      word: "Sarbruqen",
      name: "Sarbruqen (n.) Saarbrücken (Germany)"
   }, 
   {
      id: 1265,
      word: "Sargh",
      name: "Sargh (n.) sark, horse-like animal"
   }, 
   {
      id: 1266,
      word: "Sat",
      name: "Sat (v.) be stuck (in a situation)"
   }, 
   {
      id: 1267,
      word: "Satlh",
      name: "Satlh (n.) agriculture"
   }, 
   {
      id: 1268,
      word: "Savvanwer",
      name: "Savvanwer (n.) nonave"
   }, 
   {
      id: 1269,
      word: "Saw",
      name: "Saw (v.) marry (husband does this)"
   }, 
   {
      id: 1270,
      word: "Saw'",
      name: "Saw' (v.) have a depth of"
   }, 
   {
      id: 1271,
      word: "Sawlay",
      name: "Sawlay (n.) gesture"
   }, 
   {
      id: 1272,
      word: "Sawqe'",
      name: "Sawqe' (n.) nugget, chunk, clump"
   }, 
   {
      id: 1273,
      word: "SawtavrI'qa'",
      name: "SawtavrI'qa' (n.) South Africa"
   }, 
   {
      id: 1274,
      word: "Say'",
      name: "Say' (v.) be clean"
   }, 
   {
      id: 1275,
      word: "Say'qIS",
      name: "Say'qIS (n.) dust, powder"
   }, 
   {
      id: 1276,
      word: "Say'qu'",
      name: "Say'qu' (v.) be sterile"
   }, 
   {
      id: 1277,
      word: "Say'qu'moH",
      name: "Say'qu'moH (v.) sterilize"
   }, 
   {
      id: 1278,
      word: "SayDeq",
      name: "SayDeq (n.) surplus"
   }, 
   {
      id: 1279,
      word: "Se'",
      name: "Se' (n.) frequency (radio)"
   }, 
   {
      id: 1280,
      word: "Se'mon",
      name: "Se'mon (n.) salmon"
   }, 
   {
      id: 1281,
      word: "Se'tu'",
      name: "Se'tu' (n.) saucepan"
   }, 
   {
      id: 1282,
      word: "Se'vIr",
      name: "Se'vIr (n.) publication"
   }, 
   {
      id: 1283,
      word: "Se'vIr malja'",
      name: "Se'vIr malja' (n.) publishing house"
   }, 
   {
      id: 1284,
      word: "Se'vernamaqeDonya'",
      name: "Se'vernamaqeDonya' (n.) North Macedonia"
   }, 
   {
      id: 1285,
      word: "SeD",
      name: "SeD (v.) drive (a land vehicle)"
   }, 
   {
      id: 1286,
      word: "SeDveq",
      name: "SeDveq (n.) barbed spearhead"
   }, 
   {
      id: 1287,
      word: "SeH",
      name: "SeH (v.) control"
   }, 
   {
      id: 1288,
      word: "SeH'e'",
      name: "SeH'e' (n.) palm tree"
   }, 
   {
      id: 1289,
      word: "SeHjan",
      name: "SeHjan (n.) control device, controller device"
   }, 
   {
      id: 1290,
      word: "SeHlaw",
      name: "SeHlaw (n.) control panel"
   }, 
   {
      id: 1291,
      word: "SeQ",
      name: "SeQ (v.) be formal, be ritualistic, be ceremonial"
   }, 
   {
      id: 1292,
      word: "SeQpIr",
      name: "SeQpIr (p.n.) Shakespeare"
   }, 
   {
      id: 1293,
      word: "SeS",
      name: "SeS (n.) steam"
   }, 
   {
      id: 1294,
      word: "SeSor",
      name: "SeSor (n.) subject"
   }, 
   {
      id: 1295,
      word: "Sech",
      name: "Sech (n.) torch"
   }, 
   {
      id: 1296,
      word: "See notes",
      name: "See notes (Phrase) be relentless, indefatigable"
   }, 
   {
      id: 1297,
      word: "Segh",
      name: "Segh (n.) race, type, sort, class"
   }, 
   {
      id: 1298,
      word: "SemI'tIS Hol",
      name: "SemI'tIS Hol (n.) Semitish"
   }, 
   {
      id: 1299,
      word: "Sen",
      name: "Sen (v.) use the thumb, scoff (slang)"
   }, 
   {
      id: 1300,
      word: "SenDeq",
      name: "SenDeq (n.) twin"
   }, 
   {
      id: 1301,
      word: "Seneghal",
      name: "Seneghal (n.) Senegal"
   }, 
   {
      id: 1302,
      word: "Seng",
      name: "Seng (v.) cause trouble"
   }, 
   {
      id: 1303,
      word: "Seng",
      name: "Seng (n.) trouble"
   }, 
   {
      id: 1304,
      word: "Senjorgh",
      name: "Senjorgh (n.) grenade"
   }, 
   {
      id: 1305,
      word: "SenwI'",
      name: "SenwI' (n.) thumb"
   }, 
   {
      id: 1306,
      word: "SenwI' rIlwI' je",
      name: "SenwI' rIlwI' je (n.) everybody (idiomatic phrase)"
   }, 
   {
      id: 1307,
      word: "Sep",
      name: "Sep (v.) breed"
   }, 
   {
      id: 1308,
      word: "Sep",
      name: "Sep (n.) region"
   }, 
   {
      id: 1309,
      word: "Sep Hol Sar",
      name: "Sep Hol Sar (n.) Regional dialect"
   }, 
   {
      id: 1310,
      word: "SepHa'",
      name: "SepHa' (v.) root, take a root"
   }, 
   {
      id: 1311,
      word: "Separ",
      name: "Separ (n.) type of gemstone"
   }, 
   {
      id: 1312,
      word: "Seq",
      name: "Seq (n.) fault (seismic)"
   }, 
   {
      id: 1313,
      word: "Seqram",
      name: "Seqram (p.n.) Mark E. Shoulson aka ~mark"
   }, 
   {
      id: 1314,
      word: "Ser",
      name: "Ser (n.) progress"
   }, 
   {
      id: 1315,
      word: "SermanyuQ",
      name: "SermanyuQ (n.) Sherman's Planet"
   }, 
   {
      id: 1316,
      word: "Serrum",
      name: "Serrum (n.) earwax"
   }, 
   {
      id: 1317,
      word: "Setlhlo'",
      name: "Setlhlo' (n.) arsenic"
   }, 
   {
      id: 1318,
      word: "SetqIn",
      name: "SetqIn (adverb) alternatively, instead, rather"
   }, 
   {
      id: 1319,
      word: "Sev",
      name: "Sev (n.) bandage"
   }, 
   {
      id: 1320,
      word: "Sev",
      name: "Sev (v.) contain (an enemy)"
   }, 
   {
      id: 1321,
      word: "Sey",
      name: "Sey (v.) be excited"
   }, 
   {
      id: 1322,
      word: "SeymoH",
      name: "SeymoH (v.) excite"
   }, 
   {
      id: 1323,
      word: "So'",
      name: "So' (v.) hide, cloak"
   }, 
   {
      id: 1324,
      word: "So'HIp",
      name: "So'HIp (n.) stealth armor"
   }, 
   {
      id: 1325,
      word: "So'chIm",
      name: "So'chIm (n.) soh-chim, godparent"
   }, 
   {
      id: 1326,
      word: "So'mIS Hol",
      name: "So'mIS Hol (n.) Somish"
   }, 
   {
      id: 1327,
      word: "So'wI'",
      name: "So'wI' (n.) cloaking device"
   }, 
   {
      id: 1328,
      word: "SoD",
      name: "SoD (n.) flood"
   }, 
   {
      id: 1329,
      word: "SoD",
      name: "SoD (v.) flood"
   }, 
   {
      id: 1330,
      word: "SoH",
      name: "SoH (pronoun) you"
   }, 
   {
      id: 1331,
      word: "SoQ",
      name: "SoQ (v.) be closed, be shut"
   }, 
   {
      id: 1332,
      word: "SoQ",
      name: "SoQ (n.) speech, lecture, address"
   }, 
   {
      id: 1333,
      word: "SoQmoH",
      name: "SoQmoH (v.) close, shut"
   }, 
   {
      id: 1334,
      word: "SoS",
      name: "SoS (n.) mother"
   }, 
   {
      id: 1335,
      word: "SoSbor",
      name: "SoSbor (n.) core"
   }, 
   {
      id: 1336,
      word: "SoSbor'a'",
      name: "SoSbor'a' (n.) main core"
   }, 
   {
      id: 1337,
      word: "SoSnI'",
      name: "SoSnI' (n.) grandmother"
   }, 
   {
      id: 1338,
      word: "Soch",
      name: "Soch (number) seven, 7"
   }, 
   {
      id: 1339,
      word: "Soch",
      name: "Soch (n.) seventh tone of nonatonic musical scale"
   }, 
   {
      id: 1340,
      word: "Sogh",
      name: "Sogh (n.) lieutenant"
   }, 
   {
      id: 1341,
      word: "Soj",
      name: "Soj (n.) food"
   }, 
   {
      id: 1342,
      word: "Soj",
      name: "Soj (n.) matter, concern, affair (idiomatic)"
   }, 
   {
      id: 1343,
      word: "Soj naQmey",
      name: "Soj naQmey (n.) chopsticks"
   }, 
   {
      id: 1344,
      word: "Soj qub",
      name: "Soj qub (n.) haute cuisine"
   }, 
   {
      id: 1345,
      word: "Sol",
      name: "Sol (v.) quarrel"
   }, 
   {
      id: 1346,
      word: "SolDeS",
      name: "SolDeS (n.) sail"
   }, 
   {
      id: 1347,
      word: "SolbIS",
      name: "SolbIS (n.) whale, dolphin, porpoise"
   }, 
   {
      id: 1348,
      word: "SolreySol Hol",
      name: "SolreySol Hol (n.) Solresol"
   }, 
   {
      id: 1349,
      word: "Solrogh",
      name: "Solrogh (n.) guardrail, banister"
   }, 
   {
      id: 1350,
      word: "Som",
      name: "Som (n.) hull"
   }, 
   {
      id: 1351,
      word: "Soma'lIya",
      name: "Soma'lIya (n.) Somalia"
   }, 
   {
      id: 1352,
      word: "SommI'",
      name: "SommI' (n.) tool, implement, instrument"
   }, 
   {
      id: 1353,
      word: "Somraw",
      name: "Somraw (n.) muscle"
   }, 
   {
      id: 1354,
      word: "Son",
      name: "Son (v.) relieve"
   }, 
   {
      id: 1355,
      word: "SonchIy",
      name: "SonchIy (n.) death ritual (for a leader)"
   }, 
   {
      id: 1356,
      word: "Sonme'",
      name: "Sonme' (n.) set, group, party"
   }, 
   {
      id: 1357,
      word: "Sop",
      name: "Sop (v.) eat"
   }, 
   {
      id: 1358,
      word: "SopwI'pa'",
      name: "SopwI'pa' (n.) mess hall"
   }, 
   {
      id: 1359,
      word: "Soqra'tIS",
      name: "Soqra'tIS (p.n.) Steve Weaver"
   }, 
   {
      id: 1360,
      word: "Sor",
      name: "Sor (v.) speak literally"
   }, 
   {
      id: 1361,
      word: "Sor",
      name: "Sor (n.) tree"
   }, 
   {
      id: 1362,
      word: "Sor 'IventoH",
      name: "Sor 'IventoH (n.) slang for pine cone"
   }, 
   {
      id: 1363,
      word: "Sor DIr",
      name: "Sor DIr (n.) bark (of a tree)"
   }, 
   {
      id: 1364,
      word: "Sor Hap",
      name: "Sor Hap (n.) wood"
   }, 
   {
      id: 1365,
      word: "Sor Hap 'In",
      name: "Sor Hap 'In (n.) percussion instrument made of wood"
   }, 
   {
      id: 1366,
      word: "SorHa'",
      name: "SorHa' (v.) speak metaphorically"
   }, 
   {
      id: 1367,
      word: "Sorgh",
      name: "Sorgh (v.) sabotage"
   }, 
   {
      id: 1368,
      word: "Sorghmang ",
      name: "Sorghmang  (n.) sabotage"
   }, 
   {
      id: 1369,
      word: "Sornagh",
      name: "Sornagh (n.) coma"
   }, 
   {
      id: 1370,
      word: "Sorpuq",
      name: "Sorpuq (n.) copper (element)"
   }, 
   {
      id: 1371,
      word: "Sorya'",
      name: "Sorya' (n.) Sauria"
   }, 
   {
      id: 1372,
      word: "Sot",
      name: "Sot (v.) be distressed, be in distress"
   }, 
   {
      id: 1373,
      word: "Sotlaw'",
      name: "Sotlaw' (n.) distress call"
   }, 
   {
      id: 1374,
      word: "Sotlhqel",
      name: "Sotlhqel (n.) yolk"
   }, 
   {
      id: 1375,
      word: "Sov",
      name: "Sov (v.) know"
   }, 
   {
      id: 1376,
      word: "Sov",
      name: "Sov (n.) knowledge"
   }, 
   {
      id: 1377,
      word: "Soy'",
      name: "Soy' (v.) be awkward, not graceful"
   }, 
   {
      id: 1378,
      word: "Soy'",
      name: "Soy' (v.) be clumsy"
   }, 
   {
      id: 1379,
      word: "SraH",
      name: "SraH (p.n.) Sarah A. Stear"
   }, 
   {
      id: 1380,
      word: "Su",
      name: "Su (vp) you (pl)-"
   }, 
   {
      id: 1381,
      word: "Su'",
      name: "Su' (exclamation) ready, standing by"
   }, 
   {
      id: 1382,
      word: "Su'SIy",
      name: "Su'SIy (n.) sushi (loanword)"
   }, 
   {
      id: 1383,
      word: "Su'ghar SIrghmey",
      name: "Su'ghar SIrghmey (n.) cotton candy"
   }, 
   {
      id: 1384,
      word: "Su'ghar qut",
      name: "Su'ghar qut (n.) sugar"
   }, 
   {
      id: 1385,
      word: "Su'ghar qutmey",
      name: "Su'ghar qutmey (n.) sugar"
   }, 
   {
      id: 1386,
      word: "Su'lop",
      name: "Su'lop (n.) type of food, Soolop"
   }, 
   {
      id: 1387,
      word: "Su'nIm",
      name: "Su'nIm (n.) raised profile, ridges, pattern (as in fingerprints, tires, shoe tread)"
   }, 
   {
      id: 1388,
      word: "Su'roq",
      name: "Su'roq (n.) building floor, level"
   }, 
   {
      id: 1389,
      word: "Su'roq chab",
      name: "Su'roq chab (n.) cake with layers, tart"
   }, 
   {
      id: 1390,
      word: "Su'wIn",
      name: "Su'wIn (n.) large whistle (hand-held device) with a deep sound"
   }, 
   {
      id: 1391,
      word: "Su'wan ghew",
      name: "Su'wan ghew (n.) butterfly"
   }, 
   {
      id: 1392,
      word: "SuD",
      name: "SuD (v.) be green, be blue, be yellow"
   }, 
   {
      id: 1393,
      word: "SuD",
      name: "SuD (v.) gamble, take a chance, take a risk"
   }, 
   {
      id: 1394,
      word: "SuDan",
      name: "SuDan (n.) Sudan"
   }, 
   {
      id: 1395,
      word: "SuH",
      name: "SuH (exclamation) ready, standing by"
   }, 
   {
      id: 1396,
      word: "SuQ",
      name: "SuQ (v.) be toxic"
   }, 
   {
      id: 1397,
      word: "SuS",
      name: "SuS (v.) blow (into wind instrument) to produce sound, blow out, blow at"
   }, 
   {
      id: 1398,
      word: "SuS",
      name: "SuS (n.) wind, breeze"
   }, 
   {
      id: 1399,
      word: "SuS mIjDang",
      name: "SuS mIjDang (n.) fan, handheld fan"
   }, 
   {
      id: 1400,
      word: "SuSDeq",
      name: "SuSDeq (n.) windbag, bellows (instrument)"
   }, 
   {
      id: 1401,
      word: "SuStel",
      name: "SuStel (p.n.) David A. Trimboli"
   }, 
   {
      id: 1402,
      word: "Sub",
      name: "Sub (v.) be solid, be brave (slang), be heroic (slang), be bold (slang), be valiant (slang), be intrepid (slang)"
   }, 
   {
      id: 1403,
      word: "Sub",
      name: "Sub (n.) hero"
   }, 
   {
      id: 1404,
      word: "SubmaH",
      name: "SubmaH (n.) fraction, ratio"
   }, 
   {
      id: 1405,
      word: "Subpu' vaS",
      name: "Subpu' vaS (n.) Hall of Heroes"
   }, 
   {
      id: 1406,
      word: "Such",
      name: "Such (v.) visit"
   }, 
   {
      id: 1407,
      word: "Suchtuv",
      name: "Suchtuv (n.) dream, hallucination"
   }, 
   {
      id: 1408,
      word: "Sugh",
      name: "Sugh (v.) install (in office)"
   }, 
   {
      id: 1409,
      word: "Suj",
      name: "Suj (v.) disturb"
   }, 
   {
      id: 1410,
      word: "Sum",
      name: "Sum (v.) be near, be nearby"
   }, 
   {
      id: 1411,
      word: "Sumlugh",
      name: "Sumlugh (n.) definition"
   }, 
   {
      id: 1412,
      word: "Sun",
      name: "Sun (n.) discipline"
   }, 
   {
      id: 1413,
      word: "Sung",
      name: "Sung (n.) native"
   }, 
   {
      id: 1414,
      word: "Suntay'",
      name: "Suntay' (n.) pollen"
   }, 
   {
      id: 1415,
      word: "Sup",
      name: "Sup (v.) jump"
   }, 
   {
      id: 1416,
      word: "Sup",
      name: "Sup (n.) resource"
   }, 
   {
      id: 1417,
      word: "SupDIng",
      name: "SupDIng (n.) cotton-like plant"
   }, 
   {
      id: 1418,
      word: "Supghew",
      name: "Supghew (n.) type of stringed instrument"
   }, 
   {
      id: 1419,
      word: "Suq",
      name: "Suq (v.) acquire, obtain, get, gain"
   }, 
   {
      id: 1420,
      word: "SuqSIv",
      name: "SuqSIv (n.) core (of an apple, planet, sun, but not a group)"
   }, 
   {
      id: 1421,
      word: "Suqqa'",
      name: "Suqqa' (v.) prepare qud in a specific way"
   }, 
   {
      id: 1422,
      word: "SuqwIl",
      name: "SuqwIl (n.) hiss"
   }, 
   {
      id: 1423,
      word: "Sur",
      name: "Sur (v.) rinse"
   }, 
   {
      id: 1424,
      word: "SurIna'ma",
      name: "SurIna'ma (n.) Suriname"
   }, 
   {
      id: 1425,
      word: "Surchem",
      name: "Surchem (n.) force field"
   }, 
   {
      id: 1426,
      word: "Surgh",
      name: "Surgh (v.) skin"
   }, 
   {
      id: 1427,
      word: "Surma'",
      name: "Surma' (n.) force (physics concept)"
   }, 
   {
      id: 1428,
      word: "Surmen",
      name: "Surmen (n.) pressure"
   }, 
   {
      id: 1429,
      word: "Surya'",
      name: "Surya' (n.) Syria"
   }, 
   {
      id: 1430,
      word: "Sut",
      name: "Sut (n.) clothing"
   }, 
   {
      id: 1431,
      word: "Sut DeSwar",
      name: "Sut DeSwar (n.) wardrobe, clothing closet"
   }, 
   {
      id: 1432,
      word: "Sut veragh",
      name: "Sut veragh (n.) button (clothing)"
   }, 
   {
      id: 1433,
      word: "Sutay",
      name: "Sutay (n.) honorific sutai"
   }, 
   {
      id: 1434,
      word: "Sutlh",
      name: "Sutlh (v.) negotiate"
   }, 
   {
      id: 1435,
      word: "Sutlhne'",
      name: "Sutlhne' (n.) amateur"
   }, 
   {
      id: 1436,
      word: "Suto'vo'qor",
      name: "Suto'vo'qor (n.) Sto-Vo-Kor"
   }, 
   {
      id: 1437,
      word: "Sutra'ber naH",
      name: "Sutra'ber naH (n.) strawberry"
   }, 
   {
      id: 1438,
      word: "Sutra'ber naHmey",
      name: "Sutra'ber naHmey (n.) strawberries"
   }, 
   {
      id: 1439,
      word: "Suv",
      name: "Suv (v.) fight"
   }, 
   {
      id: 1440,
      word: "Suvbogh'Qib",
      name: "Suvbogh'Qib (p.n.) Paul van Berlo"
   }, 
   {
      id: 1441,
      word: "Suvchu'",
      name: "Suvchu' (v.) fight to the death"
   }, 
   {
      id: 1442,
      word: "Suverya'",
      name: "Suverya' (n.) Sweden"
   }, 
   {
      id: 1443,
      word: "SuvwI'",
      name: "SuvwI' (n.) warrior"
   }, 
   {
      id: 1444,
      word: "SuwISya'",
      name: "SuwISya' (n.) Switzerland"
   }, 
   {
      id: 1445,
      word: "SuwomIy",
      name: "SuwomIy (n.) Finland"
   }, 
   {
      id: 1446,
      word: "Suy",
      name: "Suy (n.) merchant"
   }, 
   {
      id: 1447,
      word: "Suy'",
      name: "Suy' (n.) shooy, type of animal"
   }, 
   {
      id: 1448,
      word: "SuyDar",
      name: "SuyDar (n.) qubit (quantum bit)"
   }, 
   {
      id: 1449,
      word: "SuyDuj",
      name: "SuyDuj (n.) merchant ship"
   }, 
   {
      id: 1450,
      word: "SuynIj",
      name: "SuynIj (n.) sweat, perspiration"
   }, 
   {
      id: 1451,
      word: "achghuQ",
      name: "achghuQ (p.n.) Joe Schelin"
   }, 
   {
      id: 1452,
      word: "bI",
      name: "bI (vp) you-"
   }, 
   {
      id: 1453,
      word: "bI'",
      name: "bI' (v.) sweep (away)"
   }, 
   {
      id: 1454,
      word: "bI'raD",
      name: "bI'raD (n.) dough, batter"
   }, 
   {
      id: 1455,
      word: "bI'reS",
      name: "bI'reS (n.) beginning (of an opera, play, story, speech)"
   }, 
   {
      id: 1456,
      word: "bI'reS 'echlet",
      name: "bI'reS 'echlet (n.) front cover (of a book)"
   }, 
   {
      id: 1457,
      word: "bI'reS taymey",
      name: "bI'reS taymey (n.) prologue"
   }, 
   {
      id: 1458,
      word: "bI'rel tlharghDuj",
      name: "bI'rel tlharghDuj (n.) B'rel-class Scout"
   }, 
   {
      id: 1459,
      word: "bID",
      name: "bID (n.) half"
   }, 
   {
      id: 1460,
      word: "bIH",
      name: "bIH (pronoun) they, them (none language users)"
   }, 
   {
      id: 1461,
      word: "bIQ",
      name: "bIQ (n.) water"
   }, 
   {
      id: 1462,
      word: "bIQ SeHjan",
      name: "bIQ SeHjan (n.) faucet"
   }, 
   {
      id: 1463,
      word: "bIQ bal",
      name: "bIQ bal (n.) water jug"
   }, 
   {
      id: 1464,
      word: "bIQ beb",
      name: "bIQ beb (n.) surface of water"
   }, 
   {
      id: 1465,
      word: "bIQ ghItmoHwI'",
      name: "bIQ ghItmoHwI' (n.) fountain"
   }, 
   {
      id: 1466,
      word: "bIQ notron",
      name: "bIQ notron (n.) waterfall"
   }, 
   {
      id: 1467,
      word: "bIQ'a'",
      name: "bIQ'a' (n.) ocean, sea"
   }, 
   {
      id: 1468,
      word: "bIQ'a' HeH",
      name: "bIQ'a' HeH (n.) beach"
   }, 
   {
      id: 1469,
      word: "bIQ'a' Sargh",
      name: "bIQ'a' Sargh (n.) terran seahorse"
   }, 
   {
      id: 1470,
      word: "bIQ-DawSon",
      name: "bIQ-DawSon (p.n.) Biggs-Dawson"
   }, 
   {
      id: 1471,
      word: "bIQDep",
      name: "bIQDep (n.) fish"
   }, 
   {
      id: 1472,
      word: "bIQHurgh",
      name: "bIQHurgh (p.n.) Christoph Pfisterer"
   }, 
   {
      id: 1473,
      word: "bIQSIp",
      name: "bIQSIp (n.) hydrogen"
   }, 
   {
      id: 1474,
      word: "bIQSIp 'ugh",
      name: "bIQSIp 'ugh (n.) deuterium isotope"
   }, 
   {
      id: 1475,
      word: "bIQtIq",
      name: "bIQtIq (n.) river"
   }, 
   {
      id: 1476,
      word: "bIQyIn",
      name: "bIQyIn (n.) cookie sandwich (made from two cookies with something between them)"
   }, 
   {
      id: 1477,
      word: "bIS'ub",
      name: "bIS'ub (n.) bottom (interior)"
   }, 
   {
      id: 1478,
      word: "bIghHa'",
      name: "bIghHa' (n.) prison, jail"
   }, 
   {
      id: 1479,
      word: "bIj",
      name: "bIj (v.) punish"
   }, 
   {
      id: 1480,
      word: "bIj",
      name: "bIj (n.) punishment"
   }, 
   {
      id: 1481,
      word: "bIlIS ngutlhmey",
      name: "bIlIS ngutlhmey (n.) Blissymbols"
   }, 
   {
      id: 1482,
      word: "bIlemtan",
      name: "bIlemtan (n.) whim"
   }, 
   {
      id: 1483,
      word: "bIm",
      name: "bIm (n.) second tone of nonatonic scale"
   }, 
   {
      id: 1484,
      word: "bIng",
      name: "bIng (n.) area below, area under"
   }, 
   {
      id: 1485,
      word: "bInglan",
      name: "bInglan (n.) hypothesis"
   }, 
   {
      id: 1486,
      word: "bIp",
      name: "bIp (number) hundred thousand"
   }, 
   {
      id: 1487,
      word: "bIp'uy'",
      name: "bIp'uy' (number) 100 billion"
   }, 
   {
      id: 1488,
      word: "bIqIynIy",
      name: "bIqIynIy (n.) bikini"
   }, 
   {
      id: 1489,
      word: "bIr",
      name: "bIr (v.) be cold"
   }, 
   {
      id: 1490,
      word: "bIrI'tIS qolambIya",
      name: "bIrI'tIS qolambIya (n.) British Columbia"
   }, 
   {
      id: 1491,
      word: "bIraSIw",
      name: "bIraSIw (n.) Brazil"
   }, 
   {
      id: 1492,
      word: "bIraqlul",
      name: "bIraqlul (n.) brak'lul (redundancy in body parts)"
   }, 
   {
      id: 1493,
      word: "bIre'tanya",
      name: "bIre'tanya (n.) Brittany"
   }, 
   {
      id: 1494,
      word: "bIreQtagh",
      name: "bIreQtagh (n.) bregit lung"
   }, 
   {
      id: 1495,
      word: "bIreqtal",
      name: "bIreqtal (n.) Brek'tal ritual"
   }, 
   {
      id: 1496,
      word: "bIroqlIy majaj",
      name: "bIroqlIy majaj (n.) broccoli"
   }, 
   {
      id: 1497,
      word: "bIt",
      name: "bIt (v.) be nervous, be uneasy"
   }, 
   {
      id: 1498,
      word: "bItlh",
      name: "bItlh (v.) adapt to, get used to, acclimatize to, conform to, become adjusted to"
   }, 
   {
      id: 1499,
      word: "bIv",
      name: "bIv (v.) break rules"
   }, 
   {
      id: 1500,
      word: "bIyelaruS",
      name: "bIyelaruS (n.) Belarus"
   }, 
   {
      id: 1501,
      word: "ba'",
      name: "ba' (vs6) obviously"
   }, 
   {
      id: 1502,
      word: "ba'",
      name: "ba' (v.) sit"
   }, 
   {
      id: 1503,
      word: "ba'Suq",
      name: "ba'Suq (n.) bubble"
   }, 
   {
      id: 1504,
      word: "ba'Suq SIp",
      name: "ba'Suq SIp (n.) carbon dioxide (slang)"
   }, 
   {
      id: 1505,
      word: "ba'qIn",
      name: "ba'qIn (n.) saddle"
   }, 
   {
      id: 1506,
      word: "baH",
      name: "baH (v.) fire (e.g. a torpedo, rocket, missile)"
   }, 
   {
      id: 1507,
      word: "baHjan",
      name: "baHjan (n.) launcher"
   }, 
   {
      id: 1508,
      word: "baHwI'",
      name: "baHwI' (n.) gunner"
   }, 
   {
      id: 1509,
      word: "baQ",
      name: "baQ (v.) be fresh, be just picked (fruit, vegetable)"
   }, 
   {
      id: 1510,
      word: "baQ",
      name: "baQ (v.) toss bat'leth from one hand to the other"
   }, 
   {
      id: 1511,
      word: "baQa'",
      name: "baQa' (exclamation) (curse) general invective"
   }, 
   {
      id: 1512,
      word: "baQa'",
      name: "baQa' (exclamation) boo! hiss!"
   }, 
   {
      id: 1513,
      word: "baQpel",
      name: "baQpel (n.) alternating one-handed pull-ups"
   }, 
   {
      id: 1514,
      word: "baS",
      name: "baS (n.) metal"
   }, 
   {
      id: 1515,
      word: "baS 'In",
      name: "baS 'In (n.) bell (percussion instrument made of metal)"
   }, 
   {
      id: 1516,
      word: "baS Ha'on",
      name: "baS Ha'on (n.) staple"
   }, 
   {
      id: 1517,
      word: "baS SIrgh",
      name: "baS SIrgh (n.) wire"
   }, 
   {
      id: 1518,
      word: "baS laSvargh",
      name: "baS laSvargh (n.) foundry"
   }, 
   {
      id: 1519,
      word: "baSta'",
      name: "baSta' (n.) vector"
   }, 
   {
      id: 1520,
      word: "baStan",
      name: "baStan (p.n.) Boston"
   }, 
   {
      id: 1521,
      word: "babey'DaS",
      name: "babey'DaS (n.) Barbados"
   }, 
   {
      id: 1522,
      word: "babton",
      name: "babton (n.) pepper (capsicum)"
   }, 
   {
      id: 1523,
      word: "bach",
      name: "bach (v.) shoot"
   }, 
   {
      id: 1524,
      word: "bach",
      name: "bach (n.) shot"
   }, 
   {
      id: 1525,
      word: "bachHa'",
      name: "bachHa' (v.) err (slang), make a mistake (slang)"
   }, 
   {
      id: 1526,
      word: "bachghIng",
      name: "bachghIng (n.) tension (physics)"
   }, 
   {
      id: 1527,
      word: "bagh",
      name: "bagh (v.) tie"
   }, 
   {
      id: 1528,
      word: "bagh'et",
      name: "bagh'et (n.) baguette"
   }, 
   {
      id: 1529,
      word: "baghHa'",
      name: "baghHa' (v.) crack a code (slang)"
   }, 
   {
      id: 1530,
      word: "baghneQ",
      name: "baghneQ (n.) spoon"
   }, 
   {
      id: 1531,
      word: "baj",
      name: "baj (v.) earn (can take a sentence as object), work for (actively)"
   }, 
   {
      id: 1532,
      word: "bal",
      name: "bal (n.) jug, jar, bottle"
   }, 
   {
      id: 1533,
      word: "balgharya'",
      name: "balgharya' (n.) Bulgaria"
   }, 
   {
      id: 1534,
      word: "bam",
      name: "bam (v.) face, have the prospect of having to deal with"
   }, 
   {
      id: 1535,
      word: "bambu'",
      name: "bambu' (n.) bamboo"
   }, 
   {
      id: 1536,
      word: "ban",
      name: "ban (v.) be bruised"
   }, 
   {
      id: 1537,
      word: "banan naH",
      name: "banan naH (n.) banana"
   }, 
   {
      id: 1538,
      word: "bang",
      name: "bang (n.) loved one, one who is loved"
   }, 
   {
      id: 1539,
      word: "bang bom",
      name: "bang bom (n.) love song"
   }, 
   {
      id: 1540,
      word: "bang pong",
      name: "bang pong (n.) pet name, endearment"
   }, 
   {
      id: 1541,
      word: "banglaDeS",
      name: "banglaDeS (n.) Bangladesh"
   }, 
   {
      id: 1542,
      word: "bangteH",
      name: "bangteH (p.n.) Frank Truelove"
   }, 
   {
      id: 1543,
      word: "banmoH",
      name: "banmoH (v.) bruise"
   }, 
   {
      id: 1544,
      word: "baq",
      name: "baq (v.) terminate, discontinue"
   }, 
   {
      id: 1545,
      word: "baqghol",
      name: "baqghol (n.) type of liquor, bahgol"
   }, 
   {
      id: 1546,
      word: "bar",
      name: "bar (v.) blink, flash"
   }, 
   {
      id: 1547,
      word: "barat",
      name: "barat (n.) India"
   }, 
   {
      id: 1548,
      word: "barbara'",
      name: "barbara' (p.n.) Barbara"
   }, 
   {
      id: 1549,
      word: "bargh",
      name: "bargh (n.) flat-bottomed pot for food preparation"
   }, 
   {
      id: 1550,
      word: "bargh Soj",
      name: "bargh Soj (n.) casserole"
   }, 
   {
      id: 1551,
      word: "barot",
      name: "barot (p.n.) Barot"
   }, 
   {
      id: 1552,
      word: "bartIq",
      name: "bartIq (n.) branch (of a tree)"
   }, 
   {
      id: 1553,
      word: "bartIq waq",
      name: "bartIq waq (n.) ski"
   }, 
   {
      id: 1554,
      word: "batleH bey'",
      name: "batleH bey' (n.) Bat'telh display"
   }, 
   {
      id: 1555,
      word: "batlh",
      name: "batlh (n.) honor"
   }, 
   {
      id: 1556,
      word: "batlh",
      name: "batlh (adverb) honored, with honor"
   }, 
   {
      id: 1557,
      word: "batlhHa'",
      name: "batlhHa' (adverb) dishonorably"
   }, 
   {
      id: 1558,
      word: "bav",
      name: "bav (n.) circumference"
   }, 
   {
      id: 1559,
      word: "bav",
      name: "bav (v.) orbit"
   }, 
   {
      id: 1560,
      word: "baw'",
      name: "baw' (v.) be comfortable, be feeling prepared, be confident"
   }, 
   {
      id: 1561,
      word: "baw'Ha'",
      name: "baw'Ha' (v.) be uncomfortable, be worried, be hesitant"
   }, 
   {
      id: 1562,
      word: "bay'eS",
      name: "bay'eS (n.) inferior, subordinate"
   }, 
   {
      id: 1563,
      word: "baylaD",
      name: "baylaD (n.) slice"
   }, 
   {
      id: 1564,
      word: "be'",
      name: "be' (n.) female, woman"
   }, 
   {
      id: 1565,
      word: "be'",
      name: "be' (vsr) not"
   }, 
   {
      id: 1566,
      word: "be'Hom",
      name: "be'Hom (n.) girl"
   }, 
   {
      id: 1567,
      word: "be'avrI'qa'",
      name: "be'avrI'qa' (n.) Central African Republic"
   }, 
   {
      id: 1568,
      word: "be'etor",
      name: "be'etor (p.n.) B'Etor - one of the DuraS sisters"
   }, 
   {
      id: 1569,
      word: "be'joy'",
      name: "be'joy' (n.) ritualized torture by women"
   }, 
   {
      id: 1570,
      word: "be'nI'",
      name: "be'nI' (n.) sister"
   }, 
   {
      id: 1571,
      word: "be'nal",
      name: "be'nal (n.) wife"
   }, 
   {
      id: 1572,
      word: "beH",
      name: "beH (vs2) ready, set up (referring to devices)"
   }, 
   {
      id: 1573,
      word: "beH",
      name: "beH (n.) rifle"
   }, 
   {
      id: 1574,
      word: "beHwI''av",
      name: "beHwI''av (p.n.) (dancat@.netland.nl)"
   }, 
   {
      id: 1575,
      word: "beQ",
      name: "beQ (v.) be flat"
   }, 
   {
      id: 1576,
      word: "beS",
      name: "beS (v.) scald"
   }, 
   {
      id: 1577,
      word: "beSbal moQ",
      name: "beSbal moQ (n.) baseball"
   }, 
   {
      id: 1578,
      word: "beb",
      name: "beb (n.) roof"
   }, 
   {
      id: 1579,
      word: "beb mutlhwI'",
      name: "beb mutlhwI' (n.) roofer"
   }, 
   {
      id: 1580,
      word: "bech",
      name: "bech (v.) suffer"
   }, 
   {
      id: 1581,
      word: "begh",
      name: "begh (n.) deflectors"
   }, 
   {
      id: 1582,
      word: "bej",
      name: "bej (v.) be sure (slang), be definite (slang), be positive (slang), be certain (slang)"
   }, 
   {
      id: 1583,
      word: "bej",
      name: "bej (vs6) certainly, undoubtedly"
   }, 
   {
      id: 1584,
      word: "bej",
      name: "bej (v.) watch"
   }, 
   {
      id: 1585,
      word: "bel",
      name: "bel (v.) be pleased"
   }, 
   {
      id: 1586,
      word: "bel",
      name: "bel (n.) pleasure"
   }, 
   {
      id: 1587,
      word: "bel Qu'",
      name: "bel Qu' (n.) hobby"
   }, 
   {
      id: 1588,
      word: "belHa'",
      name: "belHa' (v.) be displeased"
   }, 
   {
      id: 1589,
      word: "belghIya'",
      name: "belghIya' (n.) Belgium"
   }, 
   {
      id: 1590,
      word: "bem",
      name: "bem (n.) sole of foot"
   }, 
   {
      id: 1591,
      word: "ben",
      name: "ben (n.) years ago, years old"
   }, 
   {
      id: 1592,
      word: "beng",
      name: "beng (v.) addicted, be addicted (to)"
   }, 
   {
      id: 1593,
      word: "bep",
      name: "bep (n.) agony"
   }, 
   {
      id: 1594,
      word: "bep",
      name: "bep (v.) complain"
   }, 
   {
      id: 1595,
      word: "beq",
      name: "beq (n.) crew, crewman"
   }, 
   {
      id: 1596,
      word: "beqpuj",
      name: "beqpuj (n.) type of mineral, bekpuj (orange in color)"
   }, 
   {
      id: 1597,
      word: "ber",
      name: "ber (v.) ovulate, undergo ovulation"
   }, 
   {
      id: 1598,
      word: "berImyu'Da",
      name: "berImyu'Da (n.) Bermuda"
   }, 
   {
      id: 1599,
      word: "bergh",
      name: "bergh (v.) be irritable"
   }, 
   {
      id: 1600,
      word: "berlIn",
      name: "berlIn (n.) Berlin"
   }, 
   {
      id: 1601,
      word: "bernarDo",
      name: "bernarDo (p.n.) Bernardo"
   }, 
   {
      id: 1602,
      word: "bertlham",
      name: "bertlham (n.) end (of an opera, play, story, speech)"
   }, 
   {
      id: 1603,
      word: "bertlham 'echlet",
      name: "bertlham 'echlet (n.) back cover (of a book)"
   }, 
   {
      id: 1604,
      word: "bertlham taymey",
      name: "bertlham taymey (n.) epilogue"
   }, 
   {
      id: 1605,
      word: "bet",
      name: "bet (v.) impale"
   }, 
   {
      id: 1606,
      word: "betgham",
      name: "betgham (n.) liquid (state of matter)"
   }, 
   {
      id: 1607,
      word: "betleH",
      name: "betleH (n.) bat'leth, hand weapon (type of)"
   }, 
   {
      id: 1608,
      word: "betleH 'obe'",
      name: "betleH 'obe' (n.) Order of the Bat'leth"
   }, 
   {
      id: 1609,
      word: "betleH bey'",
      name: "betleH bey' (n.) Bat'telh display"
   }, 
   {
      id: 1610,
      word: "bettI'",
      name: "bettI' (n.) aluminum"
   }, 
   {
      id: 1611,
      word: "bewSom",
      name: "bewSom (n.) mixture of ingredients that, after a bit of time, produces fermented HIq"
   }, 
   {
      id: 1612,
      word: "bewSom pa'",
      name: "bewSom pa' (n.) brewery"
   }, 
   {
      id: 1613,
      word: "bewSom qach",
      name: "bewSom qach (n.) brewery"
   }, 
   {
      id: 1614,
      word: "bewbeb",
      name: "bewbeb (n.) Baobab (a Terran tree)"
   }, 
   {
      id: 1615,
      word: "bey",
      name: "bey (n.) howl, wail"
   }, 
   {
      id: 1616,
      word: "bey'",
      name: "bey' (n.) ceremonial display"
   }, 
   {
      id: 1617,
      word: "bey'jor",
      name: "bey'jor (n.) Bajor"
   }, 
   {
      id: 1618,
      word: "beylI'",
      name: "beylI' (n.) bank"
   }, 
   {
      id: 1619,
      word: "beylana",
      name: "beylana (p.n.) B'Elanna"
   }, 
   {
      id: 1620,
      word: "beynen",
      name: "beynen (n.) Benin"
   }, 
   {
      id: 1621,
      word: "beytor",
      name: "beytor (p.n.) B'Etor"
   }, 
   {
      id: 1622,
      word: "bo",
      name: "bo (n.) feather"
   }, 
   {
      id: 1623,
      word: "bo",
      name: "bo (vp) you (pl)-him/her/it/them"
   }, 
   {
      id: 1624,
      word: "bo'DIj",
      name: "bo'DIj (n.) court"
   }, 
   {
      id: 1625,
      word: "bo'DIj nompuq",
      name: "bo'DIj nompuq (n.) forensic evidence"
   }, 
   {
      id: 1626,
      word: "bo'DIj qaD",
      name: "bo'DIj qaD (n.) lawsuit"
   }, 
   {
      id: 1627,
      word: "bo'Dagh",
      name: "bo'Dagh (n.) scoop, scooping implement (to serve food)"
   }, 
   {
      id: 1628,
      word: "bo'Degh",
      name: "bo'Degh (n.) bird, the most general word for a bird-like creature"
   }, 
   {
      id: 1629,
      word: "bo'ghey",
      name: "bo'ghey (n.) slope"
   }, 
   {
      id: 1630,
      word: "bo'voD",
      name: "bo'voD (n.) drawer"
   }, 
   {
      id: 1631,
      word: "boD",
      name: "boD (n.) forehead (regional)"
   }, 
   {
      id: 1632,
      word: "boH",
      name: "boH (v.) be impatient"
   }, 
   {
      id: 1633,
      word: "boQ",
      name: "boQ (n.) aid, assistance"
   }, 
   {
      id: 1634,
      word: "boQ",
      name: "boQ (v.) assist"
   }, 
   {
      id: 1635,
      word: "boQ Hol",
      name: "boQ Hol (n.) pidgin, creole, contact language"
   }, 
   {
      id: 1636,
      word: "boQDu'",
      name: "boQDu' (n.) aide-de-camp"
   }, 
   {
      id: 1637,
      word: "boS",
      name: "boS (v.) collect"
   }, 
   {
      id: 1638,
      word: "boSna",
      name: "boSna (n.) Bosnia"
   }, 
   {
      id: 1639,
      word: "boSnayHercheghovIna",
      name: "boSnayHercheghovIna (n.) Bosnia"
   }, 
   {
      id: 1640,
      word: "boSporoS",
      name: "boSporoS (p.n.) Bosporus"
   }, 
   {
      id: 1641,
      word: "bobDar",
      name: "bobDar (n.) splash"
   }, 
   {
      id: 1642,
      word: "bobcho'",
      name: "bobcho' (n.) module"
   }, 
   {
      id: 1643,
      word: "boch",
      name: "boch (v.) be shiny, shine"
   }, 
   {
      id: 1644,
      word: "bochmoHwI'",
      name: "bochmoHwI' (n.) sycophant, flatterer (slang)"
   }, 
   {
      id: 1645,
      word: "bogh",
      name: "bogh (v.) be born"
   }, 
   {
      id: 1646,
      word: "bogh",
      name: "bogh (vs9) which (relative-clause marker)"
   }, 
   {
      id: 1647,
      word: "boghoy",
      name: "boghoy (n.) procession, parade, march"
   }, 
   {
      id: 1648,
      word: "boj",
      name: "boj (v.) nag"
   }, 
   {
      id: 1649,
      word: "bol",
      name: "bol (v.) drool"
   }, 
   {
      id: 1650,
      word: "bolmaq",
      name: "bolmaq (n.) bolmak, sheep, type of animal"
   }, 
   {
      id: 1651,
      word: "bolwI'",
      name: "bolwI' (n.) traitor (slang)"
   }, 
   {
      id: 1652,
      word: "bom",
      name: "bom (v.) sing, chant"
   }, 
   {
      id: 1653,
      word: "bom",
      name: "bom (n.) song, chant"
   }, 
   {
      id: 1654,
      word: "bom mu'",
      name: "bom mu' (n.) lyric, lyrics"
   }, 
   {
      id: 1655,
      word: "bom; puq rur",
      name: "bom; puq rur (v.) sing falsetto"
   }, 
   {
      id: 1656,
      word: "bomwI'",
      name: "bomwI' (n.) singer"
   }, 
   {
      id: 1657,
      word: "bon",
      name: "bon (v.) share (with someone)"
   }, 
   {
      id: 1658,
      word: "bong",
      name: "bong (adverb) accidentally, by accident"
   }, 
   {
      id: 1659,
      word: "bop",
      name: "bop (v.) be about, be concerned with"
   }, 
   {
      id: 1660,
      word: "boq",
      name: "boq (n.) alliance, bloc, coalition, fusion"
   }, 
   {
      id: 1661,
      word: "boq",
      name: "boq (v.) ally with, form an alliance with, used in math for addition"
   }, 
   {
      id: 1662,
      word: "boq Hol",
      name: "boq Hol (n.) pidgin, creole, contact language"
   }, 
   {
      id: 1663,
      word: "boq ru'",
      name: "boq ru' (n.) coalition"
   }, 
   {
      id: 1664,
      word: "boq'egh",
      name: "boq'egh (v.) used in math for multiplication"
   }, 
   {
      id: 1665,
      word: "boqHa'",
      name: "boqHa' (v.) used in math for subtraction"
   }, 
   {
      id: 1666,
      word: "boqHa''egh",
      name: "boqHa''egh (v.) used in math for division"
   }, 
   {
      id: 1667,
      word: "boqHar",
      name: "boqHar (n.) miracle, wonder"
   }, 
   {
      id: 1668,
      word: "boqrat",
      name: "boqrat (n.) bokrat, type of animal"
   }, 
   {
      id: 1669,
      word: "boqrat chej",
      name: "boqrat chej (n.) bok-rat liver, stewed"
   }, 
   {
      id: 1670,
      word: "boqyIn",
      name: "boqyIn (n.) symbiont"
   }, 
   {
      id: 1671,
      word: "bor",
      name: "bor (v.) gurgle"
   }, 
   {
      id: 1672,
      word: "borghel",
      name: "borghel (n.) a very small bird whose eggs are considered quite tasty"
   }, 
   {
      id: 1673,
      word: "borqu'",
      name: "borqu' (v.) thunder (slang)"
   }, 
   {
      id: 1674,
      word: "bortaS",
      name: "bortaS (n.) revenge"
   }, 
   {
      id: 1675,
      word: "bortaS DIb",
      name: "bortaS DIb (n.) Right of Vengeance (a legal right)"
   }, 
   {
      id: 1676,
      word: "bot",
      name: "bot (v.) insulate"
   }, 
   {
      id: 1677,
      word: "bot",
      name: "bot (v.) prevent, block, prohibit"
   }, 
   {
      id: 1678,
      word: "botjan",
      name: "botjan (n.) shields, protective force fields on a ship"
   }, 
   {
      id: 1679,
      word: "botlh",
      name: "botlh (n.) center, middle, median"
   }, 
   {
      id: 1680,
      word: "botlh",
      name: "botlh (n.) median"
   }, 
   {
      id: 1681,
      word: "bov",
      name: "bov (n.) era"
   }, 
   {
      id: 1682,
      word: "bu'",
      name: "bu' (n.) sergeant"
   }, 
   {
      id: 1683,
      word: "buD",
      name: "buD (v.) be lazy"
   }, 
   {
      id: 1684,
      word: "buDHa lalDan",
      name: "buDHa lalDan (n.) Buddhism"
   }, 
   {
      id: 1685,
      word: "buQ",
      name: "buQ (v.) threaten"
   }, 
   {
      id: 1686,
      word: "buS",
      name: "buS (v.) concentrate on, focus on, think only about"
   }, 
   {
      id: 1687,
      word: "buSHa'",
      name: "buSHa' (v.) ignore"
   }, 
   {
      id: 1688,
      word: "buSHach",
      name: "buSHach (n.) thought, notion"
   }, 
   {
      id: 1689,
      word: "buchwa'na",
      name: "buchwa'na (n.) Botswana"
   }, 
   {
      id: 1690,
      word: "buj",
      name: "buj (v.) be neither warm nor cool (temperature)"
   }, 
   {
      id: 1691,
      word: "bulvar",
      name: "bulvar (n.) monk"
   }, 
   {
      id: 1692,
      word: "bum",
      name: "bum (v.) absorb"
   }, 
   {
      id: 1693,
      word: "bup",
      name: "bup (v.) quit"
   }, 
   {
      id: 1694,
      word: "buq",
      name: "buq (n.) bag, sack, pouch, pocket"
   }, 
   {
      id: 1695,
      word: "buq Quj",
      name: "buq Quj (n.) basketball"
   }, 
   {
      id: 1696,
      word: "buq yopwaH",
      name: "buq yopwaH (n.) cargo pants"
   }, 
   {
      id: 1697,
      word: "buq yopwaH bID",
      name: "buq yopwaH bID (n.) cargo shorts"
   }, 
   {
      id: 1698,
      word: "buq'Ir",
      name: "buq'Ir (n.) cube"
   }, 
   {
      id: 1699,
      word: "buq'ach",
      name: "buq'ach (n.) trombone-like Klingon instrument"
   }, 
   {
      id: 1700,
      word: "buqjaj",
      name: "buqjaj (n.) Friday"
   }, 
   {
      id: 1701,
      word: "bur",
      name: "bur (v.) hiccup"
   }, 
   {
      id: 1702,
      word: "burgh",
      name: "burgh (n.) stomach"
   }, 
   {
      id: 1703,
      word: "burgh quD",
      name: "burgh quD (n.) naturally produced qud"
   }, 
   {
      id: 1704,
      word: "burqIyna'vaSo",
      name: "burqIyna'vaSo (n.) Burkina Faso"
   }, 
   {
      id: 1705,
      word: "burrI'to",
      name: "burrI'to (n.) burrito"
   }, 
   {
      id: 1706,
      word: "but",
      name: "but (v.) be natural"
   }, 
   {
      id: 1707,
      word: "butlh",
      name: "butlh (n.) dirt under fingernails; symbolic equivalent of gall, an admirable trait to  have"
   }, 
   {
      id: 1708,
      word: "butnat",
      name: "butnat (n.) plutonium"
   }, 
   {
      id: 1709,
      word: "buv",
      name: "buv (n.) classification"
   }, 
   {
      id: 1710,
      word: "buv",
      name: "buv (v.) classify"
   }, 
   {
      id: 1711,
      word: "buy'",
      name: "buy' (v.) be full, be filled up"
   }, 
   {
      id: 1712,
      word: "buy' ngop",
      name: "buy' ngop (exclamation) good news, it's good to hear that (slang)"
   }, 
   {
      id: 1713,
      word: "chI",
      name: "chI (v.) menstruate, undergo menstruation"
   }, 
   {
      id: 1714,
      word: "chI'ID",
      name: "chI'ID (n.) uterus"
   }, 
   {
      id: 1715,
      word: "chI'lIy",
      name: "chI'lIy (n.) chili con carne"
   }, 
   {
      id: 1716,
      word: "chI'le",
      name: "chI'le (n.) Chile"
   }, 
   {
      id: 1717,
      word: "chID",
      name: "chID (v.) admit"
   }, 
   {
      id: 1718,
      word: "chIS",
      name: "chIS (v.) be white"
   }, 
   {
      id: 1719,
      word: "chIch",
      name: "chIch (adverb) purposely, on purpose, intentionally"
   }, 
   {
      id: 1720,
      word: "chIj",
      name: "chIj (v.) navigate"
   }, 
   {
      id: 1721,
      word: "chIl",
      name: "chIl (v.) lose, misplace"
   }, 
   {
      id: 1722,
      word: "chIm",
      name: "chIm (v.) be empty, be deserted, be uninhabited"
   }, 
   {
      id: 1723,
      word: "chIp",
      name: "chIp (v.) cut (hair, etc), trim (hair, etc)"
   }, 
   {
      id: 1724,
      word: "chIq",
      name: "chIq (v.) cross, traverse"
   }, 
   {
      id: 1725,
      word: "chIrgh",
      name: "chIrgh (n.) temple (structure), church"
   }, 
   {
      id: 1726,
      word: "chItlh",
      name: "chItlh (v.) be symmetrical"
   }, 
   {
      id: 1727,
      word: "chIvay'bruqen",
      name: "chIvay'bruqen (n.) Zweibr"
   }, 
   {
      id: 1728,
      word: "chIvo'",
      name: "chIvo' (n.) total dishonor, absolute lack of honor"
   }, 
   {
      id: 1729,
      word: "chIw",
      name: "chIw (v.) express, embody, exude, epitomize"
   }, 
   {
      id: 1730,
      word: "cha",
      name: "cha (n.) torpedoes"
   }, 
   {
      id: 1731,
      word: "cha'",
      name: "cha' (v.) show, display (picture)"
   }, 
   {
      id: 1732,
      word: "cha'",
      name: "cha' (number) two, 2"
   }, 
   {
      id: 1733,
      word: "cha''etlh",
      name: "cha''etlh (n.) two-blades"
   }, 
   {
      id: 1734,
      word: "cha''etlh DaSwI'",
      name: "cha''etlh DaSwI' (n.) tweezer"
   }, 
   {
      id: 1735,
      word: "cha''etlh pe'wI'",
      name: "cha''etlh pe'wI' (n.) scissors"
   }, 
   {
      id: 1736,
      word: "cha'DIch",
      name: "cha'DIch (number) second"
   }, 
   {
      id: 1737,
      word: "cha'DIch",
      name: "cha'DIch (n.) second, aide"
   }, 
   {
      id: 1738,
      word: "cha'DaSvI'",
      name: "cha'DaSvI' (n.) a Klingon game that is similar to golf in that it involves precisely aiming a projectile"
   }, 
   {
      id: 1739,
      word: "cha'Do'",
      name: "cha'Do' (n.) a species of Klingon bird about which little is known"
   }, 
   {
      id: 1740,
      word: "cha'Har",
      name: "cha'Har (n.) isthmus"
   }, 
   {
      id: 1741,
      word: "cha'Hu'",
      name: "cha'Hu' (n.) day before yesterday"
   }, 
   {
      id: 1742,
      word: "cha'bIp",
      name: "cha'bIp (n.) a bird noted for its speed"
   }, 
   {
      id: 1743,
      word: "cha'leS",
      name: "cha'leS (n.) day after tomorrow"
   }, 
   {
      id: 1744,
      word: "cha'naS",
      name: "cha'naS (n.) a small bird which digs up bugs to eat"
   }, 
   {
      id: 1745,
      word: "cha'neH",
      name: "cha'neH (n.) forearm"
   }, 
   {
      id: 1746,
      word: "cha'nob",
      name: "cha'nob (n.) ritual gifts"
   }, 
   {
      id: 1747,
      word: "cha'par",
      name: "cha'par (n.) a bird noted for its song"
   }, 
   {
      id: 1748,
      word: "cha'puj",
      name: "cha'puj (n.) dilithium"
   }, 
   {
      id: 1749,
      word: "cha'pujqut",
      name: "cha'pujqut (n.) dilithium crystal"
   }, 
   {
      id: 1750,
      word: "cha'qu'",
      name: "cha'qu' (n.) a bird with a noisy, repetitive cry"
   }, 
   {
      id: 1751,
      word: "chaD",
      name: "chaD (n.) Chad"
   }, 
   {
      id: 1752,
      word: "chaDvay'",
      name: "chaDvay' (n.) hertz, radio frequency"
   }, 
   {
      id: 1753,
      word: "chaH",
      name: "chaH (pronoun) they, them (language users)"
   }, 
   {
      id: 1754,
      word: "chaQ",
      name: "chaQ (v.) thrust upward with end of bat'leth"
   }, 
   {
      id: 1755,
      word: "chaS",
      name: "chaS (n.) top of walking cane or ceremonial cane"
   }, 
   {
      id: 1756,
      word: "chab",
      name: "chab (n.) pie, tart, dumpling, invention (slang), innovation (slang), cake"
   }, 
   {
      id: 1757,
      word: "chab vutwI'",
      name: "chab vutwI' (n.) pizza baker"
   }, 
   {
      id: 1758,
      word: "chabHom",
      name: "chabHom (n.) cookie (food)"
   }, 
   {
      id: 1759,
      word: "chabal",
      name: "chabal (n.) something desired or requested"
   }, 
   {
      id: 1760,
      word: "chach",
      name: "chach (n.) emergency, auxiliary, backup"
   }, 
   {
      id: 1761,
      word: "chagh",
      name: "chagh (v.) drop"
   }, 
   {
      id: 1762,
      word: "chaj",
      name: "chaj (n.) close female friend of a female"
   }, 
   {
      id: 1763,
      word: "chaj",
      name: "chaj (ns4) their"
   }, 
   {
      id: 1764,
      word: "chal",
      name: "chal (n.) sky"
   }, 
   {
      id: 1765,
      word: "chal bIQ",
      name: "chal bIQ (n.) rain"
   }, 
   {
      id: 1766,
      word: "chal chuch",
      name: "chal chuch (n.) snow"
   }, 
   {
      id: 1767,
      word: "chal qul",
      name: "chal qul (n.) aurora"
   }, 
   {
      id: 1768,
      word: "chalqach",
      name: "chalqach (n.) tower (sky building)"
   }, 
   {
      id: 1769,
      word: "cham",
      name: "cham (n.) technology"
   }, 
   {
      id: 1770,
      word: "chamwI'",
      name: "chamwI' (n.) technician"
   }, 
   {
      id: 1771,
      word: "chan",
      name: "chan (n.) eastward, area toward the east (90 degrees on Terran 360 degree compass with north as 0 and degrees"
   }, 
   {
      id: 1772,
      word: "chan nagh",
      name: "chan nagh (n.) andesite"
   }, 
   {
      id: 1773,
      word: "chanDoq",
      name: "chanDoq (n.) marinade"
   }, 
   {
      id: 1774,
      word: "chang",
      name: "chang (v.) be gelatinous"
   }, 
   {
      id: 1775,
      word: "chang'eng",
      name: "chang'eng (n.) pair"
   }, 
   {
      id: 1776,
      word: "chanmon",
      name: "chanmon (n.) diamond"
   }, 
   {
      id: 1777,
      word: "chap",
      name: "chap (n.) back (of hand)"
   }, 
   {
      id: 1778,
      word: "chap",
      name: "chap (v.) be official, authenticated, authorized, legitimate"
   }, 
   {
      id: 1779,
      word: "chaq",
      name: "chaq (adverb) perhaps"
   }, 
   {
      id: 1780,
      word: "char",
      name: "char (v.) be slimy"
   }, 
   {
      id: 1781,
      word: "chargh",
      name: "chargh (v.) conquer"
   }, 
   {
      id: 1782,
      word: "charghwI'",
      name: "charghwI' (n.) conqueror, victor"
   }, 
   {
      id: 1783,
      word: "charghwI'",
      name: "charghwI' (p.n.) William H. Martin"
   }, 
   {
      id: 1784,
      word: "chatlh",
      name: "chatlh (n.) soup (thick), nonsense (slang), balderdash (slang)"
   }, 
   {
      id: 1785,
      word: "chav",
      name: "chav (v.) achieve"
   }, 
   {
      id: 1786,
      word: "chav",
      name: "chav (n.) achievement"
   }, 
   {
      id: 1787,
      word: "chav",
      name: "chav (n.) function (mathematics)"
   }, 
   {
      id: 1788,
      word: "chaw'",
      name: "chaw' (v.) allow, permit"
   }, 
   {
      id: 1789,
      word: "chaw'",
      name: "chaw' (n.) permit, license"
   }, 
   {
      id: 1790,
      word: "chay'",
      name: "chay' (question) how?"
   }, 
   {
      id: 1791,
      word: "chayqa'",
      name: "chayqa' (n.) esophagus"
   }, 
   {
      id: 1792,
      word: "che",
      name: "che (vp) you (pl)-us"
   }, 
   {
      id: 1793,
      word: "che'",
      name: "che' (v.) rule, reign, run, preside"
   }, 
   {
      id: 1794,
      word: "che'ron",
      name: "che'ron (n.) battlefield"
   }, 
   {
      id: 1795,
      word: "cheH",
      name: "cheH (v.) defect"
   }, 
   {
      id: 1796,
      word: "cheS",
      name: "cheS (n.) ches, rabbit, type of animal"
   }, 
   {
      id: 1797,
      word: "cheS Hol",
      name: "cheS Hol (n.) Tsez"
   }, 
   {
      id: 1798,
      word: "cheSqa'",
      name: "cheSqa' (n.) Czech Republic"
   }, 
   {
      id: 1799,
      word: "cheSvel",
      name: "cheSvel (n.) style of coat from the Vospeg region, coat (regional), jacket (regional)"
   }, 
   {
      id: 1800,
      word: "cheb",
      name: "cheb (n.) unit weight approx. 5 pounds (2.25kg)"
   }, 
   {
      id: 1801,
      word: "cheb'a'",
      name: "cheb'a' (n.) unit of weight approximately 45-46.4 pounds/20.4-21.05 kg/9-9.28 cheb"
   }, 
   {
      id: 1802,
      word: "chech",
      name: "chech (v.) be drunk, be intoxicated"
   }, 
   {
      id: 1803,
      word: "chechtlhutlh",
      name: "chechtlhutlh (n.) type of liquor, chech'tluth"
   }, 
   {
      id: 1804,
      word: "chegh",
      name: "chegh (v.) return (to a place)"
   }, 
   {
      id: 1805,
      word: "chej",
      name: "chej (n.) liver"
   }, 
   {
      id: 1806,
      word: "chel",
      name: "chel (v.) add"
   }, 
   {
      id: 1807,
      word: "chelwI'",
      name: "chelwI' (n.) accountant, financier (slang)"
   }, 
   {
      id: 1808,
      word: "chem",
      name: "chem (n.) field (physical)"
   }, 
   {
      id: 1809,
      word: "chem",
      name: "chem (v.) prank"
   }, 
   {
      id: 1810,
      word: "chemvaH",
      name: "chemvaH (n.) chemvah, type of animal"
   }, 
   {
      id: 1811,
      word: "chen",
      name: "chen (v.) build up, take form"
   }, 
   {
      id: 1812,
      word: "chen'ong",
      name: "chen'ong (n.) maze"
   }, 
   {
      id: 1813,
      word: "chenHa' meyrI'",
      name: "chenHa' meyrI' (v.) fail to climax (slang)"
   }, 
   {
      id: 1814,
      word: "cheng",
      name: "cheng (p.n.) Chang"
   }, 
   {
      id: 1815,
      word: "chenmoH",
      name: "chenmoH (v.) form, make, create"
   }, 
   {
      id: 1816,
      word: "chenmoHwI'",
      name: "chenmoHwI' (n.) creator, maker"
   }, 
   {
      id: 1817,
      word: "chep",
      name: "chep (v.) be prosperous, prospers"
   }, 
   {
      id: 1818,
      word: "cheq",
      name: "cheq (v.) tornado"
   }, 
   {
      id: 1819,
      word: "cher",
      name: "cher (v.) establish, set up"
   }, 
   {
      id: 1820,
      word: "chergh",
      name: "chergh (v.) tolerate"
   }, 
   {
      id: 1821,
      word: "chertIS",
      name: "chertIS (n.) mint, menthoid plant"
   }, 
   {
      id: 1822,
      word: "chertIS Su'ghar Sawqe'",
      name: "chertIS Su'ghar Sawqe' (n.) mint candy"
   }, 
   {
      id: 1823,
      word: "chetvI'",
      name: "chetvI' (n.) torpedo tube, chetvi, spear-throwing device"
   }, 
   {
      id: 1824,
      word: "chev",
      name: "chev (v.) separate"
   }, 
   {
      id: 1825,
      word: "chevwI' tlhoy'",
      name: "chevwI' tlhoy' (n.) territorial wall (e.g. Berlin Wall)"
   }, 
   {
      id: 1826,
      word: "cheyIS",
      name: "cheyIS (n.) cephalopod"
   }, 
   {
      id: 1827,
      word: "cho",
      name: "cho (vp) you-me"
   }, 
   {
      id: 1828,
      word: "cho'",
      name: "cho' (v.) succeed (to authority)"
   }, 
   {
      id: 1829,
      word: "cho'",
      name: "cho' (n.) succession"
   }, 
   {
      id: 1830,
      word: "cho'nI'yoH",
      name: "cho'nI'yoH (n.) animism"
   }, 
   {
      id: 1831,
      word: "choH",
      name: "choH (v.) alter, change"
   }, 
   {
      id: 1832,
      word: "choH",
      name: "choH (n.) change"
   }, 
   {
      id: 1833,
      word: "choH",
      name: "choH (vs3) change"
   }, 
   {
      id: 1834,
      word: "choHwI'",
      name: "choHwI' (p.n.) Stan Goliaszewski"
   }, 
   {
      id: 1835,
      word: "choQ",
      name: "choQ (n.) deck (on a ship)"
   }, 
   {
      id: 1836,
      word: "choQpel",
      name: "choQpel (n.) pull-up"
   }, 
   {
      id: 1837,
      word: "choS",
      name: "choS (v.) desert"
   }, 
   {
      id: 1838,
      word: "choS",
      name: "choS (n.) twilight"
   }, 
   {
      id: 1839,
      word: "choSan",
      name: "choSan (n.) Korea"
   }, 
   {
      id: 1840,
      word: "choSom",
      name: "choSom (n.) quartz"
   }, 
   {
      id: 1841,
      word: "chob",
      name: "chob (n.) corridor"
   }, 
   {
      id: 1842,
      word: "chob'a'",
      name: "chob'a' (n.) main corridor"
   }, 
   {
      id: 1843,
      word: "choghvat",
      name: "choghvat (n.) porch"
   }, 
   {
      id: 1844,
      word: "choghvat",
      name: "choghvat (n.) stairway leading to door of a ship, gangplank"
   }, 
   {
      id: 1845,
      word: "choj",
      name: "choj (v.) train, coach"
   }, 
   {
      id: 1846,
      word: "chol",
      name: "chol (v.) close in on, get closer to, come nearer"
   }, 
   {
      id: 1847,
      word: "choljaH",
      name: "choljaH (n.) ponytail holder"
   }, 
   {
      id: 1848,
      word: "chom",
      name: "chom (n.) bartender"
   }, 
   {
      id: 1849,
      word: "chon",
      name: "chon (n.) hunt"
   }, 
   {
      id: 1850,
      word: "chon bom",
      name: "chon bom (n.) hunting song"
   }, 
   {
      id: 1851,
      word: "chong",
      name: "chong (v.) be vertical, be good (slang), be excellent (slang), be great (slang), be wonderful (slang), be splendid (slang), be profound (slang), be thorough (slang), be careful (slang)"
   }, 
   {
      id: 1852,
      word: "chonnaQ",
      name: "chonnaQ (n.) spear, hunting spear"
   }, 
   {
      id: 1853,
      word: "chontay",
      name: "chontay (n.) ritual hunt"
   }, 
   {
      id: 1854,
      word: "chop",
      name: "chop (v.) bite"
   }, 
   {
      id: 1855,
      word: "choptaH",
      name: "choptaH (v.) gnaw"
   }, 
   {
      id: 1856,
      word: "choq",
      name: "choq (p.n.) Howard Rowner"
   }, 
   {
      id: 1857,
      word: "choq",
      name: "choq (v.) preserve, save"
   }, 
   {
      id: 1858,
      word: "chor",
      name: "chor (n.) belly, ceramic flat-bottomed pot (regional), belly pot (regional)"
   }, 
   {
      id: 1859,
      word: "chor bargh",
      name: "chor bargh (n.) ceramic flat-bottomed pot (regional)"
   }, 
   {
      id: 1860,
      word: "chorgh",
      name: "chorgh (v.) be glossy"
   }, 
   {
      id: 1861,
      word: "chorgh",
      name: "chorgh (n.) eight tone of nonatonic musical scale"
   }, 
   {
      id: 1862,
      word: "chorgh",
      name: "chorgh (number) eight, 8"
   }, 
   {
      id: 1863,
      word: "chot",
      name: "chot (v.) murder"
   }, 
   {
      id: 1864,
      word: "chotlh",
      name: "chotlh (v.) stare at, gaze at, observe"
   }, 
   {
      id: 1865,
      word: "chotmang ",
      name: "chotmang  (n.) assassination"
   }, 
   {
      id: 1866,
      word: "chotwI'",
      name: "chotwI' (n.) murderer"
   }, 
   {
      id: 1867,
      word: "chov",
      name: "chov (v.) assess, evaluate"
   }, 
   {
      id: 1868,
      word: "chovnatlh",
      name: "chovnatlh (n.) specimen, example"
   }, 
   {
      id: 1869,
      word: "choy",
      name: "choy (v.) smuggle (only for people)"
   }, 
   {
      id: 1870,
      word: "choywI'",
      name: "choywI' (n.) smuggler (only for people)"
   }, 
   {
      id: 1871,
      word: "chu'",
      name: "chu' (v.) be new"
   }, 
   {
      id: 1872,
      word: "chu'",
      name: "chu' (vs6) clearly, perfectly"
   }, 
   {
      id: 1873,
      word: "chu'",
      name: "chu' (v.) engage, activate (a device)"
   }, 
   {
      id: 1874,
      word: "chu'",
      name: "chu' (v.) play (a musical instrument)"
   }, 
   {
      id: 1875,
      word: "chu'wI'",
      name: "chu'wI' (n.) player (of an instrument)"
   }, 
   {
      id: 1876,
      word: "chu'wI'",
      name: "chu'wI' (n.) trigger"
   }, 
   {
      id: 1877,
      word: "chuD",
      name: "chuD (n.) people, kin, member of the same group or tribe or clan"
   }, 
   {
      id: 1878,
      word: "chuH",
      name: "chuH (v.) throw (a spear) at, hurl (a spear) at, explain clearly to (slang), clarify for (slang), specify for (slang)"
   }, 
   {
      id: 1879,
      word: "chuHchu'",
      name: "chuHchu' (v.) hit with a thrown spear"
   }, 
   {
      id: 1880,
      word: "chuQun",
      name: "chuQun (n.) nobility"
   }, 
   {
      id: 1881,
      word: "chuS",
      name: "chuS (v.) be noisy"
   }, 
   {
      id: 1882,
      word: "chuS'ugh",
      name: "chuS'ugh (n.) musical instrument (type of)"
   }, 
   {
      id: 1883,
      word: "chuch",
      name: "chuch (n.) ice"
   }, 
   {
      id: 1884,
      word: "chugh",
      name: "chugh (vs9) if"
   }, 
   {
      id: 1885,
      word: "chul",
      name: "chul (v.) be wise"
   }, 
   {
      id: 1886,
      word: "chum",
      name: "chum (v.) be colorful"
   }, 
   {
      id: 1887,
      word: "chun",
      name: "chun (v.) be innocent"
   }, 
   {
      id: 1888,
      word: "chunDab",
      name: "chunDab (n.) meteor"
   }, 
   {
      id: 1889,
      word: "chung",
      name: "chung (v.) accelerate"
   }, 
   {
      id: 1890,
      word: "chungHa'wI'",
      name: "chungHa'wI' (n.) brake"
   }, 
   {
      id: 1891,
      word: "chup",
      name: "chup (v.) recommend, suggest"
   }, 
   {
      id: 1892,
      word: "chuq",
      name: "chuq (vs1) one another"
   }, 
   {
      id: 1893,
      word: "chuq",
      name: "chuq (n.) range, distance"
   }, 
   {
      id: 1894,
      word: "chuq'a'",
      name: "chuq'a' (n.) long range"
   }, 
   {
      id: 1895,
      word: "chuq'a' leghwI'",
      name: "chuq'a' leghwI' (n.) space telescope"
   }, 
   {
      id: 1896,
      word: "chur",
      name: "chur (v.) be uncomfortable"
   }, 
   {
      id: 1897,
      word: "churHa'",
      name: "churHa' (v.) be comfortable"
   }, 
   {
      id: 1898,
      word: "chut",
      name: "chut (n.) law"
   }, 
   {
      id: 1899,
      word: "chut qeSwI'",
      name: "chut qeSwI' (n.) lawyer"
   }, 
   {
      id: 1900,
      word: "chuv",
      name: "chuv (v.) be left over"
   }, 
   {
      id: 1901,
      word: "chuv",
      name: "chuv (n.) leftover"
   }, 
   {
      id: 1902,
      word: "chuvmey",
      name: "chuvmey (n.) leftovers (grammatical term)"
   }, 
   {
      id: 1903,
      word: "chuy",
      name: "chuy (v.) sneeze"
   }, 
   {
      id: 1904,
      word: "chuyDaH",
      name: "chuyDaH (n.) thrusters"
   }, 
   {
      id: 1905,
      word: "e'qIn tlhen",
      name: "e'qIn tlhen (v.) make a rustling sound, rustle"
   }, 
   {
      id: 1906,
      word: "ghI'boj",
      name: "ghI'boj (p.n.) G'boj"
   }, 
   {
      id: 1907,
      word: "ghI'nI",
      name: "ghI'nI (n.) Guinea"
   }, 
   {
      id: 1908,
      word: "ghI'neS",
      name: "ghI'neS (n.) Guinness"
   }, 
   {
      id: 1909,
      word: "ghI'van",
      name: "ghI'van (n.) griffin, griffon, gryphon"
   }, 
   {
      id: 1910,
      word: "ghID",
      name: "ghID (v.) pierce, perforate"
   }, 
   {
      id: 1911,
      word: "ghIH",
      name: "ghIH (v.) be messy, be sloppy"
   }, 
   {
      id: 1912,
      word: "ghIQ",
      name: "ghIQ (v.) vacation, take a vacation, go on a holiday"
   }, 
   {
      id: 1913,
      word: "ghIS",
      name: "ghIS (v.) wriggle, squirm"
   }, 
   {
      id: 1914,
      word: "ghISDen",
      name: "ghISDen (n.) scales (animal covering)"
   }, 
   {
      id: 1915,
      word: "ghISnar",
      name: "ghISnar (n.) grishnar cat"
   }, 
   {
      id: 1916,
      word: "ghIb",
      name: "ghIb (v.) consent"
   }, 
   {
      id: 1917,
      word: "ghIch",
      name: "ghIch (n.) nose"
   }, 
   {
      id: 1918,
      word: "ghIchDep",
      name: "ghIchDep (n.) fair, funfair, carnival, circus"
   }, 
   {
      id: 1919,
      word: "ghIgh",
      name: "ghIgh (n.) assignment, task, duty (slang)"
   }, 
   {
      id: 1920,
      word: "ghIgh",
      name: "ghIgh (n.) necklace"
   }, 
   {
      id: 1921,
      word: "ghIgh yIvbeH",
      name: "ghIgh yIvbeH (n.) turtleneck"
   }, 
   {
      id: 1922,
      word: "ghIj",
      name: "ghIj (v.) scare"
   }, 
   {
      id: 1923,
      word: "ghIl",
      name: "ghIl (v.) be the mean, be the average"
   }, 
   {
      id: 1924,
      word: "ghIlDeSten",
      name: "ghIlDeSten (p.n.) Guildenstern"
   }, 
   {
      id: 1925,
      word: "ghIlaSnoS",
      name: "ghIlaSnoS (n.) Glasnost - ancient political movement"
   }, 
   {
      id: 1926,
      word: "ghIlab ghew",
      name: "ghIlab ghew (n.) glob fly"
   }, 
   {
      id: 1927,
      word: "ghIm",
      name: "ghIm (v.) exile"
   }, 
   {
      id: 1928,
      word: "ghIn",
      name: "ghIn (n.) monastery"
   }, 
   {
      id: 1929,
      word: "ghInaq",
      name: "ghInaq (n.) grinnak - A game"
   }, 
   {
      id: 1930,
      word: "ghInebISaw",
      name: "ghInebISaw (n.) Guinea-Bissau"
   }, 
   {
      id: 1931,
      word: "ghIney'eqwatoryal",
      name: "ghIney'eqwatoryal (n.) Equatorial Guinea"
   }, 
   {
      id: 1932,
      word: "ghInjaj",
      name: "ghInjaj (n.) Saturday (Informal)"
   }, 
   {
      id: 1933,
      word: "ghIntaq",
      name: "ghIntaq (n.) Battle Spear, a specific kind of spear"
   }, 
   {
      id: 1934,
      word: "ghIp'IS",
      name: "ghIp'IS (n.) friction"
   }, 
   {
      id: 1935,
      word: "ghIpDIj",
      name: "ghIpDIj (v.) court-martial"
   }, 
   {
      id: 1936,
      word: "ghIq",
      name: "ghIq (adverb) then, subsequently"
   }, 
   {
      id: 1937,
      word: "ghIqtal",
      name: "ghIqtal (exclamation) to the death (archaic)"
   }, 
   {
      id: 1938,
      word: "ghIqtu'",
      name: "ghIqtu' (n.) mathematical or chemical formula"
   }, 
   {
      id: 1939,
      word: "ghIr",
      name: "ghIr (v.) descend"
   }, 
   {
      id: 1940,
      word: "ghIrIlqa'",
      name: "ghIrIlqa' (p.n.) Grilka"
   }, 
   {
      id: 1941,
      word: "ghIrep naH",
      name: "ghIrep naH (n.) grape"
   }, 
   {
      id: 1942,
      word: "ghIrep naHmey",
      name: "ghIrep naHmey (n.) grapes"
   }, 
   {
      id: 1943,
      word: "ghIt",
      name: "ghIt (n.) ax blade, blade of axe"
   }, 
   {
      id: 1944,
      word: "ghIt",
      name: "ghIt (v.) flow (e.g., water), gush, spout"
   }, 
   {
      id: 1945,
      word: "ghIt",
      name: "ghIt (n.) open, flat hand"
   }, 
   {
      id: 1946,
      word: "ghItlh",
      name: "ghItlh (n.) manuscript"
   }, 
   {
      id: 1947,
      word: "ghItlh",
      name: "ghItlh (v.) write, mark (upon), engrave, incise"
   }, 
   {
      id: 1948,
      word: "ghItlh raS",
      name: "ghItlh raS (n.) desk"
   }, 
   {
      id: 1949,
      word: "ghItlhjaj",
      name: "ghItlhjaj (n.) Wednesday"
   }, 
   {
      id: 1950,
      word: "ghItlhwI'",
      name: "ghItlhwI' (n.) stylus, writing implement, person who writes"
   }, 
   {
      id: 1951,
      word: "ghItlhwI' 'echlet",
      name: "ghItlhwI' 'echlet (n.) chalk board, flip chart"
   }, 
   {
      id: 1952,
      word: "ghItwI'",
      name: "ghItwI' (n.) geyser"
   }, 
   {
      id: 1953,
      word: "ghIv",
      name: "ghIv (n.) limb (of a person)"
   }, 
   {
      id: 1954,
      word: "gha",
      name: "gha (v.) diaphanous, be see-through"
   }, 
   {
      id: 1955,
      word: "gha'cher",
      name: "gha'cher (n.) goat-like creature"
   }, 
   {
      id: 1956,
      word: "gha'na",
      name: "gha'na (n.) Ghana"
   }, 
   {
      id: 1957,
      word: "gha'naD",
      name: "gha'naD (n.) fodder, animal feed"
   }, 
   {
      id: 1958,
      word: "gha'poq",
      name: "gha'poq (n.) grapok sauce"
   }, 
   {
      id: 1959,
      word: "gha'tlhIq",
      name: "gha'tlhIq (n.) GaTH'K, Ode of Respect"
   }, 
   {
      id: 1960,
      word: "gha'vIq",
      name: "gha'vIq (p.n.) Grafk"
   }, 
   {
      id: 1961,
      word: "ghaH",
      name: "ghaH (pronoun) he, she, him, her"
   }, 
   {
      id: 1962,
      word: "ghaQpey'",
      name: "ghaQpey' (n.) biological sex"
   }, 
   {
      id: 1963,
      word: "ghaS",
      name: "ghaS (v.) indicate, signal"
   }, 
   {
      id: 1964,
      word: "ghab",
      name: "ghab (v.) kill (when on a hunt)"
   }, 
   {
      id: 1965,
      word: "ghab",
      name: "ghab (n.) meat from midsection of animal"
   }, 
   {
      id: 1966,
      word: "ghab tun",
      name: "ghab tun (n.) meat from midsection of animal, no bones (regional)"
   }, 
   {
      id: 1967,
      word: "ghabon",
      name: "ghabon (n.) Gabon"
   }, 
   {
      id: 1968,
      word: "ghach",
      name: "ghach (v.) lurk, lie in wait, lie low in order to ambush someone, be hidden but still pose a threat"
   }, 
   {
      id: 1969,
      word: "ghach",
      name: "ghach (vs9) nominalizer"
   }, 
   {
      id: 1970,
      word: "ghagh",
      name: "ghagh (v.) gargle"
   }, 
   {
      id: 1971,
      word: "ghaj",
      name: "ghaj (v.) have, possess"
   }, 
   {
      id: 1972,
      word: "ghal",
      name: "ghal (v.) envy, be jealous (of)"
   }, 
   {
      id: 1973,
      word: "ghalmaH",
      name: "ghalmaH (n.) splinter, sliver"
   }, 
   {
      id: 1974,
      word: "ghalmov",
      name: "ghalmov (n.) compound (chemical)"
   }, 
   {
      id: 1975,
      word: "gham",
      name: "gham (n.) limb (of an animal)"
   }, 
   {
      id: 1976,
      word: "gham na'",
      name: "gham na' (n.) ham"
   }, 
   {
      id: 1977,
      word: "ghan",
      name: "ghan (v.) be hectic, be very active, be lively"
   }, 
   {
      id: 1978,
      word: "ghan",
      name: "ghan (v.) glance at, take a quick look at"
   }, 
   {
      id: 1979,
      word: "ghan'Iq",
      name: "ghan'Iq (n.) police force"
   }, 
   {
      id: 1980,
      word: "ghan'Iq yaS",
      name: "ghan'Iq yaS (n.) police officer"
   }, 
   {
      id: 1981,
      word: "ghan'ach",
      name: "ghan'ach (n.) seizure, convulsion (medical)"
   }, 
   {
      id: 1982,
      word: "ghanHa'",
      name: "ghanHa' (v.) be peaceful, be calm"
   }, 
   {
      id: 1983,
      word: "ghang",
      name: "ghang (v.) end prematurely (an event, voyage, battle, play, opera, story, song, etc.)"
   }, 
   {
      id: 1984,
      word: "ghangwI'",
      name: "ghangwI' (n.) horizon"
   }, 
   {
      id: 1985,
      word: "ghanjaq",
      name: "ghanjaq (n.) mace (stick, club)"
   }, 
   {
      id: 1986,
      word: "ghanroq",
      name: "ghanroq (n.) basis, foundation"
   }, 
   {
      id: 1987,
      word: "ghantoH",
      name: "ghantoH (n.) model, example, pattern"
   }, 
   {
      id: 1988,
      word: "ghap",
      name: "ghap (conjunction) or, either/or (joining nouns)"
   }, 
   {
      id: 1989,
      word: "ghapqa'",
      name: "ghapqa' (n.) jaw"
   }, 
   {
      id: 1990,
      word: "ghaptal",
      name: "ghaptal (n.) equator"
   }, 
   {
      id: 1991,
      word: "ghaq",
      name: "ghaq (v.) contribute"
   }, 
   {
      id: 1992,
      word: "ghar",
      name: "ghar (v.) conduct diplomacy"
   }, 
   {
      id: 1993,
      word: "ghar",
      name: "ghar (n.) diplomacy"
   }, 
   {
      id: 1994,
      word: "gharDaq",
      name: "gharDaq (n.) loneliness"
   }, 
   {
      id: 1995,
      word: "ghargh",
      name: "ghargh (n.) serpent, snake, worm"
   }, 
   {
      id: 1996,
      word: "gharlIq 'oQqar",
      name: "gharlIq 'oQqar (n.) garlic"
   }, 
   {
      id: 1997,
      word: "gharwI'",
      name: "gharwI' (n.) diplomat"
   }, 
   {
      id: 1998,
      word: "ghatlh",
      name: "ghatlh (v.) dominate"
   }, 
   {
      id: 1999,
      word: "ghav",
      name: "ghav (n.) carbon (element)"
   }, 
   {
      id: 2000,
      word: "ghav 'uSqan",
      name: "ghav 'uSqan (n.) steel"
   }, 
   {
      id: 2001,
      word: "ghaw",
      name: "ghaw (v.) excavate, dig (a hole, trench, ditch, etc.)"
   }, 
   {
      id: 2002,
      word: "ghaw'",
      name: "ghaw' (n.) igvah liver soup"
   }, 
   {
      id: 2003,
      word: "ghaw'",
      name: "ghaw' (n.) insecure one, one full of self-doubt, self-doubter (regional slang)"
   }, 
   {
      id: 2004,
      word: "ghawran",
      name: "ghawran (p.n.) Gowron"
   }, 
   {
      id: 2005,
      word: "ghay",
      name: "ghay (v.) spray, bombard(?)"
   }, 
   {
      id: 2006,
      word: "ghay'cha'",
      name: "ghay'cha' (exclamation) (curse) general invective"
   }, 
   {
      id: 2007,
      word: "ghaytan",
      name: "ghaytan (adverb) likely"
   }, 
   {
      id: 2008,
      word: "ghaytanHa'",
      name: "ghaytanHa' (adverb) unlikely"
   }, 
   {
      id: 2009,
      word: "ghe'",
      name: "ghe' (v.) be transformed, transmuted, metamorphosed, totally altered"
   }, 
   {
      id: 2010,
      word: "ghe''or",
      name: "ghe''or (n.) netherworld (where dishonored go)"
   }, 
   {
      id: 2011,
      word: "ghe'naQ",
      name: "ghe'naQ (n.) opera"
   }, 
   {
      id: 2012,
      word: "ghe'tor",
      name: "ghe'tor (n.) Gre'thor (where spirits of dishonored go)"
   }, 
   {
      id: 2013,
      word: "gheD",
      name: "gheD (n.) prey"
   }, 
   {
      id: 2014,
      word: "gheH",
      name: "gheH (v.) have a temperature of"
   }, 
   {
      id: 2015,
      word: "gheS",
      name: "gheS (v.) assume (duties of), take on (the responsibilities of)"
   }, 
   {
      id: 2016,
      word: "gheb",
      name: "gheb (n.) horn (musical instrument)"
   }, 
   {
      id: 2017,
      word: "ghegh",
      name: "ghegh (v.) be rough"
   }, 
   {
      id: 2018,
      word: "ghel",
      name: "ghel (v.) ask (a question)"
   }, 
   {
      id: 2019,
      word: "ghem",
      name: "ghem (n.) midnight snack"
   }, 
   {
      id: 2020,
      word: "ghen",
      name: "ghen (v.) be operative, in effect, valid"
   }, 
   {
      id: 2021,
      word: "ghene'Da",
      name: "ghene'Da (n.) Grenada"
   }, 
   {
      id: 2022,
      word: "ghenlan",
      name: "ghenlan (p.n.) Greenland"
   }, 
   {
      id: 2023,
      word: "ghenraq",
      name: "ghenraq (n.) orchestra"
   }, 
   {
      id: 2024,
      word: "ghep",
      name: "ghep (v.) hug, embrace"
   }, 
   {
      id: 2025,
      word: "gher",
      name: "gher (v.) formulate, compile, pull together"
   }, 
   {
      id: 2026,
      word: "gher'ID",
      name: "gher'ID (n.) results, outcome, effect, repercussions, consequence"
   }, 
   {
      id: 2027,
      word: "ghertlhuD",
      name: "ghertlhuD (p.n.) Gertrude"
   }, 
   {
      id: 2028,
      word: "ghet",
      name: "ghet (v.) pretend (without deceiving)"
   }, 
   {
      id: 2029,
      word: "ghetwI'",
      name: "ghetwI' (n.) pretender"
   }, 
   {
      id: 2030,
      word: "ghevI'",
      name: "ghevI' (n.) sauce for gagh"
   }, 
   {
      id: 2031,
      word: "ghevchoq Sep",
      name: "ghevchoq Sep (n.) Gevchok region"
   }, 
   {
      id: 2032,
      word: "ghevjur",
      name: "ghevjur (n.) shovel"
   }, 
   {
      id: 2033,
      word: "ghew",
      name: "ghew (n.) bug, cootie"
   }, 
   {
      id: 2034,
      word: "ghew Duj",
      name: "ghew Duj (n.) helicopter (slang)"
   }, 
   {
      id: 2035,
      word: "gho",
      name: "gho (n.) circle, hoop"
   }, 
   {
      id: 2036,
      word: "gho",
      name: "gho (vp) imp: you (s/pl)-us"
   }, 
   {
      id: 2037,
      word: "gho 'Impey'",
      name: "gho 'Impey' (n.) cone (lit: circle pyramid)"
   }, 
   {
      id: 2038,
      word: "gho SubmaH",
      name: "gho SubmaH (number) pi"
   }, 
   {
      id: 2039,
      word: "gho lang",
      name: "gho lang (n.) oval"
   }, 
   {
      id: 2040,
      word: "gho paq",
      name: "gho paq (n.) binder, notebook (something you can add and remove pages from)"
   }, 
   {
      id: 2041,
      word: "gho tut",
      name: "gho tut (n.) cylinder (lit: circle column)"
   }, 
   {
      id: 2042,
      word: "gho'",
      name: "gho' (v.) step on"
   }, 
   {
      id: 2043,
      word: "gho''ong",
      name: "gho''ong (n.) magic trick"
   }, 
   {
      id: 2044,
      word: "gho''ong Ho'DoS",
      name: "gho''ong Ho'DoS (n.) magic (trick) technique"
   }, 
   {
      id: 2045,
      word: "gho'Do",
      name: "gho'Do (n.) sublight speed"
   }, 
   {
      id: 2046,
      word: "gho'lIv",
      name: "gho'lIv (n.) golf"
   }, 
   {
      id: 2047,
      word: "gho'rIch",
      name: "gho'rIch (n.) zit, acne, pimple"
   }, 
   {
      id: 2048,
      word: "ghoD",
      name: "ghoD (v.) stuff"
   }, 
   {
      id: 2049,
      word: "ghoH",
      name: "ghoH (v.) argue, dispute"
   }, 
   {
      id: 2050,
      word: "ghoQ",
      name: "ghoQ (v.) be fresh, be just killed (meat)"
   }, 
   {
      id: 2051,
      word: "ghoQ",
      name: "ghoQ (v.) be most recent"
   }, 
   {
      id: 2052,
      word: "ghoS",
      name: "ghoS (v.) approach, proceed, come, follow (a course), go away from"
   }, 
   {
      id: 2053,
      word: "ghoS",
      name: "ghoS (v.) thrust"
   }, 
   {
      id: 2054,
      word: "ghob",
      name: "ghob (n.) ethics, virtue"
   }, 
   {
      id: 2055,
      word: "ghob",
      name: "ghob (v.) fight, battle, do battle, wage war"
   }, 
   {
      id: 2056,
      word: "ghob",
      name: "ghob (n.) virtue"
   }, 
   {
      id: 2057,
      word: "ghobchuq loDnI'pu'",
      name: "ghobchuq loDnI'pu' (p.n.) The Brothers Fight One Another - famous statue"
   }, 
   {
      id: 2058,
      word: "ghobe'",
      name: "ghobe' (exclamation) no, untrue (answer to a yes/no question)"
   }, 
   {
      id: 2059,
      word: "ghoch",
      name: "ghoch (n.) destination"
   }, 
   {
      id: 2060,
      word: "ghoch",
      name: "ghoch (v.) track, track down"
   }, 
   {
      id: 2061,
      word: "ghochwI'",
      name: "ghochwI' (n.) the constellation called Tracker"
   }, 
   {
      id: 2062,
      word: "ghogh",
      name: "ghogh (n.) voice"
   }, 
   {
      id: 2063,
      word: "ghogh HablI'",
      name: "ghogh HablI' (n.) telephone"
   }, 
   {
      id: 2064,
      word: "ghogh'ot",
      name: "ghogh'ot (n.) bill, payment request, something you must pay"
   }, 
   {
      id: 2065,
      word: "ghoj",
      name: "ghoj (v.) learn"
   }, 
   {
      id: 2066,
      word: "ghojmeH taj",
      name: "ghojmeH taj (n.) boy's knife"
   }, 
   {
      id: 2067,
      word: "ghojmoH",
      name: "ghojmoH (v.) teach, instruct"
   }, 
   {
      id: 2068,
      word: "ghojmoHwI'",
      name: "ghojmoHwI' (n.) teacher"
   }, 
   {
      id: 2069,
      word: "ghojmoq",
      name: "ghojmoq (n.) nurse, nanny, governess"
   }, 
   {
      id: 2070,
      word: "ghojwI'",
      name: "ghojwI' (n.) student"
   }, 
   {
      id: 2071,
      word: "ghol",
      name: "ghol (n.) opponent, adversary"
   }, 
   {
      id: 2072,
      word: "gholeq",
      name: "gholeq (n.) flake"
   }, 
   {
      id: 2073,
      word: "gholeqmey",
      name: "gholeqmey (n.) cereal, like a breakfast cereal"
   }, 
   {
      id: 2074,
      word: "ghom",
      name: "ghom (n.) band, group, party"
   }, 
   {
      id: 2075,
      word: "ghom",
      name: "ghom (n.) group"
   }, 
   {
      id: 2076,
      word: "ghom",
      name: "ghom (v.) meet, assemble, encounter"
   }, 
   {
      id: 2077,
      word: "ghom'a'",
      name: "ghom'a' (n.) crowd"
   }, 
   {
      id: 2078,
      word: "ghom'oH",
      name: "ghom'oH (n.) slot, slit"
   }, 
   {
      id: 2079,
      word: "ghomHa'",
      name: "ghomHa' (v.) scatter, disperse"
   }, 
   {
      id: 2080,
      word: "ghommeH yotlh",
      name: "ghommeH yotlh (n.) plaza, courtyard"
   }, 
   {
      id: 2081,
      word: "ghon",
      name: "ghon (v.) sparkle, glitter"
   }, 
   {
      id: 2082,
      word: "ghonDoq",
      name: "ghonDoq (n.) knife with a slender blade"
   }, 
   {
      id: 2083,
      word: "ghong",
      name: "ghong (n.) abuse"
   }, 
   {
      id: 2084,
      word: "ghong",
      name: "ghong (v.) abuse"
   }, 
   {
      id: 2085,
      word: "ghong",
      name: "ghong (v.) exploit"
   }, 
   {
      id: 2086,
      word: "ghop",
      name: "ghop (n.) hand"
   }, 
   {
      id: 2087,
      word: "ghop 'etlh",
      name: "ghop 'etlh (n.) type of blade weapon"
   }, 
   {
      id: 2088,
      word: "ghopDap",
      name: "ghopDap (n.) asteroid"
   }, 
   {
      id: 2089,
      word: "ghoq",
      name: "ghoq (v.) spy, spy on"
   }, 
   {
      id: 2090,
      word: "ghoqchuy",
      name: "ghoqchuy (n.) (data) stream, feed"
   }, 
   {
      id: 2091,
      word: "ghoqwI'",
      name: "ghoqwI' (n.) spy"
   }, 
   {
      id: 2092,
      word: "ghor",
      name: "ghor (p.n.) Anttila Riku-Pekka"
   }, 
   {
      id: 2093,
      word: "ghor",
      name: "ghor (v.) break"
   }, 
   {
      id: 2094,
      word: "ghor",
      name: "ghor (n.) surface (of a planet)"
   }, 
   {
      id: 2095,
      word: "ghor'In",
      name: "ghor'In (n.) Gorn"
   }, 
   {
      id: 2096,
      word: "ghorgh",
      name: "ghorgh (question) when?"
   }, 
   {
      id: 2097,
      word: "ghormaghenDer",
      name: "ghormaghenDer (n.) gormagander"
   }, 
   {
      id: 2098,
      word: "ghormlIy",
      name: "ghormlIy (p.n.) Siobhan Gormley"
   }, 
   {
      id: 2099,
      word: "ghorqon",
      name: "ghorqon (p.n.) Gorkon"
   }, 
   {
      id: 2100,
      word: "ghot",
      name: "ghot (n.) person (humanoid)"
   }, 
   {
      id: 2101,
      word: "ghotI'",
      name: "ghotI' (n.) fish, most general word for fish-like creature"
   }, 
   {
      id: 2102,
      word: "ghov",
      name: "ghov (v.) recognize"
   }, 
   {
      id: 2103,
      word: "ghowron",
      name: "ghowron (p.n.) Gowron"
   }, 
   {
      id: 2104,
      word: "ghu",
      name: "ghu (n.) baby"
   }, 
   {
      id: 2105,
      word: "ghu'",
      name: "ghu' (n.) situation"
   }, 
   {
      id: 2106,
      word: "ghu'jarat",
      name: "ghu'jarat (n.) Gujarat"
   }, 
   {
      id: 2107,
      word: "ghu'lIS",
      name: "ghu'lIS (n.) item in a list"
   }, 
   {
      id: 2108,
      word: "ghuD",
      name: "ghuD (v.) be in common, be co-"
   }, 
   {
      id: 2109,
      word: "ghuH",
      name: "ghuH (n.) alert"
   }, 
   {
      id: 2110,
      word: "ghuH",
      name: "ghuH (v.) be alerted to, be prepared for"
   }, 
   {
      id: 2111,
      word: "ghuHmoH",
      name: "ghuHmoH (v.) alert, warn"
   }, 
   {
      id: 2112,
      word: "ghuQ",
      name: "ghuQ (n.) poem"
   }, 
   {
      id: 2113,
      word: "ghuS",
      name: "ghuS (v.) be prepared, be ready (to launch)"
   }, 
   {
      id: 2114,
      word: "ghuS",
      name: "ghuS (v.) lower (spear) to horizontal to attack"
   }, 
   {
      id: 2115,
      word: "ghub",
      name: "ghub (n.) bud (the flower, fruit, or shoot before it develops)"
   }, 
   {
      id: 2116,
      word: "ghubDaQ",
      name: "ghubDaQ (n.) first born child, firstborn"
   }, 
   {
      id: 2117,
      word: "ghuch",
      name: "ghuch (v.) climax"
   }, 
   {
      id: 2118,
      word: "ghugh",
      name: "ghugh (v.) vocalize"
   }, 
   {
      id: 2119,
      word: "ghughugh",
      name: "ghughugh (v.) growl"
   }, 
   {
      id: 2120,
      word: "ghuj",
      name: "ghuj (v.) pivot, swivel"
   }, 
   {
      id: 2121,
      word: "ghujmoH",
      name: "ghujmoH (v.) pivot, swivel (a thing)"
   }, 
   {
      id: 2122,
      word: "ghul",
      name: "ghul (n.) bump, protuberance"
   }, 
   {
      id: 2123,
      word: "ghum",
      name: "ghum (n.) alarm"
   }, 
   {
      id: 2124,
      word: "ghum",
      name: "ghum (v.) alarm"
   }, 
   {
      id: 2125,
      word: "ghun",
      name: "ghun (v.) be warm"
   }, 
   {
      id: 2126,
      word: "ghun",
      name: "ghun (v.) program (a computer)"
   }, 
   {
      id: 2127,
      word: "ghunchu'wI'",
      name: "ghunchu'wI' (p.n.) Alan Anderson"
   }, 
   {
      id: 2128,
      word: "ghung",
      name: "ghung (v.) be hungry"
   }, 
   {
      id: 2129,
      word: "ghunglItlh",
      name: "ghunglItlh (n.) piston"
   }, 
   {
      id: 2130,
      word: "ghunta",
      name: "ghunta (n.) check, promissory note"
   }, 
   {
      id: 2131,
      word: "ghup",
      name: "ghup (v.) swallow"
   }, 
   {
      id: 2132,
      word: "ghur",
      name: "ghur (v.) increase"
   }, 
   {
      id: 2133,
      word: "ghut",
      name: "ghut (v.) predict (based on intuition)"
   }, 
   {
      id: 2134,
      word: "ghuv",
      name: "ghuv (n.) recruit"
   }, 
   {
      id: 2135,
      word: "ghuwan",
      name: "ghuwan (n.) Rouen"
   }, 
   {
      id: 2136,
      word: "ghuwatema'la",
      name: "ghuwatema'la (n.) Guatemala"
   }, 
   {
      id: 2137,
      word: "ghuwongDung Hol",
      name: "ghuwongDung Hol (n.) Cantonese"
   }, 
   {
      id: 2138,
      word: "ghuy'",
      name: "ghuy' (exclamation) (curse) general invective"
   }, 
   {
      id: 2139,
      word: "ghuy'Do",
      name: "ghuy'Do (p.n.) (DLS9@aol.com)"
   }, 
   {
      id: 2140,
      word: "ghuy'cha'",
      name: "ghuy'cha' (exclamation) (curse) general invective"
   }, 
   {
      id: 2141,
      word: "ghwI'nItlh",
      name: "ghwI'nItlh (p.n.) Gwynyth"
   }, 
   {
      id: 2142,
      word: "jI",
      name: "jI (vp) I-"
   }, 
   {
      id: 2143,
      word: "jI'ev",
      name: "jI'ev (n.) handle, knob, doorknob"
   }, 
   {
      id: 2144,
      word: "jIH",
      name: "jIH (pronoun) I, me"
   }, 
   {
      id: 2145,
      word: "jIH",
      name: "jIH (v.) monitor"
   }, 
   {
      id: 2146,
      word: "jIH",
      name: "jIH (n.) monitor, viewing screen"
   }, 
   {
      id: 2147,
      word: "jIb",
      name: "jIb (n.) hair (on head)"
   }, 
   {
      id: 2148,
      word: "jIb",
      name: "jIb (v.) lynch, execute by hanging"
   }, 
   {
      id: 2149,
      word: "jIb'egh",
      name: "jIb'egh (v.) suicide by hanging"
   }, 
   {
      id: 2150,
      word: "jIbutIy",
      name: "jIbutIy (n.) Djibouti"
   }, 
   {
      id: 2151,
      word: "jIj",
      name: "jIj (v.) be cooperative"
   }, 
   {
      id: 2152,
      word: "jIj",
      name: "jIj (v.) cooperate"
   }, 
   {
      id: 2153,
      word: "jIl",
      name: "jIl (n.) neighbor"
   }, 
   {
      id: 2154,
      word: "jIm",
      name: "jIm (v.) shrug, heave (aircraft rising or falling without pitching)"
   }, 
   {
      id: 2155,
      word: "jIn",
      name: "jIn (v.) wish"
   }, 
   {
      id: 2156,
      word: "jIn yopwaH",
      name: "jIn yopwaH (n.) jeans"
   }, 
   {
      id: 2157,
      word: "jInaq",
      name: "jInaq (n.) amulet symbolizing a girl's coming of age"
   }, 
   {
      id: 2158,
      word: "jInay'",
      name: "jInay' (n.) J'naii"
   }, 
   {
      id: 2159,
      word: "jInbo'",
      name: "jInbo' (n.) bias"
   }, 
   {
      id: 2160,
      word: "jInmol",
      name: "jInmol (n.) project"
   }, 
   {
      id: 2161,
      word: "jInmol pa'",
      name: "jInmol pa' (n.) studio, workspace"
   }, 
   {
      id: 2162,
      word: "jIp",
      name: "jIp (n.) penalty"
   }, 
   {
      id: 2163,
      word: "jIqlem",
      name: "jIqlem (n.) strap"
   }, 
   {
      id: 2164,
      word: "jIqlem waq",
      name: "jIqlem waq (n.) sandal"
   }, 
   {
      id: 2165,
      word: "jIr",
      name: "jIr (v.) rotate, twirl"
   }, 
   {
      id: 2166,
      word: "jIrev",
      name: "jIrev (n.) giraffe"
   }, 
   {
      id: 2167,
      word: "jIrmoH",
      name: "jIrmoH (v.) crank, turn a doorknob"
   }, 
   {
      id: 2168,
      word: "jIrmoH",
      name: "jIrmoH (v.) pedal"
   }, 
   {
      id: 2169,
      word: "jIrmoH",
      name: "jIrmoH (v.) twirl bat'leth, cause bat'leth to rotate"
   }, 
   {
      id: 2170,
      word: "jIrwI' Duj",
      name: "jIrwI' Duj (n.) helicopter (slang)"
   }, 
   {
      id: 2171,
      word: "jItuj'ep",
      name: "jItuj'ep (n.) mummy"
   }, 
   {
      id: 2172,
      word: "jItuj'ep ngutlh",
      name: "jItuj'ep ngutlh (n.) mummification glyph"
   }, 
   {
      id: 2173,
      word: "jIv",
      name: "jIv (v.) be ignorant"
   }, 
   {
      id: 2174,
      word: "jIvvo'",
      name: "jIvvo' (n.) criminal, villain, malefactor"
   }, 
   {
      id: 2175,
      word: "jIy",
      name: "jIy (v.) be umami, be savory, be earthy"
   }, 
   {
      id: 2176,
      word: "jIyeStaS",
      name: "jIyeStaS (n.) inflammation"
   }, 
   {
      id: 2177,
      word: "jIyweS",
      name: "jIyweS (n.) translation, gloss"
   }, 
   {
      id: 2178,
      word: "ja'",
      name: "ja' (v.) tell, report"
   }, 
   {
      id: 2179,
      word: "ja'chuq",
      name: "ja'chuq (v.) discuss, confer"
   }, 
   {
      id: 2180,
      word: "ja'chuq",
      name: "ja'chuq (n.) succession ritual (ancient)"
   }, 
   {
      id: 2181,
      word: "jaD",
      name: "jaD (v.) toss something, throw around, hurl about"
   }, 
   {
      id: 2182,
      word: "jaDchu'",
      name: "jaDchu' (v.) juggle (objects, not tasks)"
   }, 
   {
      id: 2183,
      word: "jaH",
      name: "jaH (v.) go"
   }, 
   {
      id: 2184,
      word: "jaQ",
      name: "jaQ (v.) be deep"
   }, 
   {
      id: 2185,
      word: "jaS",
      name: "jaS (adverb) differently"
   }, 
   {
      id: 2186,
      word: "jaSHa'",
      name: "jaSHa' (adverb) similarly"
   }, 
   {
      id: 2187,
      word: "jaSrob",
      name: "jaSrob (n.) cable"
   }, 
   {
      id: 2188,
      word: "jab",
      name: "jab (v.) serve (food)"
   }, 
   {
      id: 2189,
      word: "jabbI'ID",
      name: "jabbI'ID (n.) data transmission"
   }, 
   {
      id: 2190,
      word: "jabwI'",
      name: "jabwI' (n.) food server, waiter, waitress"
   }, 
   {
      id: 2191,
      word: "jabwI'",
      name: "jabwI' (n.) waiter"
   }, 
   {
      id: 2192,
      word: "jach",
      name: "jach (v.) scream, cry out, shout, yell"
   }, 
   {
      id: 2193,
      word: "jagh",
      name: "jagh (n.) enemy"
   }, 
   {
      id: 2194,
      word: "jaghIv",
      name: "jaghIv (n.) rhythm"
   }, 
   {
      id: 2195,
      word: "jaghla'",
      name: "jaghla' (n.) enemy commander"
   }, 
   {
      id: 2196,
      word: "jaj",
      name: "jaj (n.) day (from dawn to dawn)"
   }, 
   {
      id: 2197,
      word: "jaj",
      name: "jaj (vs9) may"
   }, 
   {
      id: 2198,
      word: "jajlo'",
      name: "jajlo' (n.) dawn"
   }, 
   {
      id: 2199,
      word: "jajlo' Qa'",
      name: "jajlo' Qa' (n.) rooster-like noisy animal (not a bird) known for making a ruckus at dawn"
   }, 
   {
      id: 2200,
      word: "jajlo' chum",
      name: "jajlo' chum (n.) sunrise (colourful sky seen at dawn)"
   }, 
   {
      id: 2201,
      word: "jajvam",
      name: "jajvam (n.) today"
   }, 
   {
      id: 2202,
      word: "jal",
      name: "jal (v.) imagine, envision"
   }, 
   {
      id: 2203,
      word: "jame'qa",
      name: "jame'qa (n.) Jamaica"
   }, 
   {
      id: 2204,
      word: "jamjuD",
      name: "jamjuD (n.) bounty"
   }, 
   {
      id: 2205,
      word: "jamtlhach",
      name: "jamtlhach (n.) phosphorus"
   }, 
   {
      id: 2206,
      word: "jan",
      name: "jan (n.) device, musical instrument"
   }, 
   {
      id: 2207,
      word: "jan",
      name: "jan (p.n.) John"
   }, 
   {
      id: 2208,
      word: "janIj",
      name: "janIj (n.) bra"
   }, 
   {
      id: 2209,
      word: "janSIy",
      name: "janSIy (p.n.) Jeremy Cowan"
   }, 
   {
      id: 2210,
      word: "janbI'",
      name: "janbI' (n.) slope"
   }, 
   {
      id: 2211,
      word: "jang",
      name: "jang (v.) answer, reply"
   }, 
   {
      id: 2212,
      word: "janluq pIqarD HoD",
      name: "janluq pIqarD HoD (p.n.) Captain Jean-Luc Picard"
   }, 
   {
      id: 2213,
      word: "jantor",
      name: "jantor (n.) witness"
   }, 
   {
      id: 2214,
      word: "jaq",
      name: "jaq (v.) be bold"
   }, 
   {
      id: 2215,
      word: "jaqmoH",
      name: "jaqmoH (v.) embolden"
   }, 
   {
      id: 2216,
      word: "jaqtala'",
      name: "jaqtala' (n.) puberty, /jak'tahla/ (Klingon)"
   }, 
   {
      id: 2217,
      word: "jar",
      name: "jar (n.) month (Klingon)"
   }, 
   {
      id: 2218,
      word: "jargh",
      name: "jargh (n.) forehead (regional)"
   }, 
   {
      id: 2219,
      word: "jarjaj",
      name: "jarjaj (n.) anniversary measured in months"
   }, 
   {
      id: 2220,
      word: "jat",
      name: "jat (v.) speak incoherently (slang), mumble (slang)"
   }, 
   {
      id: 2221,
      word: "jat",
      name: "jat (n.) tongue"
   }, 
   {
      id: 2222,
      word: "jat Hol",
      name: "jat Hol (n.) gibberish"
   }, 
   {
      id: 2223,
      word: "jatlh",
      name: "jatlh (v.) say, tell, speak"
   }, 
   {
      id: 2224,
      word: "jatlh; ghughughwI' rur",
      name: "jatlh; ghughughwI' rur (v.) speak with vocal fry"
   }, 
   {
      id: 2225,
      word: "jatyIn",
      name: "jatyIn (n.) spiritual possession"
   }, 
   {
      id: 2226,
      word: "jav",
      name: "jav (n.) prisoner (slang)"
   }, 
   {
      id: 2227,
      word: "jav",
      name: "jav (number) six, 6"
   }, 
   {
      id: 2228,
      word: "jav",
      name: "jav (n.) sixth tone of nonatonic musical scale"
   }, 
   {
      id: 2229,
      word: "jav mIS",
      name: "jav mIS (n.) a stuck person (slang), ditherer (slang), confused prisoner (slang), mixed-up prisoner (slang)"
   }, 
   {
      id: 2230,
      word: "javtIm",
      name: "javtIm (n.) virus"
   }, 
   {
      id: 2231,
      word: "javtIm raS'IS",
      name: "javtIm raS'IS (n.) vaccine"
   }, 
   {
      id: 2232,
      word: "jaw",
      name: "jaw (v.) chat"
   }, 
   {
      id: 2233,
      word: "jaw",
      name: "jaw (n.) lord"
   }, 
   {
      id: 2234,
      word: "jay'",
      name: "jay' (adverb) intensely (invective)"
   }, 
   {
      id: 2235,
      word: "je",
      name: "je (adverb) also"
   }, 
   {
      id: 2236,
      word: "je",
      name: "je (conjugation) also, and (joining nouns)"
   }, 
   {
      id: 2237,
      word: "je'",
      name: "je' (v.) buy, purchase"
   }, 
   {
      id: 2238,
      word: "je'",
      name: "je' (v.) feed (someone else), enrich (the spirit)"
   }, 
   {
      id: 2239,
      word: "je'ton",
      name: "je'ton (n.) counter / workbench"
   }, 
   {
      id: 2240,
      word: "je'wagh'en",
      name: "je'wagh'en (n.) louse-like creature"
   }, 
   {
      id: 2241,
      word: "jeD",
      name: "jeD (v.) be thick, be dense, be viscous"
   }, 
   {
      id: 2242,
      word: "jeH",
      name: "jeH (v.) be absentminded"
   }, 
   {
      id: 2243,
      word: "jeQ",
      name: "jeQ (v.) be selfconfident"
   }, 
   {
      id: 2244,
      word: "jeS",
      name: "jeS (n.) jazz"
   }, 
   {
      id: 2245,
      word: "jeS",
      name: "jeS (v.) participate"
   }, 
   {
      id: 2246,
      word: "jeS QoQ",
      name: "jeS QoQ (n.) jazz music"
   }, 
   {
      id: 2247,
      word: "jech",
      name: "jech (v.) disguise"
   }, 
   {
      id: 2248,
      word: "jech",
      name: "jech (n.) disguise, costume"
   }, 
   {
      id: 2249,
      word: "jegh",
      name: "jegh (v.) surrender, give up, capitulate, acquiesce, cave (in), back down"
   }, 
   {
      id: 2250,
      word: "jeghpu'wI'",
      name: "jeghpu'wI' (n.) conquered people -- more than slaves, less than citizens. The status given to natives of worlds conquered by the Klingon Empire"
   }, 
   {
      id: 2251,
      word: "jeghwar",
      name: "jeghwar (n.) jaguar"
   }, 
   {
      id: 2252,
      word: "jej",
      name: "jej (v.) be sharp"
   }, 
   {
      id: 2253,
      word: "jejHa'",
      name: "jejHa' (v.) be blunt (of blades)"
   }, 
   {
      id: 2254,
      word: "jejHa'",
      name: "jejHa' (v.) be dull"
   }, 
   {
      id: 2255,
      word: "jejQIb",
      name: "jejQIb (p.n.) Michiel Uitdehaag"
   }, 
   {
      id: 2256,
      word: "jejSIp",
      name: "jejSIp (n.) acetylene"
   }, 
   {
      id: 2257,
      word: "jel",
      name: "jel (v.) shake, tremble"
   }, 
   {
      id: 2258,
      word: "jelwaS",
      name: "jelwaS (n.) iodine (element)"
   }, 
   {
      id: 2259,
      word: "jem",
      name: "jem (v.) sense, feel, perceive, detect"
   }, 
   {
      id: 2260,
      word: "jem'IH",
      name: "jem'IH (n.) castle"
   }, 
   {
      id: 2261,
      word: "jen",
      name: "jen (v.) be high"
   }, 
   {
      id: 2262,
      word: "jengva'",
      name: "jengva' (n.) plate (for eating)"
   }, 
   {
      id: 2263,
      word: "jentel",
      name: "jentel (n.) tassel"
   }, 
   {
      id: 2264,
      word: "jentu'",
      name: "jentu' (n.) flightless aquatic bird, similar to a penguin"
   }, 
   {
      id: 2265,
      word: "jeq",
      name: "jeq (v.) protrude from"
   }, 
   {
      id: 2266,
      word: "jeqpel",
      name: "jeqpel (n.) push-up"
   }, 
   {
      id: 2267,
      word: "jeqqIj",
      name: "jeqqIj (n.) club, bludgeon"
   }, 
   {
      id: 2268,
      word: "jer",
      name: "jer (v.) surge (aircraft suddenly moves forward or backward)"
   }, 
   {
      id: 2269,
      word: "jergh",
      name: "jergh (v.) spasm"
   }, 
   {
      id: 2270,
      word: "jetlhurgh",
      name: "jetlhurgh (p.n.) J'ethurgh"
   }, 
   {
      id: 2271,
      word: "jetlhurgh tay",
      name: "jetlhurgh tay (n.) Rite of Reclamation (or maybe Recovery), Ritual of J'ethurgh"
   }, 
   {
      id: 2272,
      word: "jev",
      name: "jev (v.) storm"
   }, 
   {
      id: 2273,
      word: "jev",
      name: "jev (v.) wheeze, breathe noisily"
   }, 
   {
      id: 2274,
      word: "jey",
      name: "jey (v.) defeat"
   }, 
   {
      id: 2275,
      word: "jey",
      name: "jey (n.) itinerary"
   }, 
   {
      id: 2276,
      word: "jey'",
      name: "jey' (n.) tin"
   }, 
   {
      id: 2277,
      word: "jey' Sorpuq",
      name: "jey' Sorpuq (n.) bronze"
   }, 
   {
      id: 2278,
      word: "jey'naS",
      name: "jey'naS (n.) double-headed axe, ax with double head"
   }, 
   {
      id: 2279,
      word: "jo",
      name: "jo (n.) resources"
   }, 
   {
      id: 2280,
      word: "jo'",
      name: "jo' (v.) inflate, fill with air, blow up"
   }, 
   {
      id: 2281,
      word: "jo'",
      name: "jo' (n.) machinery"
   }, 
   {
      id: 2282,
      word: "jo'",
      name: "jo' (v.) zoom in on"
   }, 
   {
      id: 2283,
      word: "jo'ley'",
      name: "jo'ley' (n.) tent"
   }, 
   {
      id: 2284,
      word: "joD",
      name: "joD (v.) stoop"
   }, 
   {
      id: 2285,
      word: "joH",
      name: "joH (n.) Lady (female head of house), Lord (male head of house)"
   }, 
   {
      id: 2286,
      word: "joQ",
      name: "joQ (n.) rib"
   }, 
   {
      id: 2287,
      word: "joQ",
      name: "joQ (n.) strip of material in a susdek instrument"
   }, 
   {
      id: 2288,
      word: "joS",
      name: "joS (v.) gossip"
   }, 
   {
      id: 2289,
      word: "joS",
      name: "joS (n.) rumor, gossip"
   }, 
   {
      id: 2290,
      word: "joSraD",
      name: "joSraD (n.) crater"
   }, 
   {
      id: 2291,
      word: "job",
      name: "job (v.) zigzag, be jagged"
   }, 
   {
      id: 2292,
      word: "joch",
      name: "joch (v.) be harmful"
   }, 
   {
      id: 2293,
      word: "jogh",
      name: "jogh (n.) quadrant"
   }, 
   {
      id: 2294,
      word: "joj",
      name: "joj (n.) area between"
   }, 
   {
      id: 2295,
      word: "jojlu'",
      name: "jojlu' (n.) consul"
   }, 
   {
      id: 2296,
      word: "jol",
      name: "jol (v.) beam (aboard)"
   }, 
   {
      id: 2297,
      word: "jol",
      name: "jol (n.) transport beam"
   }, 
   {
      id: 2298,
      word: "jolpa'",
      name: "jolpa' (n.) transport room"
   }, 
   {
      id: 2299,
      word: "jolpat",
      name: "jolpat (n.) transporter system"
   }, 
   {
      id: 2300,
      word: "jolvoy'",
      name: "jolvoy' (n.) transporter ionizer unit"
   }, 
   {
      id: 2301,
      word: "jom",
      name: "jom (v.) install (a device, an object, clothes on another person)"
   }, 
   {
      id: 2302,
      word: "jon",
      name: "jon (v.) capture"
   }, 
   {
      id: 2303,
      word: "jonSeH yaH",
      name: "jonSeH yaH (n.) engineering (location)"
   }, 
   {
      id: 2304,
      word: "jonpIn",
      name: "jonpIn (n.) engineering officer"
   }, 
   {
      id: 2305,
      word: "jonta'",
      name: "jonta' (n.) engine"
   }, 
   {
      id: 2306,
      word: "jonwI'",
      name: "jonwI' (n.) engineer"
   }, 
   {
      id: 2307,
      word: "jop",
      name: "jop (v.) lunge, thrust"
   }, 
   {
      id: 2308,
      word: "jop",
      name: "jop (v.) take a turn"
   }, 
   {
      id: 2309,
      word: "joq",
      name: "joq (conjunction) and/or (joining nouns)"
   }, 
   {
      id: 2310,
      word: "joq",
      name: "joq (v.) flutter, wave"
   }, 
   {
      id: 2311,
      word: "joqwI'",
      name: "joqwI' (n.) flag"
   }, 
   {
      id: 2312,
      word: "joqwI' nagh",
      name: "joqwI' nagh (n.) chip, potato chip, corn chip, crisp (UK)"
   }, 
   {
      id: 2313,
      word: "jor",
      name: "jor (v.) explode"
   }, 
   {
      id: 2314,
      word: "jorchan",
      name: "jorchan (n.) view, scene, scenery, sight, landscape"
   }, 
   {
      id: 2315,
      word: "jorchan velqa'",
      name: "jorchan velqa' (n.) scenery, stage decoration"
   }, 
   {
      id: 2316,
      word: "jorja",
      name: "jorja (n.) Georgia (US state)"
   }, 
   {
      id: 2317,
      word: "jorneb",
      name: "jorneb (n.) warhead (of a torpedo)"
   }, 
   {
      id: 2318,
      word: "jorngab",
      name: "jorngab (n.) shoulder piece of a Klingon uniform"
   }, 
   {
      id: 2319,
      word: "jornub",
      name: "jornub (n.) warhead (of a torpedo)"
   }, 
   {
      id: 2320,
      word: "jorwI'",
      name: "jorwI' (n.) explosive"
   }, 
   {
      id: 2321,
      word: "jot",
      name: "jot (v.) be calm"
   }, 
   {
      id: 2322,
      word: "jotHa'",
      name: "jotHa' (v.) be uneasy"
   }, 
   {
      id: 2323,
      word: "jotlh",
      name: "jotlh (v.) take down"
   }, 
   {
      id: 2324,
      word: "joy'",
      name: "joy' (v.) torture"
   }, 
   {
      id: 2325,
      word: "ju",
      name: "ju (vp) you-us"
   }, 
   {
      id: 2326,
      word: "ju'Da lalDan",
      name: "ju'Da lalDan (n.) Judaism"
   }, 
   {
      id: 2327,
      word: "ju'pIter",
      name: "ju'pIter (p.n.) Jupiter (planet)"
   }, 
   {
      id: 2328,
      word: "juH",
      name: "juH (n.) home"
   }, 
   {
      id: 2329,
      word: "juHqo'",
      name: "juHqo' (n.) home world"
   }, 
   {
      id: 2330,
      word: "juS",
      name: "juS (v.) overtake, pass"
   }, 
   {
      id: 2331,
      word: "jub",
      name: "jub (v.) be immortal"
   }, 
   {
      id: 2332,
      word: "jubbe'",
      name: "jubbe' (v.) be mortal"
   }, 
   {
      id: 2333,
      word: "juch",
      name: "juch (v.) have a width of"
   }, 
   {
      id: 2334,
      word: "jul",
      name: "jul (n.) sun"
   }, 
   {
      id: 2335,
      word: "julSIp",
      name: "julSIp (n.) helium (element)"
   }, 
   {
      id: 2336,
      word: "jum",
      name: "jum (v.) be odd, peculiar, unexpected, fishy"
   }, 
   {
      id: 2337,
      word: "jun",
      name: "jun (v.) evade, take evasive action"
   }, 
   {
      id: 2338,
      word: "jungwoq",
      name: "jungwoq (n.) China"
   }, 
   {
      id: 2339,
      word: "jup",
      name: "jup (n.) friend"
   }, 
   {
      id: 2340,
      word: "jutngev",
      name: "jutngev (n.) nectar"
   }, 
   {
      id: 2341,
      word: "juv",
      name: "juv (v.) measure"
   }, 
   {
      id: 2342,
      word: "jva",
      name: "jva (n.) a stuck person (slang), ditherer (slang), confused prisoner (slang), mixed-up prisoner (slang)"
   }, 
   {
      id: 2343,
      word: "lI",
      name: "lI (vp) he/she/it/they-you (pl)"
   }, 
   {
      id: 2344,
      word: "lI'",
      name: "lI' (v.) be useful"
   }, 
   {
      id: 2345,
      word: "lI'",
      name: "lI' (vs7) in progress (aspect marker)"
   }, 
   {
      id: 2346,
      word: "lI'",
      name: "lI' (v.) transmit data (to a place)"
   }, 
   {
      id: 2347,
      word: "lI'",
      name: "lI' (ns4) your (noun capable of using language)"
   }, 
   {
      id: 2348,
      word: "lI'HemvI'",
      name: "lI'HemvI' (n.) dopamine"
   }, 
   {
      id: 2349,
      word: "lI'choD",
      name: "lI'choD (n.) plasma (state of matter)"
   }, 
   {
      id: 2350,
      word: "lI'lIy",
      name: "lI'lIy (n.) lily"
   }, 
   {
      id: 2351,
      word: "lID",
      name: "lID (v.) travel or move a specified or measurable distance or trajectory"
   }, 
   {
      id: 2352,
      word: "lIH",
      name: "lIH (v.) begin a song, start a song"
   }, 
   {
      id: 2353,
      word: "lIH",
      name: "lIH (v.) introduce"
   }, 
   {
      id: 2354,
      word: "lIHtentay'",
      name: "lIHtentay' (n.) Lichtenstein"
   }, 
   {
      id: 2355,
      word: "lIQ",
      name: "lIQ (v.) be stuck (with a puzzle), be stumped"
   }, 
   {
      id: 2356,
      word: "lIS",
      name: "lIS (v.) adjust"
   }, 
   {
      id: 2357,
      word: "lIS'ab",
      name: "lIS'ab (n.) rodent"
   }, 
   {
      id: 2358,
      word: "lIb",
      name: "lIb (v.) be impending, be imminent, be loom"
   }, 
   {
      id: 2359,
      word: "lIbnen",
      name: "lIbnen (n.) Lebanon"
   }, 
   {
      id: 2360,
      word: "lIbya'",
      name: "lIbya' (n.) Libya"
   }, 
   {
      id: 2361,
      word: "lIch",
      name: "lIch (v.) pour (into/onto anything)"
   }, 
   {
      id: 2362,
      word: "lIgh",
      name: "lIgh (v.) ride"
   }, 
   {
      id: 2363,
      word: "lIghon",
      name: "lIghon (n.) Ligon"
   }, 
   {
      id: 2364,
      word: "lIghon DuQwI' pogh",
      name: "lIghon DuQwI' pogh (n.) glavin, Ligonian spike glove"
   }, 
   {
      id: 2365,
      word: "lIj",
      name: "lIj (v.) forget"
   }, 
   {
      id: 2366,
      word: "lIj",
      name: "lIj (ns4) your"
   }, 
   {
      id: 2367,
      word: "lIl",
      name: "lIl (v.) simulate, impersonate"
   }, 
   {
      id: 2368,
      word: "lIlwI'",
      name: "lIlwI' (n.) simulator"
   }, 
   {
      id: 2369,
      word: "lIm",
      name: "lIm (v.) panic"
   }, 
   {
      id: 2370,
      word: "lIn",
      name: "lIn (v.) share"
   }, 
   {
      id: 2371,
      word: "lInDab",
      name: "lInDab (n.) espionage"
   }, 
   {
      id: 2372,
      word: "lInchuq",
      name: "lInchuq (phrase) share each other"
   }, 
   {
      id: 2373,
      word: "lIng",
      name: "lIng (v.) produce"
   }, 
   {
      id: 2374,
      word: "lIngta'",
      name: "lIngta' (n.) lingta, type of animal"
   }, 
   {
      id: 2375,
      word: "lIngwI'",
      name: "lIngwI' (n.) generator"
   }, 
   {
      id: 2376,
      word: "lIngwa'Ighno'ta Hol",
      name: "lIngwa'Ighno'ta Hol (n.) Lingua Ignota"
   }, 
   {
      id: 2377,
      word: "lIngwaDepIlane'ta Hol",
      name: "lIngwaDepIlane'ta Hol (n.) Lingwa de Planeta"
   }, 
   {
      id: 2378,
      word: "lIngwavIrangqano'va Hol",
      name: "lIngwavIrangqano'va Hol (n.) Lingua Franca Nova"
   }, 
   {
      id: 2379,
      word: "lIq",
      name: "lIq (v.) round up"
   }, 
   {
      id: 2380,
      word: "lIr",
      name: "lIr (n.) a nocturnal bird"
   }, 
   {
      id: 2381,
      word: "lIr'el",
      name: "lIr'el (p.n.) L'Rell"
   }, 
   {
      id: 2382,
      word: "lIt",
      name: "lIt (v.) get on (to)"
   }, 
   {
      id: 2383,
      word: "lItHa'",
      name: "lItHa' (v.) get off (of)"
   }, 
   {
      id: 2384,
      word: "lIvqa'nan",
      name: "lIvqa'nan (n.) doorframe"
   }, 
   {
      id: 2385,
      word: "lIvrI'",
      name: "lIvrI' (n.) granite"
   }, 
   {
      id: 2386,
      word: "lIw",
      name: "lIw (n.) temporary substitute, stand-in, temporary surrogate"
   }, 
   {
      id: 2387,
      word: "lIw mu'",
      name: "lIw mu' (n.) pronoun"
   }, 
   {
      id: 2388,
      word: "lIwnal",
      name: "lIwnal (n.) concubine"
   }, 
   {
      id: 2389,
      word: "lIy",
      name: "lIy (n.) comet"
   }, 
   {
      id: 2390,
      word: "lIyenIn",
      name: "lIyenIn (p.n.) Lenin"
   }, 
   {
      id: 2391,
      word: "lIyetu'va'",
      name: "lIyetu'va' (n.) Lithuania"
   }, 
   {
      id: 2392,
      word: "la'",
      name: "la' (n.) commander"
   }, 
   {
      id: 2393,
      word: "la''a'",
      name: "la''a' (n.) commandant"
   }, 
   {
      id: 2394,
      word: "la'Dan Hol",
      name: "la'Dan Hol (n.) Láadan"
   }, 
   {
      id: 2395,
      word: "la'SIv",
      name: "la'SIv (n.) turtle, tortoise"
   }, 
   {
      id: 2396,
      word: "la'avghe",
      name: "la'avghe (n.) Le Havre"
   }, 
   {
      id: 2397,
      word: "la'qab",
      name: "la'qab (n.) whistle sound produced by one's mouth and lips"
   }, 
   {
      id: 2398,
      word: "la'quv",
      name: "la'quv (n.) Supreme Commander"
   }, 
   {
      id: 2399,
      word: "la'rut'an",
      name: "la'rut'an (n.) mica"
   }, 
   {
      id: 2400,
      word: "la'yIgh",
      name: "la'yIgh (n.) spice"
   }, 
   {
      id: 2401,
      word: "laD",
      name: "laD (v.) read"
   }, 
   {
      id: 2402,
      word: "laH",
      name: "laH (n.) ability"
   }, 
   {
      id: 2403,
      word: "laH",
      name: "laH (vs5) can, able"
   }, 
   {
      id: 2404,
      word: "laQ",
      name: "laQ (v.) fire, energize (e.g. thrusters)"
   }, 
   {
      id: 2405,
      word: "laS",
      name: "laS (v.) ink up, put paint on a brush"
   }, 
   {
      id: 2406,
      word: "laS veghaS",
      name: "laS veghaS (n.) Las Vegas"
   }, 
   {
      id: 2407,
      word: "laSvargh",
      name: "laSvargh (n.) factory"
   }, 
   {
      id: 2408,
      word: "lab",
      name: "lab (v.) transmit data (away from a place)"
   }, 
   {
      id: 2409,
      word: "lach",
      name: "lach (v.) exaggerate"
   }, 
   {
      id: 2410,
      word: "lachvoH",
      name: "lachvoH (n.) bee hive"
   }, 
   {
      id: 2411,
      word: "lagh",
      name: "lagh (n.) ensign"
   }, 
   {
      id: 2412,
      word: "lagh",
      name: "lagh (v.) take apart, disassemble"
   }, 
   {
      id: 2413,
      word: "laj",
      name: "laj (v.) accept"
   }, 
   {
      id: 2414,
      word: "laj",
      name: "laj (n.) acceptance"
   }, 
   {
      id: 2415,
      word: "lajQo'",
      name: "lajQo' (v.) reject"
   }, 
   {
      id: 2416,
      word: "lalDan",
      name: "lalDan (n.) religion"
   }, 
   {
      id: 2417,
      word: "lam",
      name: "lam (v.) be dirty"
   }, 
   {
      id: 2418,
      word: "lam",
      name: "lam (n.) dirt"
   }, 
   {
      id: 2419,
      word: "lam Ho'Du'",
      name: "lam Ho'Du' (n.) rake that loosens and/or smooth the ground"
   }, 
   {
      id: 2420,
      word: "lan",
      name: "lan (v.) place"
   }, 
   {
      id: 2421,
      word: "lanDan",
      name: "lanDan (n.) London"
   }, 
   {
      id: 2422,
      word: "lanSoy",
      name: "lanSoy (n.) queue, line, row (of people or things expected to be in motion)"
   }, 
   {
      id: 2423,
      word: "lang",
      name: "lang (v.) be thin, narrow"
   }, 
   {
      id: 2424,
      word: "lap",
      name: "lap (v.) vote, cast a ballot"
   }, 
   {
      id: 2425,
      word: "laq",
      name: "laq (v.) flap"
   }, 
   {
      id: 2426,
      word: "laq",
      name: "laq (v.) speak gibberish"
   }, 
   {
      id: 2427,
      word: "laqlaq",
      name: "laqlaq (n.) gibberish"
   }, 
   {
      id: 2428,
      word: "largh",
      name: "largh (v.) smell, sense odors"
   }, 
   {
      id: 2429,
      word: "larveS",
      name: "larveS (n.) pus"
   }, 
   {
      id: 2430,
      word: "lat",
      name: "lat (n.) shrine, monument, memorial (building)"
   }, 
   {
      id: 2431,
      word: "latIyna Hol",
      name: "latIyna Hol (n.) Latin"
   }, 
   {
      id: 2432,
      word: "latlh",
      name: "latlh (n.) additional one, other one"
   }, 
   {
      id: 2433,
      word: "latlh je",
      name: "latlh je (n.) et cetera"
   }, 
   {
      id: 2434,
      word: "latlh je",
      name: "latlh je (Phrase) Et cetera, etc"
   }, 
   {
      id: 2435,
      word: "latvIya",
      name: "latvIya (n.) Latvia"
   }, 
   {
      id: 2436,
      word: "lav",
      name: "lav (v.) lean, incline, slant"
   }, 
   {
      id: 2437,
      word: "lav",
      name: "lav (n.) shrub"
   }, 
   {
      id: 2438,
      word: "law",
      name: "law (n.) degrees (traditional)"
   }, 
   {
      id: 2439,
      word: "law'",
      name: "law' (v.) be many, be numerous"
   }, 
   {
      id: 2440,
      word: "law'",
      name: "law' (vs6) seems, apparently"
   }, 
   {
      id: 2441,
      word: "lawrI'",
      name: "lawrI' (n.) degrees (modern)"
   }, 
   {
      id: 2442,
      word: "lay",
      name: "lay (n.) air (technical term)"
   }, 
   {
      id: 2443,
      word: "lay leng",
      name: "lay leng (n.) aeronautics"
   }, 
   {
      id: 2444,
      word: "lay'",
      name: "lay' (v.) promise"
   }, 
   {
      id: 2445,
      word: "lay'Ha'",
      name: "lay'Ha' (v.) break one's word"
   }, 
   {
      id: 2446,
      word: "laybIrya'",
      name: "laybIrya' (n.) Liberia"
   }, 
   {
      id: 2447,
      word: "layerteS",
      name: "layerteS (p.n.) Laertes"
   }, 
   {
      id: 2448,
      word: "layyan",
      name: "layyan (n.) lion"
   }, 
   {
      id: 2449,
      word: "le'",
      name: "le' (v.) be special, be exceptional"
   }, 
   {
      id: 2450,
      word: "le''aq",
      name: "le''aq (n.) messenger"
   }, 
   {
      id: 2451,
      word: "le'be'",
      name: "le'be' (v.) be unexceptional, be nonspecific"
   }, 
   {
      id: 2452,
      word: "le'mIS",
      name: "le'mIS (n.) blockade"
   }, 
   {
      id: 2453,
      word: "le'yo'",
      name: "le'yo' (n.) pride"
   }, 
   {
      id: 2454,
      word: "leD",
      name: "leD (v.) be perpendicular, be at a right angle"
   }, 
   {
      id: 2455,
      word: "leH",
      name: "leH (v.) maintain"
   }, 
   {
      id: 2456,
      word: "leH",
      name: "leH (n.) maintenance"
   }, 
   {
      id: 2457,
      word: "leQ",
      name: "leQ (n.) switch, button"
   }, 
   {
      id: 2458,
      word: "leS",
      name: "leS (n.) days from now"
   }, 
   {
      id: 2459,
      word: "leS",
      name: "leS (v.) rest, relax"
   }, 
   {
      id: 2460,
      word: "leSSov",
      name: "leSSov (n.) foresight"
   }, 
   {
      id: 2461,
      word: "leSpal",
      name: "leSpal (n.) type of stringed instrument, guitar"
   }, 
   {
      id: 2462,
      word: "leSpoH",
      name: "leSpoH (n.) shore leave"
   }, 
   {
      id: 2463,
      word: "leSu'tu",
      name: "leSu'tu (n.) Lesotho"
   }, 
   {
      id: 2464,
      word: "lech",
      name: "lech (v.) blackmail"
   }, 
   {
      id: 2465,
      word: "legh",
      name: "legh (v.) see"
   }, 
   {
      id: 2466,
      word: "leghlaHbe'",
      name: "leghlaHbe' (v.) blind, is not able to see"
   }, 
   {
      id: 2467,
      word: "lel",
      name: "lel (v.) get out, take out"
   }, 
   {
      id: 2468,
      word: "lem",
      name: "lem (n.) hoof"
   }, 
   {
      id: 2469,
      word: "len",
      name: "len (n.) recess, break"
   }, 
   {
      id: 2470,
      word: "leng",
      name: "leng (v.) roam (to a place), travel (to a place), rove (to a place)"
   }, 
   {
      id: 2471,
      word: "leng",
      name: "leng (n.) trip, voyage"
   }, 
   {
      id: 2472,
      word: "lengwI'",
      name: "lengwI' (n.) rover (grammatical term)"
   }, 
   {
      id: 2473,
      word: "lenmeS rop",
      name: "lenmeS rop (n.) Lenmes disease"
   }, 
   {
      id: 2474,
      word: "lep",
      name: "lep (n.) solid (state of matter)"
   }, 
   {
      id: 2475,
      word: "ler",
      name: "ler (v.) wobble, oscillate"
   }, 
   {
      id: 2476,
      word: "lerup",
      name: "lerup (n.) bacterium, bacteria"
   }, 
   {
      id: 2477,
      word: "lervaD",
      name: "lervaD (n.) auction"
   }, 
   {
      id: 2478,
      word: "let",
      name: "let (v.) be hard (like a rock)"
   }, 
   {
      id: 2479,
      word: "letSeburgh",
      name: "letSeburgh (n.) Luxembourg"
   }, 
   {
      id: 2480,
      word: "letbIng",
      name: "letbIng (n.) mercury"
   }, 
   {
      id: 2481,
      word: "letbaQ",
      name: "letbaQ (n.) rectangle"
   }, 
   {
      id: 2482,
      word: "letlh",
      name: "letlh (n.) stairs, stairway, stairway leading to door of a ship (regional)"
   }, 
   {
      id: 2483,
      word: "lev",
      name: "lev (n.) hard palate, roof of mouth"
   }, 
   {
      id: 2484,
      word: "lev",
      name: "lev (v.) move bat'leth from vertical to horizontal orientation"
   }, 
   {
      id: 2485,
      word: "levwIt",
      name: "levwIt (n.) almond"
   }, 
   {
      id: 2486,
      word: "lew",
      name: "lew (v.) bloom"
   }, 
   {
      id: 2487,
      word: "ley'",
      name: "ley' (n.) nose (regional)"
   }, 
   {
      id: 2488,
      word: "lo'",
      name: "lo' (n.) use"
   }, 
   {
      id: 2489,
      word: "lo'",
      name: "lo' (v.) use"
   }, 
   {
      id: 2490,
      word: "lo' law'",
      name: "lo' law' (n.) utility (precedes noun it modifies)"
   }, 
   {
      id: 2491,
      word: "lo'laH",
      name: "lo'laH (v.) be valuable"
   }, 
   {
      id: 2492,
      word: "lo'laHbe'",
      name: "lo'laHbe' (v.) be worthless"
   }, 
   {
      id: 2493,
      word: "lo'laHbe'ghach",
      name: "lo'laHbe'ghach (n.) worthlessness"
   }, 
   {
      id: 2494,
      word: "lo'laHghach",
      name: "lo'laHghach (n.) value"
   }, 
   {
      id: 2495,
      word: "loD",
      name: "loD (n.) male, man"
   }, 
   {
      id: 2496,
      word: "loDHom",
      name: "loDHom (n.) boy"
   }, 
   {
      id: 2497,
      word: "loDnI'",
      name: "loDnI' (n.) brother"
   }, 
   {
      id: 2498,
      word: "loDnal",
      name: "loDnal (n.) husband"
   }, 
   {
      id: 2499,
      word: "loH",
      name: "loH (v.) administer"
   }, 
   {
      id: 2500,
      word: "loH",
      name: "loH (n.) administration"
   }, 
   {
      id: 2501,
      word: "loQ",
      name: "loQ (adverb) slightly, little bit"
   }, 
   {
      id: 2502,
      word: "loQHa'",
      name: "loQHa' (adverb) considerably, appreciably"
   }, 
   {
      id: 2503,
      word: "loS",
      name: "loS (number) four, 4"
   }, 
   {
      id: 2504,
      word: "loS",
      name: "loS (n.) fourth tone of nonatonic musical scale"
   }, 
   {
      id: 2505,
      word: "loS",
      name: "loS (v.) wait (for)"
   }, 
   {
      id: 2506,
      word: "loS reD 'Impey'",
      name: "loS reD 'Impey' (n.) pyramid with four-sided base"
   }, 
   {
      id: 2507,
      word: "loS reD mey'",
      name: "loS reD mey' (n.) quadrilateral (lit: four wall polygon)"
   }, 
   {
      id: 2508,
      word: "loScha'",
      name: "loScha' (n.) coincidence"
   }, 
   {
      id: 2509,
      word: "loSpev",
      name: "loSpev (n.) quadrotriticale"
   }, 
   {
      id: 2510,
      word: "lob",
      name: "lob (v.) obey"
   }, 
   {
      id: 2511,
      word: "lobHa'",
      name: "lobHa' (v.) disobey"
   }, 
   {
      id: 2512,
      word: "loch",
      name: "loch (v.) be a fraction of, make up a portion of, constitute part of"
   }, 
   {
      id: 2513,
      word: "loch",
      name: "loch (n.) mustache"
   }, 
   {
      id: 2514,
      word: "logh",
      name: "logh (number) repetition suffix (e.g. twice)"
   }, 
   {
      id: 2515,
      word: "logh",
      name: "logh (n.) space"
   }, 
   {
      id: 2516,
      word: "logh mIn",
      name: "logh mIn (n.) wormhole"
   }, 
   {
      id: 2517,
      word: "logh'ob",
      name: "logh'ob (n.) chest, front of something, hood/bonnet of vehicle"
   }, 
   {
      id: 2518,
      word: "loghjaj",
      name: "loghjaj (n.) Thursday"
   }, 
   {
      id: 2519,
      word: "loghqam",
      name: "loghqam (n.) unit of measure, 1.25 light years"
   }, 
   {
      id: 2520,
      word: "loj",
      name: "loj (v.) be all gone"
   }, 
   {
      id: 2521,
      word: "lojban Hol",
      name: "lojban Hol (n.) Lojban"
   }, 
   {
      id: 2522,
      word: "lojmIt",
      name: "lojmIt (n.) door, gate"
   }, 
   {
      id: 2523,
      word: "lojmItjaj",
      name: "lojmItjaj (n.) Saturday (Formal)"
   }, 
   {
      id: 2524,
      word: "lol",
      name: "lol (n.) a specific position in the martial arts form Mok'bara"
   }, 
   {
      id: 2525,
      word: "lol",
      name: "lol (v.) be in an attitude (aircraft); be in a stance, be in a pose (people animals or martial arts)"
   }, 
   {
      id: 2526,
      word: "lolSeHcha",
      name: "lolSeHcha (n.) attitude-control thruster"
   }, 
   {
      id: 2527,
      word: "lolchu'",
      name: "lolchu' (v.) be in a correct attitude (aircraft)"
   }, 
   {
      id: 2528,
      word: "lolchu'taH",
      name: "lolchu'taH (v.) maintain a correct altitude (aircraft)"
   }, 
   {
      id: 2529,
      word: "lolmoH",
      name: "lolmoH (v.) maneuver (an aircraft) to be in an attitude"
   }, 
   {
      id: 2530,
      word: "loltaH",
      name: "loltaH (v.) maintain an attitude (aircraft)"
   }, 
   {
      id: 2531,
      word: "lom",
      name: "lom (n.) corpse"
   }, 
   {
      id: 2532,
      word: "lon",
      name: "lon (v.) abandon"
   }, 
   {
      id: 2533,
      word: "lop",
      name: "lop (v.) celebrate"
   }, 
   {
      id: 2534,
      word: "lop",
      name: "lop (n.) celebration"
   }, 
   {
      id: 2535,
      word: "lop",
      name: "lop (v.) observe, celebrate (a ritual)"
   }, 
   {
      id: 2536,
      word: "lopno'",
      name: "lopno' (n.) party - probably an event or persons celebrating the event"
   }, 
   {
      id: 2537,
      word: "lopno'",
      name: "lopno' (n.) party, celebration"
   }, 
   {
      id: 2538,
      word: "lor",
      name: "lor (n.) cousin (mother's brother's child or father's sister's child), niece or nephew (man's sister's child"
   }, 
   {
      id: 2539,
      word: "lorbe'",
      name: "lorbe' (n.) female cousin (mother's brother's daughter or father's sister's daughter), niece (man's sister's dau"
   }, 
   {
      id: 2540,
      word: "lorloD",
      name: "lorloD (n.) male cousin (mother's brother's son or father's sister's son), nephew (man's sister's son or woman's"
   }, 
   {
      id: 2541,
      word: "lot",
      name: "lot (n.) catastrophe"
   }, 
   {
      id: 2542,
      word: "lot",
      name: "lot (v.) scratch"
   }, 
   {
      id: 2543,
      word: "lotlh",
      name: "lotlh (v.) rebel"
   }, 
   {
      id: 2544,
      word: "lotlhmoq",
      name: "lotlhmoq (n.) a bird that swoops into the water in order to catch food, but cannot swim"
   }, 
   {
      id: 2545,
      word: "lotlhwI'",
      name: "lotlhwI' (n.) rebel"
   }, 
   {
      id: 2546,
      word: "lotregh",
      name: "lotregh (n.) anaemia"
   }, 
   {
      id: 2547,
      word: "loy",
      name: "loy (v.) guess"
   }, 
   {
      id: 2548,
      word: "loy'",
      name: "loy' (v.) have personality, be charismatic, be charming"
   }, 
   {
      id: 2549,
      word: "lu",
      name: "lu (v.) fall (suffer loss of status)"
   }, 
   {
      id: 2550,
      word: "lu",
      name: "lu (vp) they-him/her/it"
   }, 
   {
      id: 2551,
      word: "lu'",
      name: "lu' (vs5) indefinite subject"
   }, 
   {
      id: 2552,
      word: "lu'",
      name: "lu' (exclamation) yes, okay"
   }, 
   {
      id: 2553,
      word: "lu'lap",
      name: "lu'lap (n.) beep noise"
   }, 
   {
      id: 2554,
      word: "luDnama'",
      name: "luDnama' (n.) fractal"
   }, 
   {
      id: 2555,
      word: "luH",
      name: "luH (vs5) -lu' and -laH combined (marked, slang)"
   }, 
   {
      id: 2556,
      word: "luH",
      name: "luH (v.) cause (someone) to confess or reveal a secret, exact a confession (slang)"
   }, 
   {
      id: 2557,
      word: "luH",
      name: "luH (n.) intestine"
   }, 
   {
      id: 2558,
      word: "luH",
      name: "luH (v.) yank"
   }, 
   {
      id: 2559,
      word: "luHwI' tIH",
      name: "luHwI' tIH (n.) tractor beam"
   }, 
   {
      id: 2560,
      word: "luS",
      name: "luS (v.) be submerged in, immersed in, surrounded by"
   }, 
   {
      id: 2561,
      word: "luSpet",
      name: "luSpet (n.) black hole (astronomical phenomenon)"
   }, 
   {
      id: 2562,
      word: "luch",
      name: "luch (n.) equipment, gear"
   }, 
   {
      id: 2563,
      word: "lugh",
      name: "lugh (v.) be right, be correct"
   }, 
   {
      id: 2564,
      word: "luj",
      name: "luj (v.) fail, lose (a contest)"
   }, 
   {
      id: 2565,
      word: "luj",
      name: "luj (v.) lose (not win)"
   }, 
   {
      id: 2566,
      word: "lujwI' mIr",
      name: "lujwI' mIr (n.) losing streak"
   }, 
   {
      id: 2567,
      word: "lul",
      name: "lul (v.) fight, battle (relatively major fight)"
   }, 
   {
      id: 2568,
      word: "lulIgh",
      name: "lulIgh (n.) refuge"
   }, 
   {
      id: 2569,
      word: "lum",
      name: "lum (v.) postpone, procrastinate"
   }, 
   {
      id: 2570,
      word: "lun",
      name: "lun (v.) swell, swell up"
   }, 
   {
      id: 2571,
      word: "lung",
      name: "lung (n.) lizard-like, salamander-like creature, loong"
   }, 
   {
      id: 2572,
      word: "lunglIH",
      name: "lunglIH (n.) turbine, propeller"
   }, 
   {
      id: 2573,
      word: "lunglIH Duj",
      name: "lunglIH Duj (n.) helicopter"
   }, 
   {
      id: 2574,
      word: "lungrI'",
      name: "lungrI' (n.) longitude"
   }, 
   {
      id: 2575,
      word: "lungrI'tal ",
      name: "lungrI'tal  (n.) meridian"
   }, 
   {
      id: 2576,
      word: "lup",
      name: "lup (n.) second (of time)"
   }, 
   {
      id: 2577,
      word: "lup",
      name: "lup (v.) transport"
   }, 
   {
      id: 2578,
      word: "lupDujHom",
      name: "lupDujHom (n.) shuttlecraft"
   }, 
   {
      id: 2579,
      word: "lupwI'",
      name: "lupwI' (n.) jitney, bus, train, transport vehicle"
   }, 
   {
      id: 2580,
      word: "luq",
      name: "luq (exclamation) yes, okay, I will"
   }, 
   {
      id: 2581,
      word: "luqara'",
      name: "luqara' (p.n.) Lukara"
   }, 
   {
      id: 2582,
      word: "luqlev",
      name: "luqlev (n.) curfew"
   }, 
   {
      id: 2583,
      word: "lur",
      name: "lur (n.) pupil (of eye)"
   }, 
   {
      id: 2584,
      word: "lurDech",
      name: "lurDech (n.) tradition"
   }, 
   {
      id: 2585,
      word: "lurSa",
      name: "lurSa (p.n.) Lursa"
   }, 
   {
      id: 2586,
      word: "lurSa'",
      name: "lurSa' (p.n.) Lursa"
   }, 
   {
      id: 2587,
      word: "lurgh",
      name: "lurgh (n.) direction (spatial)"
   }, 
   {
      id: 2588,
      word: "lut",
      name: "lut (n.) story"
   }, 
   {
      id: 2589,
      word: "lut mIr",
      name: "lut mIr (n.) series (literature, television)"
   }, 
   {
      id: 2590,
      word: "lut tlhaQ",
      name: "lut tlhaQ (n.) funny story"
   }, 
   {
      id: 2591,
      word: "lutlh",
      name: "lutlh (v.) be primitive"
   }, 
   {
      id: 2592,
      word: "luvnup",
      name: "luvnup (n.) daydream"
   }, 
   {
      id: 2593,
      word: "mI'",
      name: "mI' (v.) dance, run in place, do calisthenics, exercise"
   }, 
   {
      id: 2594,
      word: "mI'",
      name: "mI' (n.) number"
   }, 
   {
      id: 2595,
      word: "mI' mIr",
      name: "mI' mIr (n.) sequence of numbers"
   }, 
   {
      id: 2596,
      word: "mI' mergh",
      name: "mI' mergh (n.) complex number"
   }, 
   {
      id: 2597,
      word: "mI' mob",
      name: "mI' mob (n.) odd number"
   }, 
   {
      id: 2598,
      word: "mI' mobHa'",
      name: "mI' mobHa' (n.) even number"
   }, 
   {
      id: 2599,
      word: "mI' nagh",
      name: "mI' nagh (n.) playing dice, die"
   }, 
   {
      id: 2600,
      word: "mI' rorgh",
      name: "mI' rorgh (n.) imaginary number"
   }, 
   {
      id: 2601,
      word: "mI' tej",
      name: "mI' tej (n.) mathematician"
   }, 
   {
      id: 2602,
      word: "mI'rab",
      name: "mI'rab (n.) spiral"
   }, 
   {
      id: 2603,
      word: "mI'wI' much",
      name: "mI'wI' much (n.) dance show"
   }, 
   {
      id: 2604,
      word: "mID",
      name: "mID (n.) colony"
   }, 
   {
      id: 2605,
      word: "mIHneS",
      name: "mIHneS (n.) Grasshopper"
   }, 
   {
      id: 2606,
      word: "mIQ",
      name: "mIQ (n.) forehead (regional)"
   }, 
   {
      id: 2607,
      word: "mIQ",
      name: "mIQ (v.) fry, deep-fry"
   }, 
   {
      id: 2608,
      word: "mIS",
      name: "mIS (v.) be confused, be mixed up"
   }, 
   {
      id: 2609,
      word: "mIS",
      name: "mIS (n.) confusion"
   }, 
   {
      id: 2610,
      word: "mISjennegh",
      name: "mISjennegh (n.) marble (material)"
   }, 
   {
      id: 2611,
      word: "mISmoH",
      name: "mISmoH (v.) confuse"
   }, 
   {
      id: 2612,
      word: "mIStaq",
      name: "mIStaq (p.n.) sculptor who made Blood Oath Circles"
   }, 
   {
      id: 2613,
      word: "mIch",
      name: "mIch (n.) sector, zone"
   }, 
   {
      id: 2614,
      word: "mIgh",
      name: "mIgh (v.) be evil"
   }, 
   {
      id: 2615,
      word: "mIjDang",
      name: "mIjDang (n.) fin, flipper"
   }, 
   {
      id: 2616,
      word: "mIl",
      name: "mIl (v.) be formerly honored"
   }, 
   {
      id: 2617,
      word: "mIl'oD",
      name: "mIl'oD (n.) milod, sabre bear, type of animal"
   }, 
   {
      id: 2618,
      word: "mIllogh",
      name: "mIllogh (n.) picture, image, graphic, photograph, icon, drawing, cartoon"
   }, 
   {
      id: 2619,
      word: "mIllogh mIr",
      name: "mIllogh mIr (n.) comic strip"
   }, 
   {
      id: 2620,
      word: "mIllogh meyrI'",
      name: "mIllogh meyrI' (n.) single-panel cartoon"
   }, 
   {
      id: 2621,
      word: "mIllogh ngutlh",
      name: "mIllogh ngutlh (n.) hieroglyph"
   }, 
   {
      id: 2622,
      word: "mIllogh qol",
      name: "mIllogh qol (n.) animation, cartoon"
   }, 
   {
      id: 2623,
      word: "mIllogh qonwI'",
      name: "mIllogh qonwI' (n.) camera"
   }, 
   {
      id: 2624,
      word: "mIm",
      name: "mIm (v.) delay"
   }, 
   {
      id: 2625,
      word: "mIn",
      name: "mIn (n.) eye"
   }, 
   {
      id: 2626,
      word: "mIn tojwI'",
      name: "mIn tojwI' (n.) optical illusion"
   }, 
   {
      id: 2627,
      word: "mIn yuq",
      name: "mIn yuq (v.) perform stage magic"
   }, 
   {
      id: 2628,
      word: "mIn yuqwI'",
      name: "mIn yuqwI' (n.) stage magician"
   }, 
   {
      id: 2629,
      word: "mInyoD",
      name: "mInyoD (n.) eyelid"
   }, 
   {
      id: 2630,
      word: "mIp",
      name: "mIp (v.) be rich"
   }, 
   {
      id: 2631,
      word: "mIp",
      name: "mIp (n.) wealth, richness"
   }, 
   {
      id: 2632,
      word: "mIqta'",
      name: "mIqta' (n.) machinery"
   }, 
   {
      id: 2633,
      word: "mIr",
      name: "mIr (n.) chain, streak"
   }, 
   {
      id: 2634,
      word: "mIr",
      name: "mIr (n.) streak"
   }, 
   {
      id: 2635,
      word: "mIrSam",
      name: "mIrSam (Noun) smoking pipe"
   }, 
   {
      id: 2636,
      word: "mIt",
      name: "mIt (v.) be appropriate, be suitable, be proper for the situation,"
   }, 
   {
      id: 2637,
      word: "mItlh",
      name: "mItlh (v.) forge (metal)"
   }, 
   {
      id: 2638,
      word: "mItlhon",
      name: "mItlhon (n.) smaller sail"
   }, 
   {
      id: 2639,
      word: "mIv",
      name: "mIv (n.) helmet"
   }, 
   {
      id: 2640,
      word: "mIv",
      name: "mIv (n.) metal flat-bottomed pot (regional)"
   }, 
   {
      id: 2641,
      word: "mIv bargh",
      name: "mIv bargh (n.) metal flat-bottomed pot (regional)"
   }, 
   {
      id: 2642,
      word: "mIv'a'",
      name: "mIv'a' (n.) crown"
   }, 
   {
      id: 2643,
      word: "mIvwa'",
      name: "mIvwa' (n.) scar (result of a wound, regardless of how the wound occurred), score, tally"
   }, 
   {
      id: 2644,
      word: "mIw",
      name: "mIw (n.) procedure, process"
   }, 
   {
      id: 2645,
      word: "mIw",
      name: "mIw (n.) recipe, formula (procedure, process)"
   }, 
   {
      id: 2646,
      word: "mIw",
      name: "mIw (n.) step, stage (in a process)"
   }, 
   {
      id: 2647,
      word: "mIwba'",
      name: "mIwba' (n.) trial"
   }, 
   {
      id: 2648,
      word: "mIy",
      name: "mIy (v.) brag"
   }, 
   {
      id: 2649,
      word: "mIyama",
      name: "mIyama (n.) Burma/Myanmar"
   }, 
   {
      id: 2650,
      word: "ma",
      name: "ma (vp) we-"
   }, 
   {
      id: 2651,
      word: "ma'",
      name: "ma' (v.) accommodate"
   }, 
   {
      id: 2652,
      word: "ma'",
      name: "ma' (ns4) our (noun capable of using language)"
   }, 
   {
      id: 2653,
      word: "ma'egh",
      name: "ma'egh (n.) premiere"
   }, 
   {
      id: 2654,
      word: "ma'lI'",
      name: "ma'lI' (n.) fiber, fibre"
   }, 
   {
      id: 2655,
      word: "ma'lIy",
      name: "ma'lIy (n.) Mali"
   }, 
   {
      id: 2656,
      word: "ma'rIch",
      name: "ma'rIch (p.n.) March"
   }, 
   {
      id: 2657,
      word: "ma'to'vor",
      name: "ma'to'vor (n.) Mauk-to'Vor"
   }, 
   {
      id: 2658,
      word: "ma'veq",
      name: "ma'veq (n.) ceremonial knife used in the ritual of Mauk To'Vor"
   }, 
   {
      id: 2659,
      word: "maDaghaSqIyar",
      name: "maDaghaSqIyar (n.) Madagascar"
   }, 
   {
      id: 2660,
      word: "maDyar",
      name: "maDyar (n.) Hungary"
   }, 
   {
      id: 2661,
      word: "maH",
      name: "maH (number) ten, 10 (number-forming element)"
   }, 
   {
      id: 2662,
      word: "maH",
      name: "maH (pronoun) we, us"
   }, 
   {
      id: 2663,
      word: "maH'uy'",
      name: "maH'uy' (number) 10 million"
   }, 
   {
      id: 2664,
      word: "maHSaghan",
      name: "maHSaghan (number) 10 billion"
   }, 
   {
      id: 2665,
      word: "maHnaD",
      name: "maHnaD (n.) protein"
   }, 
   {
      id: 2666,
      word: "maHpIn",
      name: "maHpIn (n.) bowl (large)"
   }, 
   {
      id: 2667,
      word: "maQ",
      name: "maQ (n.) sign, signal"
   }, 
   {
      id: 2668,
      word: "maQmIgh",
      name: "maQmIgh (n.) dark omen, sign of evil coming"
   }, 
   {
      id: 2669,
      word: "maQmIgh",
      name: "maQmIgh (n.) omen (dark), sign of evil coming"
   }, 
   {
      id: 2670,
      word: "maS",
      name: "maS (n.) moon"
   }, 
   {
      id: 2671,
      word: "maS",
      name: "maS (v.) prefer"
   }, 
   {
      id: 2672,
      word: "maS So'lu'chu'bogh",
      name: "maS So'lu'chu'bogh (n.) new moon"
   }, 
   {
      id: 2673,
      word: "maS loQ So'lu'bogh",
      name: "maS loQ So'lu'bogh (n.) gibbous moon"
   }, 
   {
      id: 2674,
      word: "maS loQHa' So'lu'bogh",
      name: "maS loQHa' So'lu'bogh (n.) crescent moon"
   }, 
   {
      id: 2675,
      word: "maS'e' So'bogh pagh",
      name: "maS'e' So'bogh pagh (n.) full moon"
   }, 
   {
      id: 2676,
      word: "maSIr",
      name: "maSIr (n.) Egypt"
   }, 
   {
      id: 2677,
      word: "maSmelo'",
      name: "maSmelo' (n.) marshmallow"
   }, 
   {
      id: 2678,
      word: "maSmelo' Su'ghar Sawqe'",
      name: "maSmelo' Su'ghar Sawqe' (n.) marshmallow candy"
   }, 
   {
      id: 2679,
      word: "maSqa'",
      name: "maSqa' (p.n.) Christian Matzke"
   }, 
   {
      id: 2680,
      word: "maSquwa'",
      name: "maSquwa' (n.) Moscow"
   }, 
   {
      id: 2681,
      word: "maSwov",
      name: "maSwov (n.) moonlight"
   }, 
   {
      id: 2682,
      word: "mab",
      name: "mab (n.) treaty, contract, agreement, commitment, account"
   }, 
   {
      id: 2683,
      word: "mabeb",
      name: "mabeb (n.) toad-like or frog-like creature"
   }, 
   {
      id: 2684,
      word: "mabeb Duj",
      name: "mabeb Duj (n.) amphibious vehicle (slang)"
   }, 
   {
      id: 2685,
      word: "mach",
      name: "mach (v.) be small, be little"
   }, 
   {
      id: 2686,
      word: "magh",
      name: "magh (v.) betray"
   }, 
   {
      id: 2687,
      word: "magh",
      name: "magh (v.) betray, indicate (?), reveal (?)"
   }, 
   {
      id: 2688,
      word: "magh",
      name: "magh (n.) Klingon plant that most closely resembles grass"
   }, 
   {
      id: 2689,
      word: "magh gha'naD",
      name: "magh gha'naD (n.) hay"
   }, 
   {
      id: 2690,
      word: "magh yotlh",
      name: "magh yotlh (n.) lawn"
   }, 
   {
      id: 2691,
      word: "maghpub",
      name: "maghpub (n.) novel"
   }, 
   {
      id: 2692,
      word: "maghrIb",
      name: "maghrIb (n.) Morocco"
   }, 
   {
      id: 2693,
      word: "maghwI'",
      name: "maghwI' (n.) traitor"
   }, 
   {
      id: 2694,
      word: "maj",
      name: "maj (exclamation) good (expressing satisfaction)"
   }, 
   {
      id: 2695,
      word: "maj",
      name: "maj (ns4) our"
   }, 
   {
      id: 2696,
      word: "majIQ",
      name: "majIQ (p.n.) Sally Field"
   }, 
   {
      id: 2697,
      word: "majIq",
      name: "majIq (p.n.) Matt Gomes"
   }, 
   {
      id: 2698,
      word: "majQa'",
      name: "majQa' (exclamation) well done, very good"
   }, 
   {
      id: 2699,
      word: "majaj",
      name: "majaj (n.) cabbage, lettuce"
   }, 
   {
      id: 2700,
      word: "majyang",
      name: "majyang (n.) tile"
   }, 
   {
      id: 2701,
      word: "majyang mIllogh",
      name: "majyang mIllogh (n.) mosaic"
   }, 
   {
      id: 2702,
      word: "majyang mutlhwI'",
      name: "majyang mutlhwI' (n.) tiler"
   }, 
   {
      id: 2703,
      word: "mala'wIy",
      name: "mala'wIy (n.) Malawi"
   }, 
   {
      id: 2704,
      word: "maleSya'",
      name: "maleSya' (n.) Malaysia"
   }, 
   {
      id: 2705,
      word: "malja'",
      name: "malja' (n.) business"
   }, 
   {
      id: 2706,
      word: "malja' HIp",
      name: "malja' HIp (n.) suit, business suit"
   }, 
   {
      id: 2707,
      word: "mang",
      name: "mang (n.) soldier"
   }, 
   {
      id: 2708,
      word: "mangHom",
      name: "mangHom (n.) cadet"
   }, 
   {
      id: 2709,
      word: "manggha",
      name: "manggha (n.) station (train)"
   }, 
   {
      id: 2710,
      word: "mangghom",
      name: "mangghom (n.) army"
   }, 
   {
      id: 2711,
      word: "mangtay",
      name: "mangtay (n.) Thailand"
   }, 
   {
      id: 2712,
      word: "manta'",
      name: "manta' (n.) pod"
   }, 
   {
      id: 2713,
      word: "maq",
      name: "maq (v.) proclaim"
   }, 
   {
      id: 2714,
      word: "maqDar",
      name: "maqDar (n.) mak'dar, Klingon insult"
   }, 
   {
      id: 2715,
      word: "maqIy",
      name: "maqIy (n.) Maquis (Resistance)"
   }, 
   {
      id: 2716,
      word: "maqSung",
      name: "maqSung (n.) bee, wasp"
   }, 
   {
      id: 2717,
      word: "maqlegh",
      name: "maqlegh (n.) priest"
   }, 
   {
      id: 2718,
      word: "maqoch",
      name: "maqoch (n.) buddy, pal, close male friend of a male"
   }, 
   {
      id: 2719,
      word: "mar",
      name: "mar (v.) use the big toe"
   }, 
   {
      id: 2720,
      word: "marIS",
      name: "marIS (p.n.) Mars (planet)"
   }, 
   {
      id: 2721,
      word: "marQen",
      name: "marQen (n.) eddy"
   }, 
   {
      id: 2722,
      word: "marSe'luS",
      name: "marSe'luS (p.n.) Marcellus"
   }, 
   {
      id: 2723,
      word: "mara",
      name: "mara (p.n.) Mara, Kang's wife"
   }, 
   {
      id: 2724,
      word: "mara'qIS",
      name: "mara'qIS (n.) Marrakesh"
   }, 
   {
      id: 2725,
      word: "maregh",
      name: "maregh (p.n.) Dave Coulter"
   }, 
   {
      id: 2726,
      word: "marqagh",
      name: "marqagh (p.n.) Markag"
   }, 
   {
      id: 2727,
      word: "marqem",
      name: "marqem (p.n.) Mark A. Mandel"
   }, 
   {
      id: 2728,
      word: "marqoS",
      name: "marqoS (p.n.) Mark J. Reed"
   }, 
   {
      id: 2729,
      word: "martaq",
      name: "martaq (p.n.) Martok"
   }, 
   {
      id: 2730,
      word: "marvargh",
      name: "marvargh (n.) Klingon ballet"
   }, 
   {
      id: 2731,
      word: "marwI'",
      name: "marwI' (n.) big toe, first toe"
   }, 
   {
      id: 2732,
      word: "matHa'",
      name: "matHa' (n.) gunner"
   }, 
   {
      id: 2733,
      word: "matSu'",
      name: "matSu' (n.) commando"
   }, 
   {
      id: 2734,
      word: "matlh",
      name: "matlh (v.) be loyal"
   }, 
   {
      id: 2735,
      word: "matlh",
      name: "matlh (p.n.) Maltz"
   }, 
   {
      id: 2736,
      word: "matlhHa'",
      name: "matlhHa' (v.) be disloyal"
   }, 
   {
      id: 2737,
      word: "mavje'",
      name: "mavje' (n.) liver (regional)"
   }, 
   {
      id: 2738,
      word: "mavjop",
      name: "mavjop (n.) paper clip"
   }, 
   {
      id: 2739,
      word: "maw",
      name: "maw (p.n.) Mao"
   }, 
   {
      id: 2740,
      word: "maw",
      name: "maw (v.) offend"
   }, 
   {
      id: 2741,
      word: "maw'",
      name: "maw' (v.) be crazy"
   }, 
   {
      id: 2742,
      word: "may",
      name: "may (v.) be fair"
   }, 
   {
      id: 2743,
      word: "may'",
      name: "may' (n.) battle"
   }, 
   {
      id: 2744,
      word: "may' Sut",
      name: "may' Sut (n.) body armor (battle clothing)"
   }, 
   {
      id: 2745,
      word: "may' bom",
      name: "may' bom (n.) battle song"
   }, 
   {
      id: 2746,
      word: "may' rImbey",
      name: "may' rImbey (n.) adrenaline, epinephrine"
   }, 
   {
      id: 2747,
      word: "may'Duj",
      name: "may'Duj (n.) battle cruiser"
   }, 
   {
      id: 2748,
      word: "may'luch",
      name: "may'luch (n.) battle gear, panoply, complete set of armor and weapons"
   }, 
   {
      id: 2749,
      word: "may'morgh",
      name: "may'morgh (n.) battle array"
   }, 
   {
      id: 2750,
      word: "may'ron",
      name: "may'ron (n.) accordion, concertina (instrument)"
   }, 
   {
      id: 2751,
      word: "may'ron raS",
      name: "may'ron raS (n.) piano"
   }, 
   {
      id: 2752,
      word: "maySon",
      name: "maySon (n.) superconductivity"
   }, 
   {
      id: 2753,
      word: "mayqar",
      name: "mayqar (n.) braid, knotwork"
   }, 
   {
      id: 2754,
      word: "mayqel",
      name: "mayqel (p.n.) Michael"
   }, 
   {
      id: 2755,
      word: "mayvIm",
      name: "mayvIm (n.) embryo"
   }, 
   {
      id: 2756,
      word: "me'",
      name: "me' (n.) aunt, mother's sister"
   }, 
   {
      id: 2757,
      word: "me'HIyqo",
      name: "me'HIyqo (n.) Mexico"
   }, 
   {
      id: 2758,
      word: "me'cheD",
      name: "me'cheD (n.) cross (+), ex (x)"
   }, 
   {
      id: 2759,
      word: "me'nal",
      name: "me'nal (n.) aunt, mother's brother's wife"
   }, 
   {
      id: 2760,
      word: "meH",
      name: "meH (n.) bridge (of a ship)"
   }, 
   {
      id: 2761,
      word: "meH",
      name: "meH (vs9) for (purpose-clause marker)"
   }, 
   {
      id: 2762,
      word: "meHghem",
      name: "meHghem (n.) arts, the arts, culture"
   }, 
   {
      id: 2763,
      word: "meQ",
      name: "meQ (v.) burn, be on fire"
   }, 
   {
      id: 2764,
      word: "meQHam",
      name: "meQHam (adverb) ironically, counterintuitively, incongruously"
   }, 
   {
      id: 2765,
      word: "meQboghnom",
      name: "meQboghnom (p.n.) Kahless's revolutionary banner"
   }, 
   {
      id: 2766,
      word: "meS",
      name: "meS (n.) knot"
   }, 
   {
      id: 2767,
      word: "meS",
      name: "meS (v.) knot, tie a knot in something, encrypt (slang)"
   }, 
   {
      id: 2768,
      word: "meSchuS",
      name: "meSchuS (n.) large wind instrument"
   }, 
   {
      id: 2769,
      word: "meb",
      name: "meb (n.) guest"
   }, 
   {
      id: 2770,
      word: "mebpa'mey",
      name: "mebpa'mey (n.) hotel"
   }, 
   {
      id: 2771,
      word: "mech",
      name: "mech (v.) trade"
   }, 
   {
      id: 2772,
      word: "megh",
      name: "megh (n.) lunch"
   }, 
   {
      id: 2773,
      word: "megh'an",
      name: "megh'an (n.) end (of stick, rope, etc.), other end from {'er'In}"
   }, 
   {
      id: 2774,
      word: "mej",
      name: "mej (v.) leave, depart, gone"
   }, 
   {
      id: 2775,
      word: "mej'aD",
      name: "mej'aD (n.) artery"
   }, 
   {
      id: 2776,
      word: "mejnay",
      name: "mejnay (n.) apron (clothing)"
   }, 
   {
      id: 2777,
      word: "mel'ogh",
      name: "mel'ogh (n.) chrysalis"
   }, 
   {
      id: 2778,
      word: "melchoQ",
      name: "melchoQ (n.) marrow, bone marrow"
   }, 
   {
      id: 2779,
      word: "mellota'",
      name: "mellota' (p.n.) Melota - proper name from Klingon Opera"
   }, 
   {
      id: 2780,
      word: "mem",
      name: "mem (n.) catalog"
   }, 
   {
      id: 2781,
      word: "men",
      name: "men (v.) have an area of"
   }, 
   {
      id: 2782,
      word: "menggho' naH",
      name: "menggho' naH (n.) mango"
   }, 
   {
      id: 2783,
      word: "mentIy Hol",
      name: "mentIy Hol (n.) Mänti"
   }, 
   {
      id: 2784,
      word: "mep",
      name: "mep (n.) plastic"
   }, 
   {
      id: 2785,
      word: "meq",
      name: "meq (v.) reason"
   }, 
   {
      id: 2786,
      word: "meq",
      name: "meq (n.) reason, motive, logical thinking"
   }, 
   {
      id: 2787,
      word: "meq",
      name: "meq (n.) topic, subject, theme"
   }, 
   {
      id: 2788,
      word: "meqHoD",
      name: "meqHoD (n.) bypass"
   }, 
   {
      id: 2789,
      word: "meqba'",
      name: "meqba' (n.) legal proceeding (type of)"
   }, 
   {
      id: 2790,
      word: "meqba'",
      name: "meqba' (n.) type of legal proceeding; portion of the trial or appeal where evidence is  heard"
   }, 
   {
      id: 2791,
      word: "meqleH",
      name: "meqleH (n.) type of weapon, mek'leth"
   }, 
   {
      id: 2792,
      word: "meqro'vaq",
      name: "meqro'vaq (n.) Mekro'vak (region)"
   }, 
   {
      id: 2793,
      word: "mer",
      name: "mer (v.) surprise"
   }, 
   {
      id: 2794,
      word: "mergh",
      name: "mergh (v.) be combined, mixed together"
   }, 
   {
      id: 2795,
      word: "mev",
      name: "mev (v.) stop, cease"
   }, 
   {
      id: 2796,
      word: "mevaq",
      name: "mevaq (n.) mevak dagger"
   }, 
   {
      id: 2797,
      word: "mevyap",
      name: "mevyap (exclamation) stop, enough already"
   }, 
   {
      id: 2798,
      word: "mew'",
      name: "mew' (v.) cope, cope with, deal (well) with, handle"
   }, 
   {
      id: 2799,
      word: "mey",
      name: "mey (v.) match, fit onto, interlock with, interlace with, mesh with"
   }, 
   {
      id: 2800,
      word: "mey",
      name: "mey (ns2) plural (general)"
   }, 
   {
      id: 2801,
      word: "mey'",
      name: "mey' (n.) polygon"
   }, 
   {
      id: 2802,
      word: "meyIS",
      name: "meyIS (n.) maize"
   }, 
   {
      id: 2803,
      word: "meyIS tIr",
      name: "meyIS tIr (n.) sweet corn"
   }, 
   {
      id: 2804,
      word: "meyrI'",
      name: "meyrI' (n.) square"
   }, 
   {
      id: 2805,
      word: "mo'",
      name: "mo' (vs9) because"
   }, 
   {
      id: 2806,
      word: "mo'",
      name: "mo' (n.) cage"
   }, 
   {
      id: 2807,
      word: "mo'",
      name: "mo' (ns5) due to"
   }, 
   {
      id: 2808,
      word: "mo'",
      name: "mo' (n.) motive (slang), motivation (slang), grounds (slang), reason (slang), rationale (slang)"
   }, 
   {
      id: 2809,
      word: "mo'bIj",
      name: "mo'bIj (n.) latch"
   }, 
   {
      id: 2810,
      word: "mo'qay tuq",
      name: "mo'qay tuq (p.n.) House of Mo'kai"
   }, 
   {
      id: 2811,
      word: "mo'rISqa'",
      name: "mo'rISqa' (n.) Morska"
   }, 
   {
      id: 2812,
      word: "moD",
      name: "moD (v.) hurry"
   }, 
   {
      id: 2813,
      word: "moD Soj",
      name: "moD Soj (n.) fast food"
   }, 
   {
      id: 2814,
      word: "moH",
      name: "moH (v.) be ugly"
   }, 
   {
      id: 2815,
      word: "moH",
      name: "moH (vs4) cause"
   }, 
   {
      id: 2816,
      word: "moH",
      name: "moH (v.) influence, exert undue influence on (slang)"
   }, 
   {
      id: 2817,
      word: "moHaq",
      name: "moHaq (n.) prefix"
   }, 
   {
      id: 2818,
      word: "moHbey",
      name: "moHbey (n.) trapezium"
   }, 
   {
      id: 2819,
      word: "moQ",
      name: "moQ (n.) sphere"
   }, 
   {
      id: 2820,
      word: "moQ",
      name: "moQ (n.) spiked pommel of a d'k tahg knife"
   }, 
   {
      id: 2821,
      word: "moQbID",
      name: "moQbID (n.) dome"
   }, 
   {
      id: 2822,
      word: "moQbara'",
      name: "moQbara' (n.) a type of martial art, Mok'bara"
   }, 
   {
      id: 2823,
      word: "moS",
      name: "moS (v.) compromise"
   }, 
   {
      id: 2824,
      word: "moSambIyqI",
      name: "moSambIyqI (n.) Mozambique"
   }, 
   {
      id: 2825,
      word: "mob",
      name: "mob (v.) be alone"
   }, 
   {
      id: 2826,
      word: "moch",
      name: "moch (n.) superior"
   }, 
   {
      id: 2827,
      word: "mogh",
      name: "mogh (v.) be frustrated"
   }, 
   {
      id: 2828,
      word: "mogh",
      name: "mogh (p.n.) Mogh"
   }, 
   {
      id: 2829,
      word: "moj",
      name: "moj (v.) become"
   }, 
   {
      id: 2830,
      word: "mojaq",
      name: "mojaq (n.) suffix"
   }, 
   {
      id: 2831,
      word: "mol",
      name: "mol (v.) bury"
   }, 
   {
      id: 2832,
      word: "mol",
      name: "mol (n.) grave"
   }, 
   {
      id: 2833,
      word: "molDo'va",
      name: "molDo'va (n.) Moldova"
   }, 
   {
      id: 2834,
      word: "molHa'",
      name: "molHa' (v.) dig up"
   }, 
   {
      id: 2835,
      word: "molor",
      name: "molor (p.n.) Molor"
   }, 
   {
      id: 2836,
      word: "mon",
      name: "mon (n.) capital (of a place)"
   }, 
   {
      id: 2837,
      word: "mon",
      name: "mon (v.) smile"
   }, 
   {
      id: 2838,
      word: "mon",
      name: "mon (v.) smile, grin, sneer"
   }, 
   {
      id: 2839,
      word: "monQIv",
      name: "monQIv (n.) algae"
   }, 
   {
      id: 2840,
      word: "mong",
      name: "mong (n.) neck"
   }, 
   {
      id: 2841,
      word: "mongDech",
      name: "mongDech (n.) collar"
   }, 
   {
      id: 2842,
      word: "mongghol 'uluS",
      name: "mongghol 'uluS (n.) Mongolia"
   }, 
   {
      id: 2843,
      word: "mop",
      name: "mop (n.) robe"
   }, 
   {
      id: 2844,
      word: "moq",
      name: "moq (v.) beat (something with an implement)"
   }, 
   {
      id: 2845,
      word: "moqbara",
      name: "moqbara (n.) mok'bara (misspelling of moQbara')"
   }, 
   {
      id: 2846,
      word: "moqlam",
      name: "moqlam (n.) feldspar"
   }, 
   {
      id: 2847,
      word: "moqtay'",
      name: "moqtay' (n.) bruise"
   }, 
   {
      id: 2848,
      word: "mor",
      name: "mor (v.) be agile, be dexterous"
   }, 
   {
      id: 2849,
      word: "morIS",
      name: "morIS (n.) Mauritius"
   }, 
   {
      id: 2850,
      word: "moratlh",
      name: "moratlh (p.n.) Morath"
   }, 
   {
      id: 2851,
      word: "morgh",
      name: "morgh (v.) protest"
   }, 
   {
      id: 2852,
      word: "morgh",
      name: "morgh (n.) unit of area (27 square 'ujmey)"
   }, 
   {
      id: 2853,
      word: "morwI'",
      name: "morwI' (n.) ant(s), formicidae"
   }, 
   {
      id: 2854,
      word: "morwI' ghew",
      name: "morwI' ghew (n.) ant(s), formicidae"
   }, 
   {
      id: 2855,
      word: "mot",
      name: "mot (v.) be stunned, be knocked out"
   }, 
   {
      id: 2856,
      word: "motlh",
      name: "motlh (v.) be usual, be normal, be standard"
   }, 
   {
      id: 2857,
      word: "motlh",
      name: "motlh (adverb) usually, typically, as expected, expectedly"
   }, 
   {
      id: 2858,
      word: "motlhbe'",
      name: "motlhbe' (v.) be unusual"
   }, 
   {
      id: 2859,
      word: "mov",
      name: "mov (n.) top of foot"
   }, 
   {
      id: 2860,
      word: "moy'bI'",
      name: "moy'bI' (n.) slingshot"
   }, 
   {
      id: 2861,
      word: "mu",
      name: "mu (vp) he/she/it/they-me"
   }, 
   {
      id: 2862,
      word: "mu'",
      name: "mu' (n.) word"
   }, 
   {
      id: 2863,
      word: "mu' qun",
      name: "mu' qun (n.) etymology"
   }, 
   {
      id: 2864,
      word: "mu' qunQeD",
      name: "mu' qunQeD (n.) discipline of studying word histories"
   }, 
   {
      id: 2865,
      word: "mu'ghom",
      name: "mu'ghom (n.) dictionary"
   }, 
   {
      id: 2866,
      word: "mu'mey Doy'",
      name: "mu'mey Doy' (n.) tired words (used to refer to the language used by older Klingons)"
   }, 
   {
      id: 2867,
      word: "mu'mey ghoQ",
      name: "mu'mey ghoQ (n.) slang, fresh words (mostly used by younger Klingons)"
   }, 
   {
      id: 2868,
      word: "mu'mey ru'",
      name: "mu'mey ru' (n.) temporary words (ungrammatical expression used for impact)"
   }, 
   {
      id: 2869,
      word: "mu'neqo",
      name: "mu'neqo (n.) Monaco"
   }, 
   {
      id: 2870,
      word: "mu'qaD",
      name: "mu'qaD (n.) curse, insult,"
   }, 
   {
      id: 2871,
      word: "mu'qaD veS",
      name: "mu'qaD veS (n.) curse warfare"
   }, 
   {
      id: 2872,
      word: "mu'tay'",
      name: "mu'tay' (n.) vocabulary"
   }, 
   {
      id: 2873,
      word: "mu'tlhegh",
      name: "mu'tlhegh (n.) sentence"
   }, 
   {
      id: 2874,
      word: "mu'tlhegh meS",
      name: "mu'tlhegh meS (n.) paragraph"
   }, 
   {
      id: 2875,
      word: "mu'vIb",
      name: "mu'vIb (n.) whistle (hand-held device) with a shrill sound"
   }, 
   {
      id: 2876,
      word: "mu'vaj",
      name: "mu'vaj (p.n.) Adam Walker"
   }, 
   {
      id: 2877,
      word: "muD",
      name: "muD (n.) atmosphere, weather"
   }, 
   {
      id: 2878,
      word: "muD",
      name: "muD (n.) weather (in general)"
   }, 
   {
      id: 2879,
      word: "muD 'umber",
      name: "muD 'umber (n.) climate"
   }, 
   {
      id: 2880,
      word: "muD Dotlh",
      name: "muD Dotlh (n.) weather (at any given moment)"
   }, 
   {
      id: 2881,
      word: "muD Duj",
      name: "muD Duj (n.) airplane, atmosphere vessel"
   }, 
   {
      id: 2882,
      word: "muH",
      name: "muH (v.) execute, put to death"
   }, 
   {
      id: 2883,
      word: "muS",
      name: "muS (v.) hate, detest"
   }, 
   {
      id: 2884,
      word: "muSghoraw",
      name: "muSghoraw (n.) valve"
   }, 
   {
      id: 2885,
      word: "mub",
      name: "mub (v.) be legal"
   }, 
   {
      id: 2886,
      word: "much",
      name: "much (v.) perform (music)"
   }, 
   {
      id: 2887,
      word: "much",
      name: "much (v.) present"
   }, 
   {
      id: 2888,
      word: "much",
      name: "much (n.) presentation"
   }, 
   {
      id: 2889,
      word: "much Qe'",
      name: "much Qe' (n.) cabaret (location)"
   }, 
   {
      id: 2890,
      word: "much jech",
      name: "much jech (n.) costume"
   }, 
   {
      id: 2891,
      word: "much qach",
      name: "much qach (n.) theater"
   }, 
   {
      id: 2892,
      word: "much yaH",
      name: "much yaH (n.) stage"
   }, 
   {
      id: 2893,
      word: "muchpa'",
      name: "muchpa' (n.) auditorium"
   }, 
   {
      id: 2894,
      word: "muchwI'",
      name: "muchwI' (n.) musician"
   }, 
   {
      id: 2895,
      word: "mugh",
      name: "mugh (v.) translate"
   }, 
   {
      id: 2896,
      word: "mughato'",
      name: "mughato' (n.) mugato"
   }, 
   {
      id: 2897,
      word: "mughbogh permey",
      name: "mughbogh permey (n.) subtitles"
   }, 
   {
      id: 2898,
      word: "mughwI'",
      name: "mughwI' (n.) translator"
   }, 
   {
      id: 2899,
      word: "muj",
      name: "muj (v.) be wrong, incorrect"
   }, 
   {
      id: 2900,
      word: "mul",
      name: "mul (v.) be stubborn"
   }, 
   {
      id: 2901,
      word: "mum",
      name: "mum (v.) fancy, have a crush"
   }, 
   {
      id: 2902,
      word: "mum",
      name: "mum (v.) taste, sense flavors"
   }, 
   {
      id: 2903,
      word: "mun",
      name: "mun (v.) intervene"
   }, 
   {
      id: 2904,
      word: "mun'a'",
      name: "mun'a' (n.) unit of area"
   }, 
   {
      id: 2905,
      word: "mung",
      name: "mung (n.) origin"
   }, 
   {
      id: 2906,
      word: "mup",
      name: "mup (v.) impact, strike"
   }, 
   {
      id: 2907,
      word: "mupSoy",
      name: "mupSoy (n.) moopsy"
   }, 
   {
      id: 2908,
      word: "mupwI'",
      name: "mupwI' (n.) hammer"
   }, 
   {
      id: 2909,
      word: "mupwI'Hom",
      name: "mupwI'Hom (n.) mallet (for striking a musical instrument)"
   }, 
   {
      id: 2910,
      word: "muq",
      name: "muq (v.) have a volume of"
   }, 
   {
      id: 2911,
      word: "mur",
      name: "mur (v.) wince, cringe, flinch"
   }, 
   {
      id: 2912,
      word: "murItanya'",
      name: "murItanya' (n.) Mauritania"
   }, 
   {
      id: 2913,
      word: "murgh",
      name: "murgh (v.) droop, slouch, be limp"
   }, 
   {
      id: 2914,
      word: "mut",
      name: "mut (v.) be selfish"
   }, 
   {
      id: 2915,
      word: "mut",
      name: "mut (n.) species"
   }, 
   {
      id: 2916,
      word: "mutchoH",
      name: "mutchoH (n.) evolution (Darwinian)"
   }, 
   {
      id: 2917,
      word: "mutlh",
      name: "mutlh (v.) construct, assemble, put together, manufacture"
   }, 
   {
      id: 2918,
      word: "mutlh",
      name: "mutlh (v.) manufacture, construct, put together"
   }, 
   {
      id: 2919,
      word: "mutlhwI'",
      name: "mutlhwI' (n.) constructor, assembler, put togetherer"
   }, 
   {
      id: 2920,
      word: "mutwa'",
      name: "mutwa' (n.) protozoan"
   }, 
   {
      id: 2921,
      word: "muv",
      name: "muv (v.) join"
   }, 
   {
      id: 2922,
      word: "muvmoH",
      name: "muvmoH (v.) recruit"
   }, 
   {
      id: 2923,
      word: "muvtay",
      name: "muvtay (n.) initiation"
   }, 
   {
      id: 2924,
      word: "muylIS",
      name: "muylIS (n.) eyelash"
   }, 
   {
      id: 2925,
      word: "nI",
      name: "nI (vp) they-you"
   }, 
   {
      id: 2926,
      word: "nI'",
      name: "nI' (v.) be long, be lengthy (duration)"
   }, 
   {
      id: 2927,
      word: "nI'qur",
      name: "nI'qur (n.) kelp"
   }, 
   {
      id: 2928,
      word: "nID",
      name: "nID (v.) attempt, try"
   }, 
   {
      id: 2929,
      word: "nIH",
      name: "nIH (n.) right (side)"
   }, 
   {
      id: 2930,
      word: "nIH",
      name: "nIH (v.) steal"
   }, 
   {
      id: 2931,
      word: "nIHwI'",
      name: "nIHwI' (n.) thief"
   }, 
   {
      id: 2932,
      word: "nIQ",
      name: "nIQ (n.) breakfast"
   }, 
   {
      id: 2933,
      word: "nIS",
      name: "nIS (v.) disrupt, interfere"
   }, 
   {
      id: 2934,
      word: "nIS",
      name: "nIS (v.) interfere (with)"
   }, 
   {
      id: 2935,
      word: "nIS",
      name: "nIS (vs2) need"
   }, 
   {
      id: 2936,
      word: "nISwI'",
      name: "nISwI' (n.) disruptor"
   }, 
   {
      id: 2937,
      word: "nISwI' DaH",
      name: "nISwI' DaH (n.) disruptor banks"
   }, 
   {
      id: 2938,
      word: "nISwI' HIch",
      name: "nISwI' HIch (n.) hand-held disruptor, disruptor pistol"
   }, 
   {
      id: 2939,
      word: "nISwI' beH",
      name: "nISwI' beH (n.) disruptor rifle"
   }, 
   {
      id: 2940,
      word: "nISwI' tIH",
      name: "nISwI' tIH (n.) disruptor beam"
   }, 
   {
      id: 2941,
      word: "nIb",
      name: "nIb (v.) be identical"
   }, 
   {
      id: 2942,
      word: "nIbpoH",
      name: "nIbpoH (n.) Déjà vu"
   }, 
   {
      id: 2943,
      word: "nIch",
      name: "nIch (n.) ammunition"
   }, 
   {
      id: 2944,
      word: "nIj",
      name: "nIj (v.) leak"
   }, 
   {
      id: 2945,
      word: "nIl",
      name: "nIl (v.) be grassy"
   }, 
   {
      id: 2946,
      word: "nIl'atrogh",
      name: "nIl'atrogh (n.) charcoal"
   }, 
   {
      id: 2947,
      word: "nIm",
      name: "nIm (n.) milk"
   }, 
   {
      id: 2948,
      word: "nIm qulcher taD",
      name: "nIm qulcher taD (n.) ice cream"
   }, 
   {
      id: 2949,
      word: "nIm tlhagh",
      name: "nIm tlhagh (n.) butter"
   }, 
   {
      id: 2950,
      word: "nIm wIb ngogh",
      name: "nIm wIb ngogh (n.) cheese"
   }, 
   {
      id: 2951,
      word: "nImbuS wej",
      name: "nImbuS wej (n.) Nimbus III"
   }, 
   {
      id: 2952,
      word: "nIn",
      name: "nIn (n.) fuel"
   }, 
   {
      id: 2953,
      word: "nIpon",
      name: "nIpon (n.) Japan"
   }, 
   {
      id: 2954,
      word: "nIq",
      name: "nIq (v.) weave, knit"
   }, 
   {
      id: 2955,
      word: "nIq mIr",
      name: "nIq mIr (n.) alternating current/AC"
   }, 
   {
      id: 2956,
      word: "nIqDob",
      name: "nIqDob (n.) perforator, hole punch"
   }, 
   {
      id: 2957,
      word: "nIqHom",
      name: "nIqHom (n.) software"
   }, 
   {
      id: 2958,
      word: "nIt",
      name: "nIt (v.) be plain, be pure, be uncorrupted, be unsullied"
   }, 
   {
      id: 2959,
      word: "nIteb",
      name: "nIteb (adverb) alone, acting alone"
   }, 
   {
      id: 2960,
      word: "nItebHa'",
      name: "nItebHa' (adverb) together"
   }, 
   {
      id: 2961,
      word: "nItlh",
      name: "nItlh (n.) finger"
   }, 
   {
      id: 2962,
      word: "nItlh 'echlet",
      name: "nItlh 'echlet (n.) keyboard"
   }, 
   {
      id: 2963,
      word: "nItlh gheb",
      name: "nItlh gheb (n.) trumpet"
   }, 
   {
      id: 2964,
      word: "nItlh naQ",
      name: "nItlh naQ (n.) pigment stick (slang)"
   }, 
   {
      id: 2965,
      word: "nItlhpach",
      name: "nItlhpach (n.) fingernail"
   }, 
   {
      id: 2966,
      word: "nItlhpach",
      name: "nItlhpach (n.) flat end of pigment stick"
   }, 
   {
      id: 2967,
      word: "nIv",
      name: "nIv (v.) be superior"
   }, 
   {
      id: 2968,
      word: "nIve'Da'",
      name: "nIve'Da' (n.) Nevada"
   }, 
   {
      id: 2969,
      word: "nIvnav",
      name: "nIvnav (n.) pajamas"
   }, 
   {
      id: 2970,
      word: "nIwqen",
      name: "nIwqen (n.) gill"
   }, 
   {
      id: 2971,
      word: "nIyjer",
      name: "nIyjer (n.) Niger"
   }, 
   {
      id: 2972,
      word: "nIyma'",
      name: "nIyma' (n.) phantom, apparition, something that appears to be there but is not"
   }, 
   {
      id: 2973,
      word: "na'",
      name: "na' (v.) be salty, be brackish, be sure (slang), be definite (slang), be positive (slang), be certain (slang)"
   }, 
   {
      id: 2974,
      word: "na'",
      name: "na' (ns3) definite"
   }, 
   {
      id: 2975,
      word: "na'choS",
      name: "na'choS (n.) nachos"
   }, 
   {
      id: 2976,
      word: "na'ran",
      name: "na'ran (n.) type of fruit"
   }, 
   {
      id: 2977,
      word: "na'vIy Hol",
      name: "na'vIy Hol (n.) Na'vi"
   }, 
   {
      id: 2978,
      word: "naD",
      name: "naD (n.) commendation"
   }, 
   {
      id: 2979,
      word: "naD",
      name: "naD (v.) praise, commend, approve"
   }, 
   {
      id: 2980,
      word: "naD tetlh",
      name: "naD tetlh (n.) Commendation List"
   }, 
   {
      id: 2981,
      word: "naDHa'",
      name: "naDHa' (v.) discommend, disapprove"
   }, 
   {
      id: 2982,
      word: "naDHa'ghach",
      name: "naDHa'ghach (n.) discommendation"
   }, 
   {
      id: 2983,
      word: "naDev",
      name: "naDev (n.) here, hereabouts"
   }, 
   {
      id: 2984,
      word: "naDqa'ghach",
      name: "naDqa'ghach (n.) re-commendation"
   }, 
   {
      id: 2985,
      word: "naH",
      name: "naH (v.) be hostile, be malicious, be unfriendly, be antagonistic"
   }, 
   {
      id: 2986,
      word: "naH",
      name: "naH (n.) fruit, vegetable"
   }, 
   {
      id: 2987,
      word: "naH mergh",
      name: "naH mergh (n.) general term for types of salad"
   }, 
   {
      id: 2988,
      word: "naH taj",
      name: "naH taj (n.) vegetable knife, fruit knife (small knife)"
   }, 
   {
      id: 2989,
      word: "naHjej",
      name: "naHjej (n.) thistle"
   }, 
   {
      id: 2990,
      word: "naHlet",
      name: "naHlet (n.) nut, nuts"
   }, 
   {
      id: 2991,
      word: "naHnagh",
      name: "naHnagh (n.) pit (of fruit)"
   }, 
   {
      id: 2992,
      word: "naQ",
      name: "naQ (v.) be full, be whole, be entire, be complete"
   }, 
   {
      id: 2993,
      word: "naQ",
      name: "naQ (n.) ponytail (slang)"
   }, 
   {
      id: 2994,
      word: "naQ",
      name: "naQ (n.) staff"
   }, 
   {
      id: 2995,
      word: "naQ 'er",
      name: "naQ 'er (n.) brush devil (a Klingon animal)"
   }, 
   {
      id: 2996,
      word: "naQHom",
      name: "naQHom (n.) stick (used to strike percussion instrument)"
   }, 
   {
      id: 2997,
      word: "naQjej",
      name: "naQjej (n.) hunting spear"
   }, 
   {
      id: 2998,
      word: "naQjej",
      name: "naQjej (n.) spear"
   }, 
   {
      id: 2999,
      word: "naQjejHom",
      name: "naQjejHom (n.) arrow"
   }, 
   {
      id: 3000,
      word: "naS",
      name: "naS (v.) be vicious"
   }, 
   {
      id: 3001,
      word: "naSIn",
      name: "naSIn (n.) vertical post"
   }, 
   {
      id: 3002,
      word: "nab",
      name: "nab (v.) plan"
   }, 
   {
      id: 3003,
      word: "nab",
      name: "nab (n.) plan, procedure"
   }, 
   {
      id: 3004,
      word: "nach",
      name: "nach (n.) head"
   }, 
   {
      id: 3005,
      word: "nach Ha'quj",
      name: "nach Ha'quj (n.) scarf (slang)"
   }, 
   {
      id: 3006,
      word: "nagh",
      name: "nagh (n.) rock, stone"
   }, 
   {
      id: 3007,
      word: "nagh",
      name: "nagh (n.) stone, rock, ceramic material"
   }, 
   {
      id: 3008,
      word: "nagh DIr",
      name: "nagh DIr (n.) shell (of an animal)"
   }, 
   {
      id: 3009,
      word: "nagh HeH",
      name: "nagh HeH (n.) curb"
   }, 
   {
      id: 3010,
      word: "nagh beQ",
      name: "nagh beQ (n.) stone panel (artwork, similar to a painting)"
   }, 
   {
      id: 3011,
      word: "nagh ghun",
      name: "nagh ghun (n.) terracotta"
   }, 
   {
      id: 3012,
      word: "naghboch",
      name: "naghboch (n.) gemstone"
   }, 
   {
      id: 3013,
      word: "naj",
      name: "naj (v.) dream"
   }, 
   {
      id: 3014,
      word: "najmoHwI'",
      name: "najmoHwI' (n.) lullaby"
   }, 
   {
      id: 3015,
      word: "nalqaD",
      name: "nalqaD (n.) mate challange"
   }, 
   {
      id: 3016,
      word: "nalqad",
      name: "nalqad (n.) mate challenge"
   }, 
   {
      id: 3017,
      word: "nam",
      name: "nam (v.) move counterclockwise"
   }, 
   {
      id: 3018,
      word: "namIbya'",
      name: "namIbya' (n.) Namibia"
   }, 
   {
      id: 3019,
      word: "namchIl",
      name: "namchIl (n.) chlorophyll"
   }, 
   {
      id: 3020,
      word: "namtun",
      name: "namtun (n.) the familiar beginning of a song"
   }, 
   {
      id: 3021,
      word: "namwech",
      name: "namwech (n.) paw"
   }, 
   {
      id: 3022,
      word: "namyaS",
      name: "namyaS (n.) hood (of a cloak, robe, sweatshirt, or whatever)"
   }, 
   {
      id: 3023,
      word: "nan",
      name: "nan (v.) gouge"
   }, 
   {
      id: 3024,
      word: "nan",
      name: "nan (v.) use the fourth toe"
   }, 
   {
      id: 3025,
      word: "nanwI'",
      name: "nanwI' (n.) chisel"
   }, 
   {
      id: 3026,
      word: "nanwI'",
      name: "nanwI' (n.) fourth toe"
   }, 
   {
      id: 3027,
      word: "nap",
      name: "nap (v.) be simple"
   }, 
   {
      id: 3028,
      word: "naptop",
      name: "naptop (n.) eclipse"
   }, 
   {
      id: 3029,
      word: "naq",
      name: "naq (v.) be iridescent"
   }, 
   {
      id: 3030,
      word: "nar",
      name: "nar (v.) reflect"
   }, 
   {
      id: 3031,
      word: "nargh",
      name: "nargh (v.) appear, escape, grow (a mustache, beard)"
   }, 
   {
      id: 3032,
      word: "natlIS",
      name: "natlIS (n.) last item in a list"
   }, 
   {
      id: 3033,
      word: "natlh",
      name: "natlh (v.) drain, use up, consume, expend, be reprehensible (slang), be disgusting (slang), be contemptible (slang)"
   }, 
   {
      id: 3034,
      word: "nav",
      name: "nav (n.) paper, sheet of paper"
   }, 
   {
      id: 3035,
      word: "nav HablI'",
      name: "nav HablI' (n.) FAX machine"
   }, 
   {
      id: 3036,
      word: "nav QIn",
      name: "nav QIn (n.) letter (message written on paper)"
   }, 
   {
      id: 3037,
      word: "nav vaH",
      name: "nav vaH (n.) envelope (paper cover)"
   }, 
   {
      id: 3038,
      word: "navSu'",
      name: "navSu' (n.) key, legend (as on a map)"
   }, 
   {
      id: 3039,
      word: "naw'",
      name: "naw' (n.) access"
   }, 
   {
      id: 3040,
      word: "naw'",
      name: "naw' (v.) access"
   }, 
   {
      id: 3041,
      word: "naw'wat",
      name: "naw'wat (n.) remote, small, desolate place"
   }, 
   {
      id: 3042,
      word: "nawlogh",
      name: "nawlogh (n.) squadron"
   }, 
   {
      id: 3043,
      word: "nay",
      name: "nay (v.) marry (wife does this)"
   }, 
   {
      id: 3044,
      word: "nay'",
      name: "nay' (n.) course (at a meal), dish (at a meal)"
   }, 
   {
      id: 3045,
      word: "nayeghra",
      name: "nayeghra (p.n.) Niagara"
   }, 
   {
      id: 3046,
      word: "nayjerya'",
      name: "nayjerya' (n.) Nigeria"
   }, 
   {
      id: 3047,
      word: "ne'",
      name: "ne' (n.) jack in a deck of cards"
   }, 
   {
      id: 3048,
      word: "ne'",
      name: "ne' (n.) yeoman"
   }, 
   {
      id: 3049,
      word: "ne'Derlan",
      name: "ne'Derlan (n.) The Netherlands"
   }, 
   {
      id: 3050,
      word: "neH",
      name: "neH (adverb) only, merely, just"
   }, 
   {
      id: 3051,
      word: "neH",
      name: "neH (v.) want"
   }, 
   {
      id: 3052,
      word: "neHHa'",
      name: "neHHa' (adverb) not only"
   }, 
   {
      id: 3053,
      word: "neHjej",
      name: "neHjej (n.) thistle"
   }, 
   {
      id: 3054,
      word: "neHmaH",
      name: "neHmaH (n.) neutral zone"
   }, 
   {
      id: 3055,
      word: "neS",
      name: "neS (v.) be crunchy, be crispy"
   }, 
   {
      id: 3056,
      word: "neS",
      name: "neS (vs8) honorific"
   }, 
   {
      id: 3057,
      word: "neSlo'",
      name: "neSlo' (n.) small mirror"
   }, 
   {
      id: 3058,
      word: "neSngech",
      name: "neSngech (n.) dormouse-like animal"
   }, 
   {
      id: 3059,
      word: "neb",
      name: "neb (n.) beak, bill"
   }, 
   {
      id: 3060,
      word: "neb",
      name: "neb (n.) nozzle (like on the end of a hose)"
   }, 
   {
      id: 3061,
      word: "neb mIv",
      name: "neb mIv (n.) baseball cap"
   }, 
   {
      id: 3062,
      word: "neb mIv let",
      name: "neb mIv let (n.) baseball helmet"
   }, 
   {
      id: 3063,
      word: "neb mIv tun",
      name: "neb mIv tun (n.) baseball cap"
   }, 
   {
      id: 3064,
      word: "nebeylI'",
      name: "nebeylI' (n.) sarcophagus (fancy)"
   }, 
   {
      id: 3065,
      word: "nech",
      name: "nech (v.) be lateral, move laterally"
   }, 
   {
      id: 3066,
      word: "negh",
      name: "negh (n.) soldiers"
   }, 
   {
      id: 3067,
      word: "nej",
      name: "nej (v.) look for, seek, search for"
   }, 
   {
      id: 3068,
      word: "nejwI'",
      name: "nejwI' (n.) probe"
   }, 
   {
      id: 3069,
      word: "nel",
      name: "nel (v.) match, pair up, map onto"
   }, 
   {
      id: 3070,
      word: "nelchu'",
      name: "nelchu' (v.) fit in perfectly, fit perfectly"
   }, 
   {
      id: 3071,
      word: "nelmeS",
      name: "nelmeS (n.) hyperlink"
   }, 
   {
      id: 3072,
      word: "nem",
      name: "nem (n.) years from now"
   }, 
   {
      id: 3073,
      word: "nen",
      name: "nen (v.) be ascended, be mature, be grown-up, be adult"
   }, 
   {
      id: 3074,
      word: "nen",
      name: "nen (n.) growth, maturation"
   }, 
   {
      id: 3075,
      word: "nen DuSaQ",
      name: "nen DuSaQ (n.) high school, secondary education"
   }, 
   {
      id: 3076,
      word: "nenchoH",
      name: "nenchoH (v.) mature, grow up"
   }, 
   {
      id: 3077,
      word: "neng'el",
      name: "neng'el (n.) metal grid, metal lattice, barbecue grill"
   }, 
   {
      id: 3078,
      word: "nenghep",
      name: "nenghep (n.) Age of Ascension"
   }, 
   {
      id: 3079,
      word: "nentay",
      name: "nentay (n.) Rite of Ascension"
   }, 
   {
      id: 3080,
      word: "nentay cha'DIch",
      name: "nentay cha'DIch (n.) Second Rite of Ascension"
   }, 
   {
      id: 3081,
      word: "nentay wa'DIch",
      name: "nentay wa'DIch (n.) First Rite of Ascension"
   }, 
   {
      id: 3082,
      word: "nep",
      name: "nep (v.) lie, fib"
   }, 
   {
      id: 3083,
      word: "neq",
      name: "neq (v.) intersect"
   }, 
   {
      id: 3084,
      word: "neqjung",
      name: "neqjung (n.) contact, encounter, rendezvous"
   }, 
   {
      id: 3085,
      word: "neqratlh",
      name: "neqratlh (n.) glasses, spectacles"
   }, 
   {
      id: 3086,
      word: "net",
      name: "net (pronoun) that (previous topic)"
   }, 
   {
      id: 3087,
      word: "netlh",
      name: "netlh (number) ten thousand"
   }, 
   {
      id: 3088,
      word: "netlh'uy'",
      name: "netlh'uy' (number) 10 billion"
   }, 
   {
      id: 3089,
      word: "nev'aQ",
      name: "nev'aQ (n.) sarcophagus (simple)"
   }, 
   {
      id: 3090,
      word: "nev'ob",
      name: "nev'ob (n.) thigh, upper arm"
   }, 
   {
      id: 3091,
      word: "nevDagh",
      name: "nevDagh (n.) type of pot with handles (used for food preparation)"
   }, 
   {
      id: 3092,
      word: "nevroD",
      name: "nevroD (n.) tentacle"
   }, 
   {
      id: 3093,
      word: "neyo Hol",
      name: "neyo Hol (n.) Neo"
   }, 
   {
      id: 3094,
      word: "ngI'",
      name: "ngI' (v.) be pressurized"
   }, 
   {
      id: 3095,
      word: "ngI'",
      name: "ngI' (v.) have a weight of, weigh"
   }, 
   {
      id: 3096,
      word: "ngIDvoS",
      name: "ngIDvoS (n.) lead (element)"
   }, 
   {
      id: 3097,
      word: "ngIS",
      name: "ngIS (n.) Lubricant used on disruptor cannons"
   }, 
   {
      id: 3098,
      word: "ngIb",
      name: "ngIb (n.) ankle (also slang term of deprecation)"
   }, 
   {
      id: 3099,
      word: "ngIbvay",
      name: "ngIbvay (n.) oyster-like creature from Qo'noS that resembles a rock,"
   }, 
   {
      id: 3100,
      word: "ngIj",
      name: "ngIj (v.) be unruly, be rowdy"
   }, 
   {
      id: 3101,
      word: "ngIl",
      name: "ngIl (v.) dare"
   }, 
   {
      id: 3102,
      word: "ngIm",
      name: "ngIm (v.) be putrid"
   }, 
   {
      id: 3103,
      word: "ngIn",
      name: "ngIn (v.) turbulent"
   }, 
   {
      id: 3104,
      word: "ngIng",
      name: "ngIng (v.) have a negative charge, be negatively charged"
   }, 
   {
      id: 3105,
      word: "ngIp",
      name: "ngIp (v.) borrow"
   }, 
   {
      id: 3106,
      word: "ngIq",
      name: "ngIq (n.) single one, individual one, each one"
   }, 
   {
      id: 3107,
      word: "ngIr",
      name: "ngIr (v.) knead, massage"
   }, 
   {
      id: 3108,
      word: "ngIt",
      name: "ngIt (v.) ride"
   }, 
   {
      id: 3109,
      word: "ngItHel",
      name: "ngItHel (n.) type of musical instrument"
   }, 
   {
      id: 3110,
      word: "ngItHel naQ",
      name: "ngItHel naQ (n.) bow"
   }, 
   {
      id: 3111,
      word: "ngItlh",
      name: "ngItlh (v.) be stuck (like a ring on a finger)"
   }, 
   {
      id: 3112,
      word: "ngIv",
      name: "ngIv (v.) patrol"
   }, 
   {
      id: 3113,
      word: "nga'chuq",
      name: "nga'chuq (v.) sex (i.e. perform sex; always subject)"
   }, 
   {
      id: 3114,
      word: "ngaD",
      name: "ngaD (v.) be stable, be balanced"
   }, 
   {
      id: 3115,
      word: "ngaDmoH",
      name: "ngaDmoH (v.) stabilize"
   }, 
   {
      id: 3116,
      word: "ngaDmoHwI'",
      name: "ngaDmoHwI' (n.) stabilizer (component of a ship)"
   }, 
   {
      id: 3117,
      word: "ngaDmoQ",
      name: "ngaDmoQ (n.) gyroscope"
   }, 
   {
      id: 3118,
      word: "ngaH",
      name: "ngaH (v.) squeeze (an object)"
   }, 
   {
      id: 3119,
      word: "ngaQ",
      name: "ngaQ (v.) be locked, be sealed, be secured, be fastened"
   }, 
   {
      id: 3120,
      word: "ngaQHa'moHwI'",
      name: "ngaQHa'moHwI' (n.) key"
   }, 
   {
      id: 3121,
      word: "ngaS",
      name: "ngaS (v.) contain (have inside)"
   }, 
   {
      id: 3122,
      word: "ngab",
      name: "ngab (v.) disappear, vanish"
   }, 
   {
      id: 3123,
      word: "ngach",
      name: "ngach (v.) debate"
   }, 
   {
      id: 3124,
      word: "ngagh",
      name: "ngagh (v.) mate with"
   }, 
   {
      id: 3125,
      word: "ngaj",
      name: "ngaj (v.) be short (in duration)"
   }, 
   {
      id: 3126,
      word: "ngajrun",
      name: "ngajrun (n.) puzzle, riddle"
   }, 
   {
      id: 3127,
      word: "ngal",
      name: "ngal (v.) be chewy"
   }, 
   {
      id: 3128,
      word: "ngam",
      name: "ngam (v.) adhere, stick"
   }, 
   {
      id: 3129,
      word: "ngam'eQ",
      name: "ngam'eQ (n.) gluten"
   }, 
   {
      id: 3130,
      word: "ngan",
      name: "ngan (n.) inhabitant"
   }, 
   {
      id: 3131,
      word: "ngang",
      name: "ngang (v.) straddle"
   }, 
   {
      id: 3132,
      word: "ngang",
      name: "ngang (v.) vary, be varying"
   }, 
   {
      id: 3133,
      word: "ngap",
      name: "ngap (v.) be consonant"
   }, 
   {
      id: 3134,
      word: "ngapHa'",
      name: "ngapHa' (v.) be discordant, dissonant"
   }, 
   {
      id: 3135,
      word: "ngaq",
      name: "ngaq (n.) support (military term)"
   }, 
   {
      id: 3136,
      word: "ngar",
      name: "ngar (v.) be miraculous, supernatural, wondrous"
   }, 
   {
      id: 3137,
      word: "ngat",
      name: "ngat (n.) gunpowder"
   }, 
   {
      id: 3138,
      word: "ngat",
      name: "ngat (n.) herbed granulated cartilage (for food preparation)"
   }, 
   {
      id: 3139,
      word: "ngat 'atlhqam",
      name: "ngat 'atlhqam (n.) a type of mold"
   }, 
   {
      id: 3140,
      word: "ngav",
      name: "ngav (n.) Writer's cramp"
   }, 
   {
      id: 3141,
      word: "ngavyaw'",
      name: "ngavyaw' (n.) canine-like creature (larger than a qovIj)"
   }, 
   {
      id: 3142,
      word: "ngaw",
      name: "ngaw (v.) erode"
   }, 
   {
      id: 3143,
      word: "ngawDeq",
      name: "ngawDeq (n.) mixing stick with flattened, paddlelike end"
   }, 
   {
      id: 3144,
      word: "ngay'",
      name: "ngay' (n.) glory"
   }, 
   {
      id: 3145,
      word: "ngayvo'wan",
      name: "ngayvo'wan (n.) Klingon work pants"
   }, 
   {
      id: 3146,
      word: "nge'",
      name: "nge' (v.) take away"
   }, 
   {
      id: 3147,
      word: "ngeD",
      name: "ngeD (v.) be easy"
   }, 
   {
      id: 3148,
      word: "ngeH",
      name: "ngeH (v.) send"
   }, 
   {
      id: 3149,
      word: "ngeHbej",
      name: "ngeHbej (n.) cosmos"
   }, 
   {
      id: 3150,
      word: "ngeQ",
      name: "ngeQ (v.) bump into, run into, collide with"
   }, 
   {
      id: 3151,
      word: "ngeS",
      name: "ngeS (v.) bake"
   }, 
   {
      id: 3152,
      word: "ngeSlIch",
      name: "ngeSlIch (n.) loan"
   }, 
   {
      id: 3153,
      word: "ngeSlIch 'ap",
      name: "ngeSlIch 'ap (n.) interest"
   }, 
   {
      id: 3154,
      word: "ngeSmoH",
      name: "ngeSmoH (v.) bake"
   }, 
   {
      id: 3155,
      word: "ngeSmoHwI'",
      name: "ngeSmoHwI' (n.) baker (uncommon)"
   }, 
   {
      id: 3156,
      word: "ngeb",
      name: "ngeb (v.) be counterfeit, be false, be fake"
   }, 
   {
      id: 3157,
      word: "ngech",
      name: "ngech (n.) valley, woman's cleavage"
   }, 
   {
      id: 3158,
      word: "ngegh",
      name: "ngegh (v.) traffic in"
   }, 
   {
      id: 3159,
      word: "ngej",
      name: "ngej (v.) infect"
   }, 
   {
      id: 3160,
      word: "ngel",
      name: "ngel (v.) attract, lure"
   }, 
   {
      id: 3161,
      word: "ngelwI'",
      name: "ngelwI' (n.) bait"
   }, 
   {
      id: 3162,
      word: "ngem",
      name: "ngem (n.) forest, woods"
   }, 
   {
      id: 3163,
      word: "ngen",
      name: "ngen (v.) be numb"
   }, 
   {
      id: 3164,
      word: "ngeng",
      name: "ngeng (n.) lake"
   }, 
   {
      id: 3165,
      word: "ngep",
      name: "ngep (v.) override"
   }, 
   {
      id: 3166,
      word: "ngep",
      name: "ngep (v.) take/have priority"
   }, 
   {
      id: 3167,
      word: "ngep'oS",
      name: "ngep'oS (n.) stairs, stairway (except at ship door) (regional)"
   }, 
   {
      id: 3168,
      word: "ngeq",
      name: "ngeq (v.) store, hoard, cache"
   }, 
   {
      id: 3169,
      word: "ngeqwI'",
      name: "ngeqwI' (n.) capacitor"
   }, 
   {
      id: 3170,
      word: "nger",
      name: "nger (n.) theory"
   }, 
   {
      id: 3171,
      word: "ngetlh",
      name: "ngetlh (v.) diffract"
   }, 
   {
      id: 3172,
      word: "ngev",
      name: "ngev (v.) sell"
   }, 
   {
      id: 3173,
      word: "ngo'",
      name: "ngo' (v.) be old (not new)"
   }, 
   {
      id: 3174,
      word: "ngoD",
      name: "ngoD (n.) fact"
   }, 
   {
      id: 3175,
      word: "ngoH",
      name: "ngoH (v.) paint using fingers"
   }, 
   {
      id: 3176,
      word: "ngoH",
      name: "ngoH (v.) smear"
   }, 
   {
      id: 3177,
      word: "ngoQ",
      name: "ngoQ (n.) goal, purpose"
   }, 
   {
      id: 3178,
      word: "ngoS",
      name: "ngoS (v.) dissolve"
   }, 
   {
      id: 3179,
      word: "ngob'at",
      name: "ngob'at (n.) breast"
   }, 
   {
      id: 3180,
      word: "ngoch",
      name: "ngoch (n.) policy"
   }, 
   {
      id: 3181,
      word: "ngochjuH",
      name: "ngochjuH (n.) quark (particle)"
   }, 
   {
      id: 3182,
      word: "ngogh",
      name: "ngogh (n.) block, brick, lump"
   }, 
   {
      id: 3183,
      word: "ngogh mutlhwI'",
      name: "ngogh mutlhwI' (n.) bricklayer"
   }, 
   {
      id: 3184,
      word: "ngogh tun",
      name: "ngogh tun (n.) pillow"
   }, 
   {
      id: 3185,
      word: "ngoj",
      name: "ngoj (v.) be restless"
   }, 
   {
      id: 3186,
      word: "ngol",
      name: "ngol (v.) move bat'leth from horizontal to vertical orientation"
   }, 
   {
      id: 3187,
      word: "ngolpel",
      name: "ngolpel (n.) sit-up"
   }, 
   {
      id: 3188,
      word: "ngom",
      name: "ngom (v.) be geeky"
   }, 
   {
      id: 3189,
      word: "ngomwI'",
      name: "ngomwI' (n.) geek"
   }, 
   {
      id: 3190,
      word: "ngon",
      name: "ngon (v.) bubble"
   }, 
   {
      id: 3191,
      word: "ngonDer",
      name: "ngonDer (n.) nostalgia"
   }, 
   {
      id: 3192,
      word: "ngong",
      name: "ngong (n.) experiment"
   }, 
   {
      id: 3193,
      word: "ngong",
      name: "ngong (v.) experiment"
   }, 
   {
      id: 3194,
      word: "ngop",
      name: "ngop (n.) plates (for eating)"
   }, 
   {
      id: 3195,
      word: "ngoq",
      name: "ngoq (n.) code"
   }, 
   {
      id: 3196,
      word: "ngor",
      name: "ngor (v.) cheat"
   }, 
   {
      id: 3197,
      word: "ngotlh",
      name: "ngotlh (v.) be fanatical"
   }, 
   {
      id: 3198,
      word: "ngotrI'",
      name: "ngotrI' (n.) latitude"
   }, 
   {
      id: 3199,
      word: "ngotrI'tal",
      name: "ngotrI'tal (n.) parallel"
   }, 
   {
      id: 3200,
      word: "ngov",
      name: "ngov (v.) slither, wriggle, squirm, writhe"
   }, 
   {
      id: 3201,
      word: "ngoy'",
      name: "ngoy' (v.) be responsible"
   }, 
   {
      id: 3202,
      word: "ngu'",
      name: "ngu' (v.) identify"
   }, 
   {
      id: 3203,
      word: "ngu'lIj",
      name: "ngu'lIj (n.) soot, grime"
   }, 
   {
      id: 3204,
      word: "nguD",
      name: "nguD (v.) be glued to"
   }, 
   {
      id: 3205,
      word: "nguDwI'",
      name: "nguDwI' (n.) glue"
   }, 
   {
      id: 3206,
      word: "nguH",
      name: "nguH (v.) testify"
   }, 
   {
      id: 3207,
      word: "nguHwI'",
      name: "nguHwI' (n.) witness"
   }, 
   {
      id: 3208,
      word: "nguSDI'",
      name: "nguSDI' (n.) motor"
   }, 
   {
      id: 3209,
      word: "ngub",
      name: "ngub (v.) migrate, immigrate, emigrate"
   }, 
   {
      id: 3210,
      word: "ngugh",
      name: "ngugh (adverb) then, at that time"
   }, 
   {
      id: 3211,
      word: "ngujlep",
      name: "ngujlep (n.) mouthpiece (of a wind instrument)"
   }, 
   {
      id: 3212,
      word: "ngun",
      name: "ngun (v.) perch"
   }, 
   {
      id: 3213,
      word: "ngup",
      name: "ngup (n.) authority, power, one in authority or in charge (slang)"
   }, 
   {
      id: 3214,
      word: "ngup",
      name: "ngup (n.) cape (clothing)"
   }, 
   {
      id: 3215,
      word: "nguq",
      name: "nguq (v.) be arrogant, be haughty, be conceited"
   }, 
   {
      id: 3216,
      word: "ngur",
      name: "ngur (v.) be autistic/aspie"
   }, 
   {
      id: 3217,
      word: "ngutlh",
      name: "ngutlh (n.) letter, written character"
   }, 
   {
      id: 3218,
      word: "ngutlh nagh",
      name: "ngutlh nagh (n.) die/dice with letters"
   }, 
   {
      id: 3219,
      word: "ngutlhmey qa'",
      name: "ngutlhmey qa' (v.) transliterate"
   }, 
   {
      id: 3220,
      word: "nguv",
      name: "nguv (v.) be dyed, be stained, be tinted"
   }, 
   {
      id: 3221,
      word: "nguvmoH",
      name: "nguvmoH (v.) dye, stain, tint"
   }, 
   {
      id: 3222,
      word: "nguy",
      name: "nguy (v.) scoff"
   }, 
   {
      id: 3223,
      word: "no'",
      name: "no' (n.) ancestors"
   }, 
   {
      id: 3224,
      word: "no' DIr",
      name: "no' DIr (n.) ancestor hanging (decoration, not ritual)"
   }, 
   {
      id: 3225,
      word: "no' DIr",
      name: "no' DIr (n.) ancestor hanging (wall ornament)"
   }, 
   {
      id: 3226,
      word: "no' Hol",
      name: "no' Hol (n.) ancient language"
   }, 
   {
      id: 3227,
      word: "no''och",
      name: "no''och (n.) forehead (regional)"
   }, 
   {
      id: 3228,
      word: "no'QeD",
      name: "no'QeD (n.) genealogy"
   }, 
   {
      id: 3229,
      word: "no'laS pa'",
      name: "no'laS pa' (n.) sitting room, lounge, parlour"
   }, 
   {
      id: 3230,
      word: "no'negh",
      name: "no'negh (n.) sulfur (element)"
   }, 
   {
      id: 3231,
      word: "noD",
      name: "noD (v.) retaliate"
   }, 
   {
      id: 3232,
      word: "noDwI'",
      name: "noDwI' (n.) avenger"
   }, 
   {
      id: 3233,
      word: "noH",
      name: "noH (v.) judge, estimate"
   }, 
   {
      id: 3234,
      word: "noH",
      name: "noH (n.) war (an individual war)"
   }, 
   {
      id: 3235,
      word: "noQ",
      name: "noQ (v.) be organic"
   }, 
   {
      id: 3236,
      word: "noS",
      name: "noS (v.) eat in small mouthfuls, nibble"
   }, 
   {
      id: 3237,
      word: "noSvagh",
      name: "noSvagh (n.) deodorant"
   }, 
   {
      id: 3238,
      word: "nob",
      name: "nob (n.) gift"
   }, 
   {
      id: 3239,
      word: "nob",
      name: "nob (v.) give"
   }, 
   {
      id: 3240,
      word: "nobHa'",
      name: "nobHa' (v.) give back, return"
   }, 
   {
      id: 3241,
      word: "nobmeD",
      name: "nobmeD (n.) skeleton"
   }, 
   {
      id: 3242,
      word: "noch",
      name: "noch (n.) sensor"
   }, 
   {
      id: 3243,
      word: "nochmIt",
      name: "nochmIt (n.) spin (quantum physics)"
   }, 
   {
      id: 3244,
      word: "nogh",
      name: "nogh (v.) writhe"
   }, 
   {
      id: 3245,
      word: "noj",
      name: "noj (v.) lend"
   }, 
   {
      id: 3246,
      word: "nol",
      name: "nol (n.) funeral"
   }, 
   {
      id: 3247,
      word: "nom",
      name: "nom (adverb) fast, quickly"
   }, 
   {
      id: 3248,
      word: "nompuq",
      name: "nompuq (n.) authority, evidence, attestation, reference, citation"
   }, 
   {
      id: 3249,
      word: "non",
      name: "non (v.) be rotten"
   }, 
   {
      id: 3250,
      word: "nong",
      name: "nong (v.) be passionate"
   }, 
   {
      id: 3251,
      word: "nop",
      name: "nop (v.) omit, except"
   }, 
   {
      id: 3252,
      word: "noq",
      name: "noq (n.) nipple"
   }, 
   {
      id: 3253,
      word: "noregh",
      name: "noregh (n.) Norway"
   }, 
   {
      id: 3254,
      word: "norgh",
      name: "norgh (n.) shark-like sea carnivore, norg"
   }, 
   {
      id: 3255,
      word: "nortlham",
      name: "nortlham (n.) descendant"
   }, 
   {
      id: 3256,
      word: "not",
      name: "not (adverb) never"
   }, 
   {
      id: 3257,
      word: "notlh",
      name: "notlh (v.) be obsolete"
   }, 
   {
      id: 3258,
      word: "notqa'",
      name: "notqa' (n.) a large, black bird"
   }, 
   {
      id: 3259,
      word: "notron",
      name: "notron (n.) curtain, drape"
   }, 
   {
      id: 3260,
      word: "nov",
      name: "nov (n.) alien, outsider, foreigner"
   }, 
   {
      id: 3261,
      word: "nov",
      name: "nov (v.) be foreign, be alien"
   }, 
   {
      id: 3262,
      word: "noy",
      name: "noy (v.) be famous, be well known"
   }, 
   {
      id: 3263,
      word: "nu",
      name: "nu (vp) he/she/it/they-us"
   }, 
   {
      id: 3264,
      word: "nu'",
      name: "nu' (v.) be particularly small"
   }, 
   {
      id: 3265,
      word: "nu'Qan",
      name: "nu'Qan (n.) alcove"
   }, 
   {
      id: 3266,
      word: "nu'SIylan",
      name: "nu'SIylan (n.) New Zealand"
   }, 
   {
      id: 3267,
      word: "nuD",
      name: "nuD (v.) examine"
   }, 
   {
      id: 3268,
      word: "nuH",
      name: "nuH (n.) possibility"
   }, 
   {
      id: 3269,
      word: "nuH",
      name: "nuH (n.) weapon"
   }, 
   {
      id: 3270,
      word: "nuH bey'",
      name: "nuH bey' (n.) Pride of Weapons"
   }, 
   {
      id: 3271,
      word: "nuHHom",
      name: "nuHHom (n.) small arms"
   }, 
   {
      id: 3272,
      word: "nuHmey",
      name: "nuHmey (n.) arsenal"
   }, 
   {
      id: 3273,
      word: "nuHpIn",
      name: "nuHpIn (n.) weapons officer"
   }, 
   {
      id: 3274,
      word: "nuQ",
      name: "nuQ (v.) annoy, bother"
   }, 
   {
      id: 3275,
      word: "nuS",
      name: "nuS (v.) ridicule"
   }, 
   {
      id: 3276,
      word: "nub",
      name: "nub (v.) be suspect"
   }, 
   {
      id: 3277,
      word: "nubwI'",
      name: "nubwI' (n.) predecessor"
   }, 
   {
      id: 3278,
      word: "nuch",
      name: "nuch (n.) coward"
   }, 
   {
      id: 3279,
      word: "nugh",
      name: "nugh (n.) society"
   }, 
   {
      id: 3280,
      word: "nugh",
      name: "nugh (n.) society; group of people with shared culture"
   }, 
   {
      id: 3281,
      word: "nughI'",
      name: "nughI' (v.) give (someone) a noogie"
   }, 
   {
      id: 3282,
      word: "nughI'",
      name: "nughI' (v.) twist knuckle into someone's head"
   }, 
   {
      id: 3283,
      word: "nuj",
      name: "nuj (n.) mouth"
   }, 
   {
      id: 3284,
      word: "nuj 'In",
      name: "nuj 'In (n.) the practice of producing percussive sounds with the mouth, beatboxing"
   }, 
   {
      id: 3285,
      word: "nuj 'In chu'",
      name: "nuj 'In chu' (v.) beatbox"
   }, 
   {
      id: 3286,
      word: "nuj yaj",
      name: "nuj yaj (v.) read lips"
   }, 
   {
      id: 3287,
      word: "nulqIm",
      name: "nulqIm (n.) media"
   }, 
   {
      id: 3288,
      word: "num",
      name: "num (v.) promote"
   }, 
   {
      id: 3289,
      word: "nung",
      name: "nung (v.) precede"
   }, 
   {
      id: 3290,
      word: "nungmaH",
      name: "nungmaH (n.) hybrid"
   }, 
   {
      id: 3291,
      word: "nup",
      name: "nup (v.) decrease"
   }, 
   {
      id: 3292,
      word: "nuq",
      name: "nuq (question) what?"
   }, 
   {
      id: 3293,
      word: "nuqDaq",
      name: "nuqDaq (question) where?"
   }, 
   {
      id: 3294,
      word: "nuqHm",
      name: "nuqHm (p.n.) Robert E. Newcombe"
   }, 
   {
      id: 3295,
      word: "nuqjatlh",
      name: "nuqjatlh (exclamation) what did you say? huh? what?"
   }, 
   {
      id: 3296,
      word: "nuqneH",
      name: "nuqneH (exclamation) what do you want? (greeting)"
   }, 
   {
      id: 3297,
      word: "nur",
      name: "nur (n.) dignity"
   }, 
   {
      id: 3298,
      word: "nural",
      name: "nural (n.) Neural"
   }, 
   {
      id: 3299,
      word: "nuralngan",
      name: "nuralngan (n.) Neuralese"
   }, 
   {
      id: 3300,
      word: "nurgh",
      name: "nurgh (v.) be awkward (feeling, situation, etc)"
   }, 
   {
      id: 3301,
      word: "nutye'",
      name: "nutye' (n.) olive tree"
   }, 
   {
      id: 3302,
      word: "nuv",
      name: "nuv (n.) person (humanoid)"
   }, 
   {
      id: 3303,
      word: "nuyorgh",
      name: "nuyorgh (n.) New York"
   }, 
   {
      id: 3304,
      word: "oy",
      name: "oy (ns1) endearment"
   }, 
   {
      id: 3305,
      word: "pI",
      name: "pI (vp) we-you"
   }, 
   {
      id: 3306,
      word: "pI'",
      name: "pI' (v.) be fat"
   }, 
   {
      id: 3307,
      word: "pID",
      name: "pID (v.) coat (food) with herbed mixture"
   }, 
   {
      id: 3308,
      word: "pID",
      name: "pID (v.) slang for laS (ink up, put paint on a brush)"
   }, 
   {
      id: 3309,
      word: "pIH",
      name: "pIH (v.) be suspicious"
   }, 
   {
      id: 3310,
      word: "pIH",
      name: "pIH (v.) expect"
   }, 
   {
      id: 3311,
      word: "pIQ",
      name: "pIQ (v.) be direct"
   }, 
   {
      id: 3312,
      word: "pIQHa'",
      name: "pIQHa' (v.) be indirect, be roundabout, be devious"
   }, 
   {
      id: 3313,
      word: "pIch",
      name: "pIch (v.) blame"
   }, 
   {
      id: 3314,
      word: "pIch",
      name: "pIch (n.) fault, blame"
   }, 
   {
      id: 3315,
      word: "pIchSIv",
      name: "pIchSIv (n.) vinegar"
   }, 
   {
      id: 3316,
      word: "pIgh",
      name: "pIgh (n.) ruins"
   }, 
   {
      id: 3317,
      word: "pIj",
      name: "pIj (adverb) often, frequently"
   }, 
   {
      id: 3318,
      word: "pIjHa'",
      name: "pIjHa' (adverb) seldom, infrequently"
   }, 
   {
      id: 3319,
      word: "pIl",
      name: "pIl (v.) be stimulated, be inspired, be motivated"
   }, 
   {
      id: 3320,
      word: "pIlHa'",
      name: "pIlHa' (v.) be unmotivated"
   }, 
   {
      id: 3321,
      word: "pIlIpIynaS",
      name: "pIlIpIynaS (n.) the Philippines"
   }, 
   {
      id: 3322,
      word: "pIlam naH",
      name: "pIlam naH (n.) plum"
   }, 
   {
      id: 3323,
      word: "pIlghIm",
      name: "pIlghIm (n.) mast, flagpole"
   }, 
   {
      id: 3324,
      word: "pIlmoH",
      name: "pIlmoH (v.) stimulate, inspire, motivate"
   }, 
   {
      id: 3325,
      word: "pIm",
      name: "pIm (v.) be different"
   }, 
   {
      id: 3326,
      word: "pIn",
      name: "pIn (n.) boss, expert, authority (slang)"
   }, 
   {
      id: 3327,
      word: "pIn tlhoy'",
      name: "pIn tlhoy' (n.) territorial wall"
   }, 
   {
      id: 3328,
      word: "pIn'a'",
      name: "pIn'a' (n.) master"
   }, 
   {
      id: 3329,
      word: "pIp",
      name: "pIp (n.) spine"
   }, 
   {
      id: 3330,
      word: "pIpyuS",
      name: "pIpyuS (n.) pipius"
   }, 
   {
      id: 3331,
      word: "pIq",
      name: "pIq (n.) time period from now (future)"
   }, 
   {
      id: 3332,
      word: "pIqaD",
      name: "pIqaD (n.) Klingon writing system"
   }, 
   {
      id: 3333,
      word: "pIqcho'",
      name: "pIqcho' (n.) athlete"
   }, 
   {
      id: 3334,
      word: "pIqcho' chojmoHwI'",
      name: "pIqcho' chojmoHwI' (n.) trainer (a fitness trainer)"
   }, 
   {
      id: 3335,
      word: "pIqcho' waq",
      name: "pIqcho' waq (n.) sneaker, tennis shoe, trainer UK)"
   }, 
   {
      id: 3336,
      word: "pIr",
      name: "pIr (v.) be fertile"
   }, 
   {
      id: 3337,
      word: "pIra'Ha",
      name: "pIra'Ha (n.) Prague"
   }, 
   {
      id: 3338,
      word: "pIraHa'",
      name: "pIraHa' (n.) Praha"
   }, 
   {
      id: 3339,
      word: "pIraqSIS",
      name: "pIraqSIS (n.) Praxis"
   }, 
   {
      id: 3340,
      word: "pIrmuS",
      name: "pIrmuS (n.) bottom (exterior)"
   }, 
   {
      id: 3341,
      word: "pItSa' chab",
      name: "pItSa' chab (n.) pizza"
   }, 
   {
      id: 3342,
      word: "pItlh",
      name: "pItlh (exclamation) done"
   }, 
   {
      id: 3343,
      word: "pItlhbergh",
      name: "pItlhbergh (n.) Pittsburgh (US)"
   }, 
   {
      id: 3344,
      word: "pIv",
      name: "pIv (v.) be healthy"
   }, 
   {
      id: 3345,
      word: "pIvchem",
      name: "pIvchem (n.) warp field"
   }, 
   {
      id: 3346,
      word: "pIvghor",
      name: "pIvghor (n.) warp drive"
   }, 
   {
      id: 3347,
      word: "pIvlob",
      name: "pIvlob (n.) warp factor"
   }, 
   {
      id: 3348,
      word: "pIvyoch",
      name: "pIvyoch (n.) a rather pungent Klingon beverage"
   }, 
   {
      id: 3349,
      word: "pIw",
      name: "pIw (n.) odor, smell"
   }, 
   {
      id: 3350,
      word: "pIw rebmugh",
      name: "pIw rebmugh (n.) incense"
   }, 
   {
      id: 3351,
      word: "pIwSIp",
      name: "pIwSIp (n.) ammonia"
   }, 
   {
      id: 3352,
      word: "pa'",
      name: "pa' (vs9) before"
   }, 
   {
      id: 3353,
      word: "pa'",
      name: "pa' (n.) room, chamber, enclosed area"
   }, 
   {
      id: 3354,
      word: "pa'",
      name: "pa' (n.) there, over there, thereabouts"
   }, 
   {
      id: 3355,
      word: "pa' beb",
      name: "pa' beb (n.) ceiling of top storey room"
   }, 
   {
      id: 3356,
      word: "pa' beb De'lor",
      name: "pa' beb De'lor (n.) stalactite"
   }, 
   {
      id: 3357,
      word: "pa' reD",
      name: "pa' reD (n.) interior face of exterior wall"
   }, 
   {
      id: 3358,
      word: "pa'jaH",
      name: "pa'jaH (n.) rhyme"
   }, 
   {
      id: 3359,
      word: "pa'logh",
      name: "pa'logh (n.) the past (as a whole)"
   }, 
   {
      id: 3360,
      word: "pa'raghway",
      name: "pa'raghway (n.) Paraguay"
   }, 
   {
      id: 3361,
      word: "pa'vo",
      name: "pa'vo (p.n.) Pahvo (planet)"
   }, 
   {
      id: 3362,
      word: "paH",
      name: "paH (n.) gown, dress"
   }, 
   {
      id: 3363,
      word: "paH bID",
      name: "paH bID (n.) skirt"
   }, 
   {
      id: 3364,
      word: "paQ",
      name: "paQ (v.) meditate, cogitate, reflect"
   }, 
   {
      id: 3365,
      word: "paQDI'norgh",
      name: "paQDI'norgh (n.) teachings"
   }, 
   {
      id: 3366,
      word: "paQjen",
      name: "paQjen (n.) sequin, spangle"
   }, 
   {
      id: 3367,
      word: "paS",
      name: "paS (v.) be late"
   }, 
   {
      id: 3368,
      word: "paSjav",
      name: "paSjav (n.) cinnamon-like Klingon plant"
   }, 
   {
      id: 3369,
      word: "paSlogh",
      name: "paSlogh (n.) socks"
   }, 
   {
      id: 3370,
      word: "paSlogh tuQ DaS",
      name: "paSlogh tuQ DaS (v.) be inside-out"
   }, 
   {
      id: 3371,
      word: "paSrIq",
      name: "paSrIq (n.) fabric used in carpets and rugs"
   }, 
   {
      id: 3372,
      word: "paSta'",
      name: "paSta' (n.) Terran pasta, noodles, spaghetti"
   }, 
   {
      id: 3373,
      word: "pab",
      name: "pab (v.) follow (rules)"
   }, 
   {
      id: 3374,
      word: "pab",
      name: "pab (n.) grammar"
   }, 
   {
      id: 3375,
      word: "pab buv",
      name: "pab buv (n.) part of speech"
   }, 
   {
      id: 3376,
      word: "pabHa'",
      name: "pabHa' (v.) misfollow (rules), follow (rules) wrongly"
   }, 
   {
      id: 3377,
      word: "pabpo'",
      name: "pabpo' (n.) grammarian"
   }, 
   {
      id: 3378,
      word: "pach",
      name: "pach (n.) claw"
   }, 
   {
      id: 3379,
      word: "pagh",
      name: "pagh (conjunction) either/or (sentences)"
   }, 
   {
      id: 3380,
      word: "pagh",
      name: "pagh (p.n.) Eric Andeen"
   }, 
   {
      id: 3381,
      word: "pagh",
      name: "pagh (n.) no one"
   }, 
   {
      id: 3382,
      word: "pagh",
      name: "pagh (n.) none, nothing, no one"
   }, 
   {
      id: 3383,
      word: "pagh",
      name: "pagh (number) zero"
   }, 
   {
      id: 3384,
      word: "paghDIch",
      name: "paghDIch (number) zeroth (about something that has not occurred)"
   }, 
   {
      id: 3385,
      word: "paghlogh",
      name: "paghlogh (adverb) zero times, never (emphatic)"
   }, 
   {
      id: 3386,
      word: "paghur",
      name: "paghur (n.) hermit, recluse"
   }, 
   {
      id: 3387,
      word: "paj",
      name: "paj (v.) resign"
   }, 
   {
      id: 3388,
      word: "pal'ar",
      name: "pal'ar (n.) kin, family member"
   }, 
   {
      id: 3389,
      word: "pan",
      name: "pan (v.) solve"
   }, 
   {
      id: 3390,
      word: "pan",
      name: "pan (v.) spark, emit sparks"
   }, 
   {
      id: 3391,
      word: "panDa'",
      name: "panDa' (n.) panda bear"
   }, 
   {
      id: 3392,
      word: "panama'",
      name: "panama' (n.) Panama"
   }, 
   {
      id: 3393,
      word: "pang",
      name: "pang (v.) pluck (a stringed instrument)"
   }, 
   {
      id: 3394,
      word: "papwanughI'nIy",
      name: "papwanughI'nIy (n.) Papua New Guinea"
   }, 
   {
      id: 3395,
      word: "paq",
      name: "paq (n.) book"
   }, 
   {
      id: 3396,
      word: "paq Duj",
      name: "paq Duj (n.) bookmobile"
   }, 
   {
      id: 3397,
      word: "paq nojwI'",
      name: "paq nojwI' (n.) librarian"
   }, 
   {
      id: 3398,
      word: "paq nojwI' qach",
      name: "paq nojwI' qach (n.) library (building)"
   }, 
   {
      id: 3399,
      word: "paq nojwI' tum",
      name: "paq nojwI' tum (n.) library (public)"
   }, 
   {
      id: 3400,
      word: "paqIStan",
      name: "paqIStan (n.) Pakistan"
   }, 
   {
      id: 3401,
      word: "par",
      name: "par (v.) dislike"
   }, 
   {
      id: 3402,
      word: "parHa'",
      name: "parHa' (v.) like"
   }, 
   {
      id: 3403,
      word: "parIy",
      name: "parIy (p.n.) Paris"
   }, 
   {
      id: 3404,
      word: "parbIng",
      name: "parbIng (n.) a mid-sized bird with particularly garish coloring"
   }, 
   {
      id: 3405,
      word: "parchech",
      name: "parchech (n.) gypsum"
   }, 
   {
      id: 3406,
      word: "pargh",
      name: "pargh (v.) be synthetic, artificial"
   }, 
   {
      id: 3407,
      word: "parmaq",
      name: "parmaq (n.) love, romance"
   }, 
   {
      id: 3408,
      word: "parmaq qep",
      name: "parmaq qep (n.) date"
   }, 
   {
      id: 3409,
      word: "parmaqqay",
      name: "parmaqqay (n.) romantic companion, romantic partner"
   }, 
   {
      id: 3410,
      word: "pat",
      name: "pat (n.) system"
   }, 
   {
      id: 3411,
      word: "patat 'oQqar",
      name: "patat 'oQqar (n.) potato, potatoes"
   }, 
   {
      id: 3412,
      word: "patlh",
      name: "patlh (v.) be ranked, have a status, be graded, be sorted, have a rank of"
   }, 
   {
      id: 3413,
      word: "patlh",
      name: "patlh (n.) level, layer, standing"
   }, 
   {
      id: 3414,
      word: "patlh",
      name: "patlh (n.) order (as in alphabetical order)"
   }, 
   {
      id: 3415,
      word: "patlh",
      name: "patlh (n.) rank (military, governmental)"
   }, 
   {
      id: 3416,
      word: "patlhmoH",
      name: "patlhmoH (v.) rank, assign status, sort, compare"
   }, 
   {
      id: 3417,
      word: "patmor",
      name: "patmor (n.) emerald"
   }, 
   {
      id: 3418,
      word: "pav",
      name: "pav (v.) be urgent"
   }, 
   {
      id: 3419,
      word: "paw",
      name: "paw (v.) arrive"
   }, 
   {
      id: 3420,
      word: "paw'",
      name: "paw' (v.) butt heads (slang)"
   }, 
   {
      id: 3421,
      word: "paw'",
      name: "paw' (v.) collide"
   }, 
   {
      id: 3422,
      word: "paw'aD",
      name: "paw'aD (n.) vein"
   }, 
   {
      id: 3423,
      word: "pay",
      name: "pay (v.) regret"
   }, 
   {
      id: 3424,
      word: "pay'",
      name: "pay' (adverb) suddenly"
   }, 
   {
      id: 3425,
      word: "pay'an",
      name: "pay'an (n.) particle"
   }, 
   {
      id: 3426,
      word: "pay'rIn",
      name: "pay'rIn (n.) excavation, dug-up ruins"
   }, 
   {
      id: 3427,
      word: "pay'tlhan ghargh",
      name: "pay'tlhan ghargh (n.) python"
   }, 
   {
      id: 3428,
      word: "pe",
      name: "pe (vp) imp: you (pl)-"
   }, 
   {
      id: 3429,
      word: "pe'",
      name: "pe' (v.) cut"
   }, 
   {
      id: 3430,
      word: "pe''egh",
      name: "pe''egh (v.) keep score"
   }, 
   {
      id: 3431,
      word: "pe''egh",
      name: "pe''egh (v.) keep score (lit. <cut oneself>, usually on the face)"
   }, 
   {
      id: 3432,
      word: "pe'bIl",
      name: "pe'bIl (n.) lightning"
   }, 
   {
      id: 3433,
      word: "pe'meH 'echlet",
      name: "pe'meH 'echlet (n.) cutting board"
   }, 
   {
      id: 3434,
      word: "pe'meH taj",
      name: "pe'meH taj (n.) cutting knife"
   }, 
   {
      id: 3435,
      word: "pe'ru'",
      name: "pe'ru' (n.) Peru"
   }, 
   {
      id: 3436,
      word: "pe'vIl",
      name: "pe'vIl (adverb) forcefully, by force"
   }, 
   {
      id: 3437,
      word: "pe'vIlHa'",
      name: "pe'vIlHa' (adverb) gently"
   }, 
   {
      id: 3438,
      word: "peD",
      name: "peD (v.) snow, fall slowly (like snow)"
   }, 
   {
      id: 3439,
      word: "peHghep",
      name: "peHghep (n.) Age of Inclusion"
   }, 
   {
      id: 3440,
      word: "peHruS",
      name: "peHruS (p.n.) Daniel Morse"
   }, 
   {
      id: 3441,
      word: "peQ",
      name: "peQ (n.) magnetism"
   }, 
   {
      id: 3442,
      word: "peQ chem",
      name: "peQ chem (n.) magnetic field"
   }, 
   {
      id: 3443,
      word: "peQnagh",
      name: "peQnagh (n.) magnet"
   }, 
   {
      id: 3444,
      word: "peS",
      name: "peS (v.) supply, furnish, provide, dispense"
   }, 
   {
      id: 3445,
      word: "peSHIr",
      name: "peSHIr (p.n.) Jarno Peschier"
   }, 
   {
      id: 3446,
      word: "peb'ot",
      name: "peb'ot (n.) type of fruit"
   }, 
   {
      id: 3447,
      word: "pegh",
      name: "pegh (v.) keep something secret, be secret"
   }, 
   {
      id: 3448,
      word: "pegh",
      name: "pegh (n.) secret"
   }, 
   {
      id: 3449,
      word: "peghmey vIttlhegh",
      name: "peghmey vIttlhegh (n.) secrecy proverb"
   }, 
   {
      id: 3450,
      word: "pej",
      name: "pej (v.) demolish"
   }, 
   {
      id: 3451,
      word: "pel'aQ",
      name: "pel'aQ (n.) coffin"
   }, 
   {
      id: 3452,
      word: "pel'aQ",
      name: "pel'aQ (n.) shell (of an egg)"
   }, 
   {
      id: 3453,
      word: "pem",
      name: "pem (n.) daytime"
   }, 
   {
      id: 3454,
      word: "pemjep",
      name: "pemjep (n.) midday"
   }, 
   {
      id: 3455,
      word: "penSIlvenya'",
      name: "penSIlvenya' (n.) Pennsylvania"
   }, 
   {
      id: 3456,
      word: "peng",
      name: "peng (n.) torpedo, missile"
   }, 
   {
      id: 3457,
      word: "pep",
      name: "pep (v.) raise"
   }, 
   {
      id: 3458,
      word: "pep'en",
      name: "pep'en (n.) current (in air or water)"
   }, 
   {
      id: 3459,
      word: "peq",
      name: "peq (v.) slaughter (connotes intention, targeting specific victims)"
   }, 
   {
      id: 3460,
      word: "per",
      name: "per (n.) label"
   }, 
   {
      id: 3461,
      word: "per",
      name: "per (v.) label"
   }, 
   {
      id: 3462,
      word: "per naH",
      name: "per naH (n.) pear"
   }, 
   {
      id: 3463,
      word: "per naHmey",
      name: "per naHmey (n.) pears"
   }, 
   {
      id: 3464,
      word: "per yuD",
      name: "per yuD (n.) code name"
   }, 
   {
      id: 3465,
      word: "perletlh",
      name: "perletlh (n.) stump"
   }, 
   {
      id: 3466,
      word: "pet",
      name: "pet (v.) be welded (together)"
   }, 
   {
      id: 3467,
      word: "petaQ",
      name: "petaQ (exclamation) (curse) epithet, insult"
   }, 
   {
      id: 3468,
      word: "petben",
      name: "petben (n.) thump, thud"
   }, 
   {
      id: 3469,
      word: "petqaD",
      name: "petqaD (n.) a medical device for mending bones"
   }, 
   {
      id: 3470,
      word: "pey",
      name: "pey (n.) acid"
   }, 
   {
      id: 3471,
      word: "piece of candy",
      name: "piece of candy (n.) Su'ghar Sawqe'"
   }, 
   {
      id: 3472,
      word: "po",
      name: "po (n.) morning"
   }, 
   {
      id: 3473,
      word: "po",
      name: "po (n.) Tibet"
   }, 
   {
      id: 3474,
      word: "po'",
      name: "po' (v.) be expert, be skilled"
   }, 
   {
      id: 3475,
      word: "po'lISqa'",
      name: "po'lISqa' (n.) Poland"
   }, 
   {
      id: 3476,
      word: "po'lIgh",
      name: "po'lIgh (n.) sauce"
   }, 
   {
      id: 3477,
      word: "po'lo yIvbeH",
      name: "po'lo yIvbeH (n.) polo shirt"
   }, 
   {
      id: 3478,
      word: "po'oH",
      name: "po'oH (n.) corner of the street, corner of a piece of paper"
   }, 
   {
      id: 3479,
      word: "poD",
      name: "poD (v.) be clipped"
   }, 
   {
      id: 3480,
      word: "poDmoH",
      name: "poDmoH (v.) clip"
   }, 
   {
      id: 3481,
      word: "poH",
      name: "poH (n.) period of time"
   }, 
   {
      id: 3482,
      word: "poH",
      name: "poH (v.) time"
   }, 
   {
      id: 3483,
      word: "poHSer",
      name: "poHSer (n.) compost"
   }, 
   {
      id: 3484,
      word: "poQ",
      name: "poQ (v.) demand, require"
   }, 
   {
      id: 3485,
      word: "poS",
      name: "poS (v.) be open, be opened"
   }, 
   {
      id: 3486,
      word: "poS",
      name: "poS (n.) left (side)"
   }, 
   {
      id: 3487,
      word: "poSmoH",
      name: "poSmoH (v.) open"
   }, 
   {
      id: 3488,
      word: "pob",
      name: "pob (n.) hair (on body), animal hair/fur"
   }, 
   {
      id: 3489,
      word: "pob yIvbeH",
      name: "pob yIvbeH (n.) sweater"
   }, 
   {
      id: 3490,
      word: "poch",
      name: "poch (v.) plant"
   }, 
   {
      id: 3491,
      word: "pogh",
      name: "pogh (n.) glove"
   }, 
   {
      id: 3492,
      word: "poj",
      name: "poj (n.) analysis"
   }, 
   {
      id: 3493,
      word: "poj",
      name: "poj (v.) analyze"
   }, 
   {
      id: 3494,
      word: "pol",
      name: "pol (v.) keep, save"
   }, 
   {
      id: 3495,
      word: "polHa'",
      name: "polHa' (v.) discard"
   }, 
   {
      id: 3496,
      word: "polonyuS",
      name: "polonyuS (p.n.) Polonius"
   }, 
   {
      id: 3497,
      word: "pom",
      name: "pom (n.) dysentery"
   }, 
   {
      id: 3498,
      word: "pomtut",
      name: "pomtut (n.) battering ram"
   }, 
   {
      id: 3499,
      word: "pon",
      name: "pon (v.) persuade, convince"
   }, 
   {
      id: 3500,
      word: "pong",
      name: "pong (n.) name"
   }, 
   {
      id: 3501,
      word: "pong",
      name: "pong (v.) name, call"
   }, 
   {
      id: 3502,
      word: "pop",
      name: "pop (n.) reward"
   }, 
   {
      id: 3503,
      word: "popSop",
      name: "popSop (n.) sodium"
   }, 
   {
      id: 3504,
      word: "poq",
      name: "poq (n.) indigestion"
   }, 
   {
      id: 3505,
      word: "por",
      name: "por (n.) leaf (of a plant)"
   }, 
   {
      id: 3506,
      word: "por Ho'Du'",
      name: "por Ho'Du' (n.) rake for leaves"
   }, 
   {
      id: 3507,
      word: "porgh",
      name: "porgh (n.) body"
   }, 
   {
      id: 3508,
      word: "porghQeD",
      name: "porghQeD (n.) physiology"
   }, 
   {
      id: 3509,
      word: "portughal",
      name: "portughal (n.) Portugal"
   }, 
   {
      id: 3510,
      word: "potlh",
      name: "potlh (v.) be important"
   }, 
   {
      id: 3511,
      word: "potlh",
      name: "potlh (n.) something important"
   }, 
   {
      id: 3512,
      word: "pov",
      name: "pov (n.) afternoon"
   }, 
   {
      id: 3513,
      word: "pov",
      name: "pov (v.) be excellent"
   }, 
   {
      id: 3514,
      word: "povjaj",
      name: "povjaj (n.) Tuesday"
   }, 
   {
      id: 3515,
      word: "poy'",
      name: "poy' (v.) confiscate"
   }, 
   {
      id: 3516,
      word: "poymar",
      name: "poymar (n.) mystery"
   }, 
   {
      id: 3517,
      word: "pu'",
      name: "pu' (n.) horn"
   }, 
   {
      id: 3518,
      word: "pu'",
      name: "pu' (vs7) perfective (aspect marker)"
   }, 
   {
      id: 3519,
      word: "pu'",
      name: "pu' (n.) phaser, disruptor, energy weapon"
   }, 
   {
      id: 3520,
      word: "pu'",
      name: "pu' (ns2) plural (beings capable of using language)"
   }, 
   {
      id: 3521,
      word: "pu'DaH",
      name: "pu'DaH (n.) phaser banks"
   }, 
   {
      id: 3522,
      word: "pu'HIch",
      name: "pu'HIch (n.) phaser pistol"
   }, 
   {
      id: 3523,
      word: "pu'beH",
      name: "pu'beH (n.) phaser rifle"
   }, 
   {
      id: 3524,
      word: "pu'beq",
      name: "pu'beq (n.) phaser crew"
   }, 
   {
      id: 3525,
      word: "pu'jIn",
      name: "pu'jIn (n.) map, plan (as in a building plan)"
   }, 
   {
      id: 3526,
      word: "pu'porgh 'oQqar",
      name: "pu'porgh 'oQqar (n.) ginger"
   }, 
   {
      id: 3527,
      word: "pu'veng",
      name: "pu'veng (n.) twig, cat's whiskers, insect antennae"
   }, 
   {
      id: 3528,
      word: "puH",
      name: "puH (n.) land"
   }, 
   {
      id: 3529,
      word: "puH Duj",
      name: "puH Duj (n.) car, automobile, land vessel"
   }, 
   {
      id: 3530,
      word: "puH beQ",
      name: "puH beQ (n.) plains, flatlands"
   }, 
   {
      id: 3531,
      word: "puH nIl",
      name: "puH nIl (n.) grassland, steppe"
   }, 
   {
      id: 3532,
      word: "puH taD",
      name: "puH taD (n.) tundra"
   }, 
   {
      id: 3533,
      word: "puH yIQ",
      name: "puH yIQ (n.) swamp, wetlands"
   }, 
   {
      id: 3534,
      word: "puHley'",
      name: "puHley' (n.) cape, point"
   }, 
   {
      id: 3535,
      word: "puQ",
      name: "puQ (v.) be fed up"
   }, 
   {
      id: 3536,
      word: "puS",
      name: "puS (v.) be few, be several, be a handful"
   }, 
   {
      id: 3537,
      word: "puS",
      name: "puS (v.) sight (with gunsight)"
   }, 
   {
      id: 3538,
      word: "pub",
      name: "pub (v.) boil"
   }, 
   {
      id: 3539,
      word: "puboS",
      name: "puboS (n.) scapula"
   }, 
   {
      id: 3540,
      word: "puch",
      name: "puch (n.) toilet"
   }, 
   {
      id: 3541,
      word: "puchpa'",
      name: "puchpa' (n.) washroom"
   }, 
   {
      id: 3542,
      word: "pugh",
      name: "pugh (n.) dregs"
   }, 
   {
      id: 3543,
      word: "puj",
      name: "puj (v.) be weak"
   }, 
   {
      id: 3544,
      word: "pujmoH",
      name: "pujmoH (v.) weaken"
   }, 
   {
      id: 3545,
      word: "pujwI'",
      name: "pujwI' (n.) weakling"
   }, 
   {
      id: 3546,
      word: "pul",
      name: "pul (v.) be ground up"
   }, 
   {
      id: 3547,
      word: "pum",
      name: "pum (n.) accusation"
   }, 
   {
      id: 3548,
      word: "pum",
      name: "pum (v.) accuse"
   }, 
   {
      id: 3549,
      word: "pum",
      name: "pum (v.) fall"
   }, 
   {
      id: 3550,
      word: "pumnuj",
      name: "pumnuj (n.) handcuffs, manacles"
   }, 
   {
      id: 3551,
      word: "pun",
      name: "pun (v.) be low (in pitch)"
   }, 
   {
      id: 3552,
      word: "pung",
      name: "pung (n.) mercy"
   }, 
   {
      id: 3553,
      word: "pup",
      name: "pup (v.) be perfect, be exact"
   }, 
   {
      id: 3554,
      word: "pup",
      name: "pup (v.) kick"
   }, 
   {
      id: 3555,
      word: "pupHa'",
      name: "pupHa' (v.) be approximate"
   }, 
   {
      id: 3556,
      word: "pupqa'",
      name: "pupqa' (v.) bribe (slang)"
   }, 
   {
      id: 3557,
      word: "puq",
      name: "puq (n.) child, offspring"
   }, 
   {
      id: 3558,
      word: "puq Hol",
      name: "puq Hol (n.) baby talk (chilren's language)"
   }, 
   {
      id: 3559,
      word: "puq chonnaQ",
      name: "puq chonnaQ (n.) fork"
   }, 
   {
      id: 3560,
      word: "puq poH",
      name: "puq poH (n.) generation"
   }, 
   {
      id: 3561,
      word: "puqbe'",
      name: "puqbe' (n.) daughter"
   }, 
   {
      id: 3562,
      word: "puqloD",
      name: "puqloD (n.) son"
   }, 
   {
      id: 3563,
      word: "puqnI'",
      name: "puqnI' (n.) grandchild"
   }, 
   {
      id: 3564,
      word: "puqnI'be'",
      name: "puqnI'be' (n.) granddaughter"
   }, 
   {
      id: 3565,
      word: "puqnI'loD",
      name: "puqnI'loD (n.) grandson"
   }, 
   {
      id: 3566,
      word: "pur",
      name: "pur (v.) inhale"
   }, 
   {
      id: 3567,
      word: "puv",
      name: "puv (v.) fly"
   }, 
   {
      id: 3568,
      word: "puy",
      name: "puy (v.) wreck"
   }, 
   {
      id: 3569,
      word: "puyjaq",
      name: "puyjaq (n.) nova"
   }, 
   {
      id: 3570,
      word: "puyjaq'a'",
      name: "puyjaq'a' (n.) super nova"
   }, 
   {
      id: 3571,
      word: "qI'",
      name: "qI' (v.) sign (a treaty)"
   }, 
   {
      id: 3572,
      word: "qID",
      name: "qID (n.) joke"
   }, 
   {
      id: 3573,
      word: "qID",
      name: "qID (v.) joke, make a joke, tell a joke"
   }, 
   {
      id: 3574,
      word: "qIH",
      name: "qIH (v.) meet (for the first time)"
   }, 
   {
      id: 3575,
      word: "qIHne'nogh",
      name: "qIHne'nogh (n.) cholesterol"
   }, 
   {
      id: 3576,
      word: "qIQ",
      name: "qIQ (v.) mutiny"
   }, 
   {
      id: 3577,
      word: "qIS",
      name: "qIS (v.) be libidinous"
   }, 
   {
      id: 3578,
      word: "qIb",
      name: "qIb (n.) galaxy"
   }, 
   {
      id: 3579,
      word: "qIbHeS",
      name: "qIbHeS (n.) galactic rim"
   }, 
   {
      id: 3580,
      word: "qIch",
      name: "qIch (v.) condemn"
   }, 
   {
      id: 3581,
      word: "qIgh",
      name: "qIgh (n.) shortcut"
   }, 
   {
      id: 3582,
      word: "qIj",
      name: "qIj (v.) be black"
   }, 
   {
      id: 3583,
      word: "qIl",
      name: "qIl (v.) cancel"
   }, 
   {
      id: 3584,
      word: "qIm",
      name: "qIm (v.) pay attention, concentrate"
   }, 
   {
      id: 3585,
      word: "qImHa'",
      name: "qImHa' (v.) disregard"
   }, 
   {
      id: 3586,
      word: "qImlaq",
      name: "qImlaq (p.n.) K'mlak"
   }, 
   {
      id: 3587,
      word: "qImroq",
      name: "qImroq (n.) season"
   }, 
   {
      id: 3588,
      word: "qIn",
      name: "qIn (v.) moan, groan"
   }, 
   {
      id: 3589,
      word: "qInut",
      name: "qInut (n.) scythe, sickle, falx"
   }, 
   {
      id: 3590,
      word: "qIp",
      name: "qIp (v.) hit (with hand, fist, implement), knock"
   }, 
   {
      id: 3591,
      word: "qIproS",
      name: "qIproS (n.) Cyprus"
   }, 
   {
      id: 3592,
      word: "qIr'a'",
      name: "qIr'a' (n.) continuum"
   }, 
   {
      id: 3593,
      word: "qIrIbaS",
      name: "qIrIbaS (n.) Kiribati"
   }, 
   {
      id: 3594,
      word: "qIrbI'",
      name: "qIrbI' (n.) hygiene"
   }, 
   {
      id: 3595,
      word: "qIrqoD",
      name: "qIrqoD (n.) a pine-like tree"
   }, 
   {
      id: 3596,
      word: "qIt",
      name: "qIt (n.) a big, fat bird native to Kronos, which is able to fly, but not for a long time"
   }, 
   {
      id: 3597,
      word: "qIt",
      name: "qIt (v.) be possible"
   }, 
   {
      id: 3598,
      word: "qItI'nga'",
      name: "qItI'nga' (n.) K'Tinga class vessel"
   }, 
   {
      id: 3599,
      word: "qIv",
      name: "qIv (n.) knee"
   }, 
   {
      id: 3600,
      word: "qIvo'rIt",
      name: "qIvo'rIt (p.n.) K'Vort class vessel"
   }, 
   {
      id: 3601,
      word: "qIvon",
      name: "qIvon (n.) an unspecified body part"
   }, 
   {
      id: 3602,
      word: "qSeroHS",
      name: "qSeroHS (p.n.) Niall Hosking"
   }, 
   {
      id: 3603,
      word: "qa",
      name: "qa (vp) I-you"
   }, 
   {
      id: 3604,
      word: "qa'",
      name: "qa' (vs3) do again, resume"
   }, 
   {
      id: 3605,
      word: "qa'",
      name: "qa' (v.) replace"
   }, 
   {
      id: 3606,
      word: "qa'",
      name: "qa' (n.) spirit, ghost"
   }, 
   {
      id: 3607,
      word: "qa' QoywI'",
      name: "qa' QoywI' (n.) shaman"
   }, 
   {
      id: 3608,
      word: "qa'lIq Hol",
      name: "qa'lIq Hol (n.) Scottish Gaelic"
   }, 
   {
      id: 3609,
      word: "qa'mInar",
      name: "qa'mInar (p.n.) Kaminar"
   }, 
   {
      id: 3610,
      word: "qa'meH",
      name: "qa'meH (n.) replacement (permanent)"
   }, 
   {
      id: 3611,
      word: "qa'meH vIttlhegh",
      name: "qa'meH vIttlhegh (n.) replacement proverb"
   }, 
   {
      id: 3612,
      word: "qa'mel",
      name: "qa'mel (n.) camel"
   }, 
   {
      id: 3613,
      word: "qa'naDa'",
      name: "qa'naDa' (n.) Canada"
   }, 
   {
      id: 3614,
      word: "qa'nabIS",
      name: "qa'nabIS (n.) cannabis"
   }, 
   {
      id: 3615,
      word: "qa'put",
      name: "qa'put (n.) monkey-like creature"
   }, 
   {
      id: 3616,
      word: "qa'rI'",
      name: "qa'rI' (n.) end (of corridor, tunnel, conduit, Jeffries tube, sewer, road, bridge, long field, etc.)"
   }, 
   {
      id: 3617,
      word: "qa'ramel Su'ghar Sawqe'",
      name: "qa'ramel Su'ghar Sawqe' (n.) caramel candy"
   }, 
   {
      id: 3618,
      word: "qa'rol",
      name: "qa'rol (n.) a really big bird"
   }, 
   {
      id: 3619,
      word: "qa'vIn",
      name: "qa'vIn (n.) coffee, type of beverage"
   }, 
   {
      id: 3620,
      word: "qa'vaQ",
      name: "qa'vaQ (n.) qa'vak (traditional game), weapon training using a hoop and stick"
   }, 
   {
      id: 3621,
      word: "qa'vam",
      name: "qa'vam (n.) Genesis"
   }, 
   {
      id: 3622,
      word: "qaD",
      name: "qaD (v.) challenge, resist, oppose, confront, face"
   }, 
   {
      id: 3623,
      word: "qaD",
      name: "qaD (n.) challenge, test of one's abilities"
   }, 
   {
      id: 3624,
      word: "qaD mIr",
      name: "qaD mIr (n.) tournament"
   }, 
   {
      id: 3625,
      word: "qaDvan",
      name: "qaDvan (n.) probation"
   }, 
   {
      id: 3626,
      word: "qaDvan SIQ",
      name: "qaDvan SIQ (v.) be on probation"
   }, 
   {
      id: 3627,
      word: "qaH",
      name: "qaH (n.) sir"
   }, 
   {
      id: 3628,
      word: "qaS",
      name: "qaS (v.) occur, happen"
   }, 
   {
      id: 3629,
      word: "qab",
      name: "qab (v.) be bad"
   }, 
   {
      id: 3630,
      word: "qab",
      name: "qab (n.) face"
   }, 
   {
      id: 3631,
      word: "qab jech",
      name: "qab jech (n.) mask"
   }, 
   {
      id: 3632,
      word: "qach",
      name: "qach (n.) building, structure"
   }, 
   {
      id: 3633,
      word: "qach DIS",
      name: "qach DIS (n.) basement"
   }, 
   {
      id: 3634,
      word: "qach noy",
      name: "qach noy (n.) landmark (building)"
   }, 
   {
      id: 3635,
      word: "qagh",
      name: "qagh (v.) interrupt"
   }, 
   {
      id: 3636,
      word: "qagh",
      name: "qagh (n.) serpent worm (food)"
   }, 
   {
      id: 3637,
      word: "qaj",
      name: "qaj (v.) soar"
   }, 
   {
      id: 3638,
      word: "qajunpaQ",
      name: "qajunpaQ (n.) courage, audacity"
   }, 
   {
      id: 3639,
      word: "qal",
      name: "qal (v.) be corrupt"
   }, 
   {
      id: 3640,
      word: "qal'aq",
      name: "qal'aq (n.) frame, framework, supporting structure, skeleton"
   }, 
   {
      id: 3641,
      word: "qalI'qos",
      name: "qalI'qos (p.n.) Calicos"
   }, 
   {
      id: 3642,
      word: "qalIvornIya",
      name: "qalIvornIya (n.) California"
   }, 
   {
      id: 3643,
      word: "qalmoH",
      name: "qalmoH (v.) corrupt"
   }, 
   {
      id: 3644,
      word: "qalmuS",
      name: "qalmuS (n.) color"
   }, 
   {
      id: 3645,
      word: "qalmuS lung",
      name: "qalmuS lung (n.) chameleon"
   }, 
   {
      id: 3646,
      word: "qam",
      name: "qam (n.) foot"
   }, 
   {
      id: 3647,
      word: "qama'",
      name: "qama' (n.) prisoner"
   }, 
   {
      id: 3648,
      word: "qamchIy",
      name: "qamchIy (p.n.) Qam-Chee"
   }, 
   {
      id: 3649,
      word: "qamchIyngan",
      name: "qamchIyngan (p.n.) Inhabitant of Qam-Chee"
   }, 
   {
      id: 3650,
      word: "qamerun",
      name: "qamerun (n.) Cameroon"
   }, 
   {
      id: 3651,
      word: "qamor",
      name: "qamor (p.n.) Kahmor"
   }, 
   {
      id: 3652,
      word: "qampuchIya'",
      name: "qampuchIya' (n.) Cambodia"
   }, 
   {
      id: 3653,
      word: "qan",
      name: "qan (v.) be old (not young)"
   }, 
   {
      id: 3654,
      word: "qan",
      name: "qan (v.) use the fourth (pinky/little finger) finger"
   }, 
   {
      id: 3655,
      word: "qanQIy loS",
      name: "qanQIy loS (p.n.) Cancri IV (planet)"
   }, 
   {
      id: 3656,
      word: "qang",
      name: "qang (v.) agree with routinely (slang), always agree with (slang), always cooperate with (slang), cooperate with routinely (slang)"
   }, 
   {
      id: 3657,
      word: "qang",
      name: "qang (v.) pour (from one container into another)"
   }, 
   {
      id: 3658,
      word: "qang",
      name: "qang (vs2) willing"
   }, 
   {
      id: 3659,
      word: "qangtlhIn",
      name: "qangtlhIn (n.) beliefs, principles, standards, ethics, ideology"
   }, 
   {
      id: 3660,
      word: "qanjIt",
      name: "qanjIt (p.n.) Kanjit"
   }, 
   {
      id: 3661,
      word: "qanra'",
      name: "qanra' (p.n.) Kahnrah"
   }, 
   {
      id: 3662,
      word: "qanraD",
      name: "qanraD (n.) a bird known for its song"
   }, 
   {
      id: 3663,
      word: "qanwI'",
      name: "qanwI' (n.) fourth finger, little finger"
   }, 
   {
      id: 3664,
      word: "qap",
      name: "qap (v.) insist"
   }, 
   {
      id: 3665,
      word: "qappam",
      name: "qappam (n.) foundation"
   }, 
   {
      id: 3666,
      word: "qaq",
      name: "qaq (v.) be preferable"
   }, 
   {
      id: 3667,
      word: "qaq naH",
      name: "qaq naH (n.) watermelon"
   }, 
   {
      id: 3668,
      word: "qar",
      name: "qar (v.) be accurate"
   }, 
   {
      id: 3669,
      word: "qar Doq",
      name: "qar Doq (n.) goldfish"
   }, 
   {
      id: 3670,
      word: "qar ghotI'",
      name: "qar ghotI' (n.) carp"
   }, 
   {
      id: 3671,
      word: "qarDaS",
      name: "qarDaS (n.) Cardassia"
   }, 
   {
      id: 3672,
      word: "qarDaSQa'",
      name: "qarDaSQa' (n.) Cardassian Union"
   }, 
   {
      id: 3673,
      word: "qarDaSngan",
      name: "qarDaSngan (n.) Cardassian (person)"
   }, 
   {
      id: 3674,
      word: "qara'te",
      name: "qara'te (n.) karate"
   }, 
   {
      id: 3675,
      word: "qargh",
      name: "qargh (v.) be bulky, be thick"
   }, 
   {
      id: 3676,
      word: "qarghan",
      name: "qarghan (p.n.) Kargan"
   }, 
   {
      id: 3677,
      word: "qarpal",
      name: "qarpal (n.) trapezoid"
   }, 
   {
      id: 3678,
      word: "qartaj",
      name: "qartaj (n.) Carthage"
   }, 
   {
      id: 3679,
      word: "qaryoq",
      name: "qaryoq (n.) bird capable of mimicking speech"
   }, 
   {
      id: 3680,
      word: "qaryoq'a'",
      name: "qaryoq'a' (n.) bird capable of mimicking speech, larger than qaryoq"
   }, 
   {
      id: 3681,
      word: "qat",
      name: "qat (v.) accompany (singing) with instrumental music"
   }, 
   {
      id: 3682,
      word: "qat",
      name: "qat (v.) wrap, encase"
   }, 
   {
      id: 3683,
      word: "qatalunya'",
      name: "qatalunya' (n.) Catalonia"
   }, 
   {
      id: 3684,
      word: "qatlh",
      name: "qatlh (question) why?"
   }, 
   {
      id: 3685,
      word: "qatlhDa'",
      name: "qatlhDa' (n.) pipe for water"
   }, 
   {
      id: 3686,
      word: "qatra'",
      name: "qatra' (n.) Katra (vulcan soul)"
   }, 
   {
      id: 3687,
      word: "qatru'",
      name: "qatru' (n.) nerd"
   }, 
   {
      id: 3688,
      word: "qatvoH",
      name: "qatvoH (n.) shellfish (clam, oyster, mussel, scallop, brachiopod"
   }, 
   {
      id: 3689,
      word: "qav",
      name: "qav (n.) the meaning of this word is unknown"
   }, 
   {
      id: 3690,
      word: "qav'ap",
      name: "qav'ap (n.) value, rent, fee"
   }, 
   {
      id: 3691,
      word: "qav'ap juH",
      name: "qav'ap juH (n.) apartment, flat"
   }, 
   {
      id: 3692,
      word: "qaw",
      name: "qaw (n.) memory (the ability)"
   }, 
   {
      id: 3693,
      word: "qaw",
      name: "qaw (v.) remember"
   }, 
   {
      id: 3694,
      word: "qaw'",
      name: "qaw' (v.) flip over, tip over"
   }, 
   {
      id: 3695,
      word: "qaw'moH",
      name: "qaw'moH (v.) flip over"
   }, 
   {
      id: 3696,
      word: "qawHaq",
      name: "qawHaq (n.) memory banks"
   }, 
   {
      id: 3697,
      word: "qawmoH",
      name: "qawmoH (v.) remind"
   }, 
   {
      id: 3698,
      word: "qawno'",
      name: "qawno' (n.) remembrance, memorial"
   }, 
   {
      id: 3699,
      word: "qay",
      name: "qay (v.) use the second (middle) finger"
   }, 
   {
      id: 3700,
      word: "qay'",
      name: "qay' (v.) be a problem, be a hassle"
   }, 
   {
      id: 3701,
      word: "qayrI'Hom",
      name: "qayrI'Hom (n.) clavicle"
   }, 
   {
      id: 3702,
      word: "qaytap",
      name: "qaytap (n.) bill, act"
   }, 
   {
      id: 3703,
      word: "qaytu'",
      name: "qaytu' (n.) parent (gender-neutral term)"
   }, 
   {
      id: 3704,
      word: "qaywI'",
      name: "qaywI' (n.) second finger, middle finger"
   }, 
   {
      id: 3705,
      word: "qa’ramel",
      name: "qa’ramel (n.) caramel"
   }, 
   {
      id: 3706,
      word: "qe'rot 'oQqar",
      name: "qe'rot 'oQqar (n.) carrot"
   }, 
   {
      id: 3707,
      word: "qeD",
      name: "qeD (v.) vacate"
   }, 
   {
      id: 3708,
      word: "qeH",
      name: "qeH (v.) resent"
   }, 
   {
      id: 3709,
      word: "qeQ",
      name: "qeQ (n.) fecal matter, feces, poo, poop"
   }, 
   {
      id: 3710,
      word: "qeQvav",
      name: "qeQvav (n.) thingamajig"
   }, 
   {
      id: 3711,
      word: "qeS",
      name: "qeS (n.) advice"
   }, 
   {
      id: 3712,
      word: "qeS",
      name: "qeS (v.) advise"
   }, 
   {
      id: 3713,
      word: "qeSHoS",
      name: "qeSHoS (n.) keshos, fox, small canine, type of animal"
   }, 
   {
      id: 3714,
      word: "qeSmIv",
      name: "qeSmIv (p.n.) Paul J. Coffey"
   }, 
   {
      id: 3715,
      word: "qeSnoDmaj",
      name: "qeSnoDmaj (n.) jellyfish"
   }, 
   {
      id: 3716,
      word: "qeb",
      name: "qeb (v.) squeeze (windbag instrument)"
   }, 
   {
      id: 3717,
      word: "qebeq",
      name: "qebeq (n.) Quebec"
   }, 
   {
      id: 3718,
      word: "qebeq veng",
      name: "qebeq veng (n.) Quebec City"
   }, 
   {
      id: 3719,
      word: "qech",
      name: "qech (n.) idea"
   }, 
   {
      id: 3720,
      word: "qegh",
      name: "qegh (n.) vat, barrel (for storage of liquor)"
   }, 
   {
      id: 3721,
      word: "qej",
      name: "qej (v.) be grouchy, be mean"
   }, 
   {
      id: 3722,
      word: "qel",
      name: "qel (v.) consider, take into account"
   }, 
   {
      id: 3723,
      word: "qel",
      name: "qel (v.) nod"
   }, 
   {
      id: 3724,
      word: "qelHay'ya",
      name: "qelHay'ya (n.) Kal'Hyah"
   }, 
   {
      id: 3725,
      word: "qelI'qam",
      name: "qelI'qam (n.) kellicam"
   }, 
   {
      id: 3726,
      word: "qelpIngan",
      name: "qelpIngan (p.n.) Kelpien"
   }, 
   {
      id: 3727,
      word: "qelpIya'ngan",
      name: "qelpIya'ngan (p.n.) Kelpien"
   }, 
   {
      id: 3728,
      word: "qem",
      name: "qem (v.) bring"
   }, 
   {
      id: 3729,
      word: "qempa'",
      name: "qempa' (n.) ancestor"
   }, 
   {
      id: 3730,
      word: "qempa'QeH",
      name: "qempa'QeH (p.n.) Qempa'keh"
   }, 
   {
      id: 3731,
      word: "qemyu'po'",
      name: "qemyu'po' (n.) cerebral palsy"
   }, 
   {
      id: 3732,
      word: "qen",
      name: "qen (p.n.) Ken Crissey"
   }, 
   {
      id: 3733,
      word: "qen",
      name: "qen (adverb) recently, a short time ago"
   }, 
   {
      id: 3734,
      word: "qen",
      name: "qen (v.) wipe"
   }, 
   {
      id: 3735,
      word: "qenSaS",
      name: "qenSaS (n.) Kansas"
   }, 
   {
      id: 3736,
      word: "qeng",
      name: "qeng (v.) carry, convey"
   }, 
   {
      id: 3737,
      word: "qeng",
      name: "qeng (p.n.) Kang"
   }, 
   {
      id: 3738,
      word: "qengHoD",
      name: "qengHoD (n.) treasure, booty, plunder, swag, loot"
   }, 
   {
      id: 3739,
      word: "qenggharu'",
      name: "qenggharu' (n.) kangaroo"
   }, 
   {
      id: 3740,
      word: "qenya'",
      name: "qenya' (n.) Kenya"
   }, 
   {
      id: 3741,
      word: "qep",
      name: "qep (n.) meeting"
   }, 
   {
      id: 3742,
      word: "qeq",
      name: "qeq (n.) drill (military)"
   }, 
   {
      id: 3743,
      word: "qeq",
      name: "qeq (v.) practice, train, prepare"
   }, 
   {
      id: 3744,
      word: "qeqchu'",
      name: "qeqchu' (v.) train really well, to work really hard at it and achieve intended goals"
   }, 
   {
      id: 3745,
      word: "qer",
      name: "qer (v.) shrink, get smaller"
   }, 
   {
      id: 3746,
      word: "qerHa'",
      name: "qerHa' (v.) grow, return to original size"
   }, 
   {
      id: 3747,
      word: "qerjIq",
      name: "qerjIq (n.) fireplace"
   }, 
   {
      id: 3748,
      word: "qet",
      name: "qet (v.) run, jog"
   }, 
   {
      id: 3749,
      word: "qet'uy",
      name: "qet'uy (n.) pine cone"
   }, 
   {
      id: 3750,
      word: "qetlh",
      name: "qetlh (v.) be dull, be uninteresting"
   }, 
   {
      id: 3751,
      word: "qettlhup",
      name: "qettlhup (n.) type of sauce"
   }, 
   {
      id: 3752,
      word: "qev",
      name: "qev (v.) crowd"
   }, 
   {
      id: 3753,
      word: "qevaS",
      name: "qevaS (n.) kevas"
   }, 
   {
      id: 3754,
      word: "qevpob",
      name: "qevpob (n.) jowl, cheek"
   }, 
   {
      id: 3755,
      word: "qew",
      name: "qew (v.) use the third (ring) finger"
   }, 
   {
      id: 3756,
      word: "qewwI'",
      name: "qewwI' (n.) third finger, ring finger"
   }, 
   {
      id: 3757,
      word: "qey",
      name: "qey (v.) be in vain, futile"
   }, 
   {
      id: 3758,
      word: "qey'Hav",
      name: "qey'Hav (n.) vagina"
   }, 
   {
      id: 3759,
      word: "qeylIS",
      name: "qeylIS (p.n.) Kahless"
   }, 
   {
      id: 3760,
      word: "qeylIS betleH",
      name: "qeylIS betleH (n.) Sword of Kahless"
   }, 
   {
      id: 3761,
      word: "qeylIS mInDu'",
      name: "qeylIS mInDu' (n.) Eyes of Kahless"
   }, 
   {
      id: 3762,
      word: "qeylIs betleH",
      name: "qeylIs betleH (p.n.) Sword of Kahless"
   }, 
   {
      id: 3763,
      word: "qeylar",
      name: "qeylar (p.n.) K'Ehleyr"
   }, 
   {
      id: 3764,
      word: "qo'",
      name: "qo' (n.) world, realm"
   }, 
   {
      id: 3765,
      word: "qo'la' 'awje'",
      name: "qo'la' 'awje' (n.) cola (coke)"
   }, 
   {
      id: 3766,
      word: "qo'leq",
      name: "qo'leq (p.n.) Ko'lek"
   }, 
   {
      id: 3767,
      word: "qo'qa' qo'la'",
      name: "qo'qa' qo'la' (n.) Coca-Cola"
   }, 
   {
      id: 3768,
      word: "qo'qaD",
      name: "qo'qaD (n.) phlegm"
   }, 
   {
      id: 3769,
      word: "qo'qo",
      name: "qo'qo (n.) coconut"
   }, 
   {
      id: 3770,
      word: "qo'rIn",
      name: "qo'rIn (n.) chromium salts"
   }, 
   {
      id: 3771,
      word: "qo'rIn DIr",
      name: "qo'rIn DIr (n.) leather"
   }, 
   {
      id: 3772,
      word: "qo'ran",
      name: "qo'ran (p.n.) Anthony Curran"
   }, 
   {
      id: 3773,
      word: "qo'rob",
      name: "qo'rob (n.) puppet"
   }, 
   {
      id: 3774,
      word: "qo'vID",
      name: "qo'vID (n.) Covid 19 (SARS-CoV-2 disease)"
   }, 
   {
      id: 3775,
      word: "qoD",
      name: "qoD (n.) inside, interior"
   }, 
   {
      id: 3776,
      word: "qoH",
      name: "qoH (n.) fool"
   }, 
   {
      id: 3777,
      word: "qoS",
      name: "qoS (n.) birthday"
   }, 
   {
      id: 3778,
      word: "qoSqa'rIy",
      name: "qoSqa'rIy (n.) Kos'Karii"
   }, 
   {
      id: 3779,
      word: "qoSta'",
      name: "qoSta' (n.) strip, tape, ribbon (long flat thin material)"
   }, 
   {
      id: 3780,
      word: "qoStarI'qa",
      name: "qoStarI'qa (n.) Costa Rica"
   }, 
   {
      id: 3781,
      word: "qobra' ghargh",
      name: "qobra' ghargh (n.) cobra"
   }, 
   {
      id: 3782,
      word: "qoch",
      name: "qoch (n.) partner"
   }, 
   {
      id: 3783,
      word: "qoch",
      name: "qoch (v.) squeeze into (a space)"
   }, 
   {
      id: 3784,
      word: "qoch'uq",
      name: "qoch'uq (n.) rubber"
   }, 
   {
      id: 3785,
      word: "qogh",
      name: "qogh (n.) belt, ear (external, cartilaginous flap)"
   }, 
   {
      id: 3786,
      word: "qogh tuQmoHHa'",
      name: "qogh tuQmoHHa' (idiom) to not hear"
   }, 
   {
      id: 3787,
      word: "qoj",
      name: "qoj (conjunction) and/or (joining sentences)"
   }, 
   {
      id: 3788,
      word: "qoj",
      name: "qoj (n.) cliff"
   }, 
   {
      id: 3789,
      word: "qol",
      name: "qol (n.) collection of segments that are joined together, collocation"
   }, 
   {
      id: 3790,
      word: "qol",
      name: "qol (p.n.) Kol"
   }, 
   {
      id: 3791,
      word: "qol",
      name: "qol (v.) pronounce"
   }, 
   {
      id: 3792,
      word: "qol'om",
      name: "qol'om (n.) gold (element)"
   }, 
   {
      id: 3793,
      word: "qolotlh",
      name: "qolotlh (p.n.) Koloth"
   }, 
   {
      id: 3794,
      word: "qolqoS",
      name: "qolqoS (n.) core of a group, the essential part of something; essence"
   }, 
   {
      id: 3795,
      word: "qomorIy",
      name: "qomorIy (n.) Comoros"
   }, 
   {
      id: 3796,
      word: "qompogh",
      name: "qompogh (n.) type of food, Kompog"
   }, 
   {
      id: 3797,
      word: "qon",
      name: "qon (v.) record, compose music"
   }, 
   {
      id: 3798,
      word: "qonggho",
      name: "qonggho (n.) Congo"
   }, 
   {
      id: 3799,
      word: "qonglIl",
      name: "qonglIl (n.) peanut"
   }, 
   {
      id: 3800,
      word: "qongmeS",
      name: "qongmeS (n.) sibling"
   }, 
   {
      id: 3801,
      word: "qonwI'",
      name: "qonwI' (n.) songwriter, storywriter"
   }, 
   {
      id: 3802,
      word: "qop",
      name: "qop (v.) arrest"
   }, 
   {
      id: 3803,
      word: "qopagh",
      name: "qopagh (n.) diorite"
   }, 
   {
      id: 3804,
      word: "qoq",
      name: "qoq (n.) robot"
   }, 
   {
      id: 3805,
      word: "qoq",
      name: "qoq (ns3) so-called"
   }, 
   {
      id: 3806,
      word: "qoq De'wI' Dojmey",
      name: "qoq De'wI' Dojmey (n.) botnet (computer jargon)"
   }, 
   {
      id: 3807,
      word: "qor",
      name: "qor (p.n.) Kor"
   }, 
   {
      id: 3808,
      word: "qor",
      name: "qor (v.) scavenge"
   }, 
   {
      id: 3809,
      word: "qorDayt",
      name: "qorDayt (p.n.) Keven A. Geiselman"
   }, 
   {
      id: 3810,
      word: "qorDu'",
      name: "qorDu' (n.) family"
   }, 
   {
      id: 3811,
      word: "qoreQ",
      name: "qoreQ (p.n.) Korax"
   }, 
   {
      id: 3812,
      word: "qorgh",
      name: "qorgh (v.) to stop up, fill up a hole"
   }, 
   {
      id: 3813,
      word: "qorghwI'",
      name: "qorghwI' (n.) pacifier"
   }, 
   {
      id: 3814,
      word: "qorghwI'",
      name: "qorghwI' (n.) stopper, cork (for a bottle)"
   }, 
   {
      id: 3815,
      word: "qornelyuS",
      name: "qornelyuS (p.n.) Cornelius"
   }, 
   {
      id: 3816,
      word: "qoro'nIn",
      name: "qoro'nIn (p.n.) Linda Hunnefield"
   }, 
   {
      id: 3817,
      word: "qoro'na javtIm",
      name: "qoro'na javtIm (n.) corona virus"
   }, 
   {
      id: 3818,
      word: "qorvIt",
      name: "qorvIt (n.) korvit, type of rodent"
   }, 
   {
      id: 3819,
      word: "qot",
      name: "qot (v.) back, sponsor, support, capitalize, invest in"
   }, 
   {
      id: 3820,
      word: "qotDIvwar",
      name: "qotDIvwar (n.) Cote d'Ivoire"
   }, 
   {
      id: 3821,
      word: "qotar",
      name: "qotar (p.n.) Kotar"
   }, 
   {
      id: 3822,
      word: "qotlh",
      name: "qotlh (v.) deserve, warrant"
   }, 
   {
      id: 3823,
      word: "qotlh",
      name: "qotlh (v.) tickle"
   }, 
   {
      id: 3824,
      word: "qovDa'",
      name: "qovDa' (n.) exponent"
   }, 
   {
      id: 3825,
      word: "qovIj",
      name: "qovIj (n.) canine-like creature (smaller than a ngavyaw')"
   }, 
   {
      id: 3826,
      word: "qoy'",
      name: "qoy' (v.) plead, beg"
   }, 
   {
      id: 3827,
      word: "qriS'ey",
      name: "qriS'ey (p.n.) Ken Crissey"
   }, 
   {
      id: 3828,
      word: "qu'",
      name: "qu' (v.) be fierce"
   }, 
   {
      id: 3829,
      word: "qu'",
      name: "qu' (v.) be great (slang), be wonderful (slang), be excellent (slang), be splendid (slang), be good (slang)"
   }, 
   {
      id: 3830,
      word: "qu'",
      name: "qu' (vsr) emphatic"
   }, 
   {
      id: 3831,
      word: "qu'",
      name: "qu' (p.n.) Joe Steger"
   }, 
   {
      id: 3832,
      word: "qu'vIgh",
      name: "qu'vIgh (n.) member of an august body"
   }, 
   {
      id: 3833,
      word: "qu'vu'",
      name: "qu'vu' (n.) pyramid with a three-sided base, tetrahedron"
   }, 
   {
      id: 3834,
      word: "quD",
      name: "quD (n.) type of sauce"
   }, 
   {
      id: 3835,
      word: "quH",
      name: "quH (n.) heritage"
   }, 
   {
      id: 3836,
      word: "quH",
      name: "quH (v.) slice, carve"
   }, 
   {
      id: 3837,
      word: "quHvaj",
      name: "quHvaj (n.) dandruff"
   }, 
   {
      id: 3838,
      word: "quS",
      name: "quS (n.) chair"
   }, 
   {
      id: 3839,
      word: "quSDI'",
      name: "quSDI' (n.) batch"
   }, 
   {
      id: 3840,
      word: "quSlab",
      name: "quSlab (n.) couch, bench, chair for multiple people"
   }, 
   {
      id: 3841,
      word: "qub",
      name: "qub (v.) be rare"
   }, 
   {
      id: 3842,
      word: "quba'",
      name: "quba' (n.) Cuba"
   }, 
   {
      id: 3843,
      word: "qubbID",
      name: "qubbID (n.) span, run, stretch (between)"
   }, 
   {
      id: 3844,
      word: "quch",
      name: "quch (v.) kidnap"
   }, 
   {
      id: 3845,
      word: "qugh",
      name: "qugh (v.) cruise"
   }, 
   {
      id: 3846,
      word: "qughDo",
      name: "qughDo (n.) crusing speed"
   }, 
   {
      id: 3847,
      word: "qughDuj",
      name: "qughDuj (n.) cruiser"
   }, 
   {
      id: 3848,
      word: "qul",
      name: "qul (n.) fire"
   }, 
   {
      id: 3849,
      word: "qul 'alwI'",
      name: "qul 'alwI' (n.) will-o'-the-wisp"
   }, 
   {
      id: 3850,
      word: "qul QongmoHwI'",
      name: "qul QongmoHwI' (n.) firefighter"
   }, 
   {
      id: 3851,
      word: "qul SuvwI'",
      name: "qul SuvwI' (n.) firefighter, lit. fire fighter, fire warrior"
   }, 
   {
      id: 3852,
      word: "qul chenmoH",
      name: "qul chenmoH (v.) light a fire, ignite"
   }, 
   {
      id: 3853,
      word: "qul mI'wI'",
      name: "qul mI'wI' (n.) fire dancer"
   }, 
   {
      id: 3854,
      word: "qul qaDwI'",
      name: "qul qaDwI' (n.) firefighter, lit. fire challenger"
   }, 
   {
      id: 3855,
      word: "qul tlhay'moHwI'",
      name: "qul tlhay'moHwI' (n.) firefighter, lit. fire tamer (less frequent)"
   }, 
   {
      id: 3856,
      word: "qul tuq",
      name: "qul tuq (p.n.) House of Fire - name of an opera"
   }, 
   {
      id: 3857,
      word: "qulHuD",
      name: "qulHuD (n.) volcano"
   }, 
   {
      id: 3858,
      word: "qulSIp",
      name: "qulSIp (n.) methane"
   }, 
   {
      id: 3859,
      word: "qulcher",
      name: "qulcher (n.) cream"
   }, 
   {
      id: 3860,
      word: "qum",
      name: "qum (v.) govern"
   }, 
   {
      id: 3861,
      word: "qum",
      name: "qum (n.) government"
   }, 
   {
      id: 3862,
      word: "qumwI'",
      name: "qumwI' (n.) governor"
   }, 
   {
      id: 3863,
      word: "qun",
      name: "qun (n.) history"
   }, 
   {
      id: 3864,
      word: "qun",
      name: "qun (v.) scold"
   }, 
   {
      id: 3865,
      word: "qunI'",
      name: "qunI' (n.) adverb(ial)"
   }, 
   {
      id: 3866,
      word: "qunQeD",
      name: "qunQeD (n.) history science"
   }, 
   {
      id: 3867,
      word: "qung",
      name: "qung (n.) hole (like in a musical wind instrument)"
   }, 
   {
      id: 3868,
      word: "quntej",
      name: "quntej (n.) historian"
   }, 
   {
      id: 3869,
      word: "qup",
      name: "qup (n.) elder"
   }, 
   {
      id: 3870,
      word: "quprIp",
      name: "quprIp (n.) Council of Elders"
   }, 
   {
      id: 3871,
      word: "quq",
      name: "quq (v.) happen simultaneously, be simultaneous"
   }, 
   {
      id: 3872,
      word: "qur",
      name: "qur (v.) be greedy"
   }, 
   {
      id: 3873,
      word: "qur'ep",
      name: "qur'ep (n.) wig"
   }, 
   {
      id: 3874,
      word: "qurDIStan",
      name: "qurDIStan (n.) Kurdistan"
   }, 
   {
      id: 3875,
      word: "qurIn",
      name: "qurIn (p.n.) Kurn"
   }, 
   {
      id: 3876,
      word: "qurgh",
      name: "qurgh (n.) bean, beans"
   }, 
   {
      id: 3877,
      word: "qurgh",
      name: "qurgh (p.n.) Chris Lipscombe"
   }, 
   {
      id: 3878,
      word: "qurleH",
      name: "qurleH (n.) kur'leth"
   }, 
   {
      id: 3879,
      word: "qurme'",
      name: "qurme' (n.) ingredient"
   }, 
   {
      id: 3880,
      word: "qurmoQ",
      name: "qurmoQ (n.) larynx"
   }, 
   {
      id: 3881,
      word: "qut",
      name: "qut (n.) crystal (geologic formation)"
   }, 
   {
      id: 3882,
      word: "qut",
      name: "qut (v.) predict (suspected to be fraudulent)"
   }, 
   {
      id: 3883,
      word: "qut na'",
      name: "qut na' (n.) salt (culinary, halite)"
   }, 
   {
      id: 3884,
      word: "qutlh",
      name: "qutlh (v.) be cheap"
   }, 
   {
      id: 3885,
      word: "qutluch",
      name: "qutluch (n.) hand weapon (type of)"
   }, 
   {
      id: 3886,
      word: "qutluch tay",
      name: "qutluch tay (n.) Kut'luch ceremony"
   }, 
   {
      id: 3887,
      word: "quv",
      name: "quv (v.) be honored"
   }, 
   {
      id: 3888,
      word: "quv",
      name: "quv (n.) honor"
   }, 
   {
      id: 3889,
      word: "quv bey'",
      name: "quv bey' (n.) honor display"
   }, 
   {
      id: 3890,
      word: "quvHa'",
      name: "quvHa' (v.) be dishonored"
   }, 
   {
      id: 3891,
      word: "quvHa'ghach",
      name: "quvHa'ghach (n.) dishonor"
   }, 
   {
      id: 3892,
      word: "quvHa'ghach mIr",
      name: "quvHa'ghach mIr (n.) losing streak"
   }, 
   {
      id: 3893,
      word: "quvamaq",
      name: "quvamaq (p.n.) Kuvah'magh"
   }, 
   {
      id: 3894,
      word: "quvmoH",
      name: "quvmoH (v.) honor"
   }, 
   {
      id: 3895,
      word: "quvyaH",
      name: "quvyaH (n.) habit"
   }, 
   {
      id: 3896,
      word: "quwenya' Hol",
      name: "quwenya' Hol (n.) Quenya"
   }, 
   {
      id: 3897,
      word: "quy'Ip",
      name: "quy'Ip (n.) vomit"
   }, 
   {
      id: 3898,
      word: "r'Hul",
      name: "r'Hul (p.n.) Rachel Wyman"
   }, 
   {
      id: 3899,
      word: "rI'",
      name: "rI' (v.) hail"
   }, 
   {
      id: 3900,
      word: "rI'Se'",
      name: "rI'Se' (n.) hailing frequency"
   }, 
   {
      id: 3901,
      word: "rI'gheS",
      name: "rI'gheS (n.) deflector (singular)"
   }, 
   {
      id: 3902,
      word: "rI'meH wovmoHwI'",
      name: "rI'meH wovmoHwI' (n.) beacon"
   }, 
   {
      id: 3903,
      word: "rI'wI'",
      name: "rI'wI' (n.) loudspeaker"
   }, 
   {
      id: 3904,
      word: "rID",
      name: "rID (v.) digest (the process food goes through)"
   }, 
   {
      id: 3905,
      word: "rID'oH",
      name: "rID'oH (n.) barley-like plant"
   }, 
   {
      id: 3906,
      word: "rIH",
      name: "rIH (v.) energize"
   }, 
   {
      id: 3907,
      word: "rIHwI'",
      name: "rIHwI' (n.) energizer"
   }, 
   {
      id: 3908,
      word: "rIQ",
      name: "rIQ (v.) be injured"
   }, 
   {
      id: 3909,
      word: "rIQmoH",
      name: "rIQmoH (v.) injure"
   }, 
   {
      id: 3910,
      word: "rIS",
      name: "rIS (n.) click"
   }, 
   {
      id: 3911,
      word: "rIS",
      name: "rIS (v.) make a cracking, clicking, or snapping sound, emit a signal"
   }, 
   {
      id: 3912,
      word: "rISlIw",
      name: "rISlIw (n.) tar"
   }, 
   {
      id: 3913,
      word: "rIb",
      name: "rIb (v.) be spread, spread out"
   }, 
   {
      id: 3914,
      word: "rIch",
      name: "rIch (v.) talk about, discuss"
   }, 
   {
      id: 3915,
      word: "rIchwIn",
      name: "rIchwIn (n.) directive, injunction"
   }, 
   {
      id: 3916,
      word: "rIgh",
      name: "rIgh (v.) be lame"
   }, 
   {
      id: 3917,
      word: "rIj",
      name: "rIj (v.) be moored, anchored"
   }, 
   {
      id: 3918,
      word: "rIjHa'",
      name: "rIjHa' (v.) be adrift"
   }, 
   {
      id: 3919,
      word: "rIjmeH tlhegh",
      name: "rIjmeH tlhegh (n.) tether, leash"
   }, 
   {
      id: 3920,
      word: "rIl",
      name: "rIl (v.) play (a wind instrument)"
   }, 
   {
      id: 3921,
      word: "rIl",
      name: "rIl (v.) use the thumb"
   }, 
   {
      id: 3922,
      word: "rIlwI'",
      name: "rIlwI' (n.) thumb"
   }, 
   {
      id: 3923,
      word: "rImbey",
      name: "rImbey (n.) hormone"
   }, 
   {
      id: 3924,
      word: "rIn",
      name: "rIn (v.) be accomplished, be finished"
   }, 
   {
      id: 3925,
      word: "rIp",
      name: "rIp (n.) council, assembly"
   }, 
   {
      id: 3926,
      word: "rIq",
      name: "rIq (v.) pioneer, break through, innovate"
   }, 
   {
      id: 3927,
      word: "rIt",
      name: "rIt (v.) summon, invite"
   }, 
   {
      id: 3928,
      word: "rItlh",
      name: "rItlh (n.) pigment, paint, dye, ink"
   }, 
   {
      id: 3929,
      word: "rItlh 'echlet",
      name: "rItlh 'echlet (n.) ink pad"
   }, 
   {
      id: 3930,
      word: "rItlh naQ",
      name: "rItlh naQ (n.) pigment stick, paint brush"
   }, 
   {
      id: 3931,
      word: "rItlh vol",
      name: "rItlh vol (n.) stencil"
   }, 
   {
      id: 3932,
      word: "rIv",
      name: "rIv (v.) split"
   }, 
   {
      id: 3933,
      word: "rIvSo'",
      name: "rIvSo' (n.) embassy"
   }, 
   {
      id: 3934,
      word: "rIymuS",
      name: "rIymuS (n.) Remus"
   }, 
   {
      id: 3935,
      word: "ra'",
      name: "ra' (v.) command, order"
   }, 
   {
      id: 3936,
      word: "ra'",
      name: "ra' (v.) conduct (an orchestra)"
   }, 
   {
      id: 3937,
      word: "ra'",
      name: "ra' (ns4) your (pl) (noun capable of using language)"
   }, 
   {
      id: 3938,
      word: "ra'Duch",
      name: "ra'Duch (n.) triangle"
   }, 
   {
      id: 3939,
      word: "ra'Duch leD",
      name: "ra'Duch leD (n.) right triangle"
   }, 
   {
      id: 3940,
      word: "ra'Duch leD qubbID",
      name: "ra'Duch leD qubbID (n.) hypotenuse"
   }, 
   {
      id: 3941,
      word: "ra'Duch quv",
      name: "ra'Duch quv (n.) isosceles triangle (lit: honored triangle)"
   }, 
   {
      id: 3942,
      word: "ra'Duch tIQ",
      name: "ra'Duch tIQ (n.) equilateral triangle (lit: ancient triangle)"
   }, 
   {
      id: 3943,
      word: "ra'Duch tut",
      name: "ra'Duch tut (n.) prism (three sided base)"
   }, 
   {
      id: 3944,
      word: "ra'ghomquv",
      name: "ra'ghomquv (n.) High Command"
   }, 
   {
      id: 3945,
      word: "ra'taj",
      name: "ra'taj (n.) type of beverage, coffee with liquor"
   }, 
   {
      id: 3946,
      word: "ra'wI'",
      name: "ra'wI' (n.) commander"
   }, 
   {
      id: 3947,
      word: "raD",
      name: "raD (v.) force, compel"
   }, 
   {
      id: 3948,
      word: "raHta'",
      name: "raHta' (n.) racht (Klingon food)"
   }, 
   {
      id: 3949,
      word: "raQ",
      name: "raQ (n.) camp (military term)"
   }, 
   {
      id: 3950,
      word: "raQ",
      name: "raQ (v.) manipulate by hand, handle"
   }, 
   {
      id: 3951,
      word: "raQpo'",
      name: "raQpo' (n.) passenger"
   }, 
   {
      id: 3952,
      word: "raS",
      name: "raS (n.) table"
   }, 
   {
      id: 3953,
      word: "raS'IS",
      name: "raS'IS (n.) seed"
   }, 
   {
      id: 3954,
      word: "raSber naH",
      name: "raSber naH (n.) raspberry"
   }, 
   {
      id: 3955,
      word: "raSber naHmey",
      name: "raSber naHmey (n.) raspberries"
   }, 
   {
      id: 3956,
      word: "raSya'",
      name: "raSya' (n.) Russia"
   }, 
   {
      id: 3957,
      word: "rab",
      name: "rab (v.) be gigantic, huge, humongous"
   }, 
   {
      id: 3958,
      word: "rabe'rIt",
      name: "rabe'rIt (p.n.) Robert"
   }, 
   {
      id: 3959,
      word: "rach",
      name: "rach (v.) invigorate, fortify, strengthen"
   }, 
   {
      id: 3960,
      word: "rachwI'",
      name: "rachwI' (n.) nurse"
   }, 
   {
      id: 3961,
      word: "ragh",
      name: "ragh (v.) decay, rust, corrode"
   }, 
   {
      id: 3962,
      word: "raghbI'",
      name: "raghbI' (n.) rugby"
   }, 
   {
      id: 3963,
      word: "raghghan",
      name: "raghghan (n.) doll, action figure, miniature humanoid"
   }, 
   {
      id: 3964,
      word: "raj",
      name: "raj (ns4) your (pl)"
   }, 
   {
      id: 3965,
      word: "rajma'",
      name: "rajma' (n.) kidney"
   }, 
   {
      id: 3966,
      word: "ral",
      name: "ral (v.) be violent"
   }, 
   {
      id: 3967,
      word: "ram",
      name: "ram (v.) be trivial, be trifling, be unimportant, be insignificant"
   }, 
   {
      id: 3968,
      word: "ram",
      name: "ram (n.) night"
   }, 
   {
      id: 3969,
      word: "ramDung",
      name: "ramDung (n.) chewing gum"
   }, 
   {
      id: 3970,
      word: "ramjep",
      name: "ramjep (n.) a type of bird (probably nocturnal)"
   }, 
   {
      id: 3971,
      word: "ramjep",
      name: "ramjep (n.) midnight"
   }, 
   {
      id: 3972,
      word: "rang",
      name: "rang (v.) be responsible for"
   }, 
   {
      id: 3973,
      word: "rap",
      name: "rap (v.) be the same"
   }, 
   {
      id: 3974,
      word: "rapmar",
      name: "rapmar (n.) oar"
   }, 
   {
      id: 3975,
      word: "raq",
      name: "raq (v.) be repetitive/redundant"
   }, 
   {
      id: 3976,
      word: "raqDar",
      name: "raqDar (n.) pirate"
   }, 
   {
      id: 3977,
      word: "raqDar chap",
      name: "raqDar chap (n.) privateer"
   }, 
   {
      id: 3978,
      word: "raqSan",
      name: "raqSan (p.n.) Roxann"
   }, 
   {
      id: 3979,
      word: "raqchap",
      name: "raqchap () privateer"
   }, 
   {
      id: 3980,
      word: "raqvel",
      name: "raqvel (n.) railing part of a guardrail or banister"
   }, 
   {
      id: 3981,
      word: "rar",
      name: "rar (v.) connect"
   }, 
   {
      id: 3982,
      word: "rarchuq",
      name: "rarchuq (v.) be related"
   }, 
   {
      id: 3983,
      word: "rarwI'",
      name: "rarwI' (n.) plug"
   }, 
   {
      id: 3984,
      word: "ratlh",
      name: "ratlh (v.) remain"
   }, 
   {
      id: 3985,
      word: "rav",
      name: "rav (n.) floor, minimum"
   }, 
   {
      id: 3986,
      word: "rav De'lor",
      name: "rav De'lor (n.) stalagmite"
   }, 
   {
      id: 3987,
      word: "rav'eq",
      name: "rav'eq (n.) ceiling"
   }, 
   {
      id: 3988,
      word: "ravngI'",
      name: "ravngI' (n.) furniture, item of furniture"
   }, 
   {
      id: 3989,
      word: "raw",
      name: "raw (v.) lightning"
   }, 
   {
      id: 3990,
      word: "raw'",
      name: "raw' (n.) an aquatic bird with colorful plumage"
   }, 
   {
      id: 3991,
      word: "ray tlhen",
      name: "ray tlhen (v.) make an r sound, trill"
   }, 
   {
      id: 3992,
      word: "ray'",
      name: "ray' (n.) targets"
   }, 
   {
      id: 3993,
      word: "ray' tIr",
      name: "ray' tIr (n.) rice"
   }, 
   {
      id: 3994,
      word: "rayQeD",
      name: "rayQeD (n.) genetics"
   }, 
   {
      id: 3995,
      word: "raywal",
      name: "raywal (n.) booth (small building)"
   }, 
   {
      id: 3996,
      word: "re",
      name: "re (vp) we-you (pl)"
   }, 
   {
      id: 3997,
      word: "re'Hom'at",
      name: "re'Hom'at (n.) scarf (neck)"
   }, 
   {
      id: 3998,
      word: "re'chIv",
      name: "re'chIv (n.) internal organ"
   }, 
   {
      id: 3999,
      word: "re'lIng",
      name: "re'lIng (n.) instinct, talent, facility, aptitude"
   }, 
   {
      id: 4000,
      word: "re'nop",
      name: "re'nop (n.) shard"
   }, 
   {
      id: 4001,
      word: "re'tISyav",
      name: "re'tISyav (n.) spermatozoon"
   }, 
   {
      id: 4002,
      word: "re'yub",
      name: "re'yub (n.) habitat"
   }, 
   {
      id: 4003,
      word: "reD",
      name: "reD (n.) exterior wall, side (of something)"
   }, 
   {
      id: 4004,
      word: "reD'eS",
      name: "reD'eS (n.) bureaucracy"
   }, 
   {
      id: 4005,
      word: "reDlIgh",
      name: "reDlIgh (n.) fluorine"
   }, 
   {
      id: 4006,
      word: "reDyev",
      name: "reDyev (n.) shortage"
   }, 
   {
      id: 4007,
      word: "reH",
      name: "reH (adverb) always"
   }, 
   {
      id: 4008,
      word: "reH",
      name: "reH (v.) play"
   }, 
   {
      id: 4009,
      word: "reS",
      name: "reS (v.) conjure, cast a spell"
   }, 
   {
      id: 4010,
      word: "reS",
      name: "reS (v.) grow (flowers/plants/vegetables)"
   }, 
   {
      id: 4011,
      word: "reStav",
      name: "reStav (n.) shin, forearm"
   }, 
   {
      id: 4012,
      word: "rebmugh",
      name: "rebmugh (n.) resin"
   }, 
   {
      id: 4013,
      word: "rech",
      name: "rech (v.) exhale"
   }, 
   {
      id: 4014,
      word: "regh",
      name: "regh (v.) bleed"
   }, 
   {
      id: 4015,
      word: "reghuluS",
      name: "reghuluS (n.) Regulus"
   }, 
   {
      id: 4016,
      word: "reghuluS 'Iwghargh",
      name: "reghuluS 'Iwghargh (n.) Regulan bloodworm"
   }, 
   {
      id: 4017,
      word: "reghuluSngan",
      name: "reghuluSngan (n.) Regulan"
   }, 
   {
      id: 4018,
      word: "rejghun",
      name: "rejghun (n.) undergarments, underwear, underpants, undershirts"
   }, 
   {
      id: 4019,
      word: "rejghun yIvbeH",
      name: "rejghun yIvbeH (n.) undershirt"
   }, 
   {
      id: 4020,
      word: "rejghun yopwaH",
      name: "rejghun yopwaH (n.) boxer shorts"
   }, 
   {
      id: 4021,
      word: "rejghun yopwaH",
      name: "rejghun yopwaH (n.) underpants"
   }, 
   {
      id: 4022,
      word: "rejghun yopwaH Qey",
      name: "rejghun yopwaH Qey (n.) boxer briefs"
   }, 
   {
      id: 4023,
      word: "rejghun yopwaHHom",
      name: "rejghun yopwaHHom (n.) briefs"
   }, 
   {
      id: 4024,
      word: "rejmorgh",
      name: "rejmorgh (n.) worrywart"
   }, 
   {
      id: 4025,
      word: "rel",
      name: "rel (v.) be dazed"
   }, 
   {
      id: 4026,
      word: "relleghDaq",
      name: "relleghDaq (n.) psychokinesis"
   }, 
   {
      id: 4027,
      word: "rem",
      name: "rem (v.) suck"
   }, 
   {
      id: 4028,
      word: "rem'ay'",
      name: "rem'ay' (n.) diaphragm, thoracic diaphragm (body part)"
   }, 
   {
      id: 4029,
      word: "remloS",
      name: "remloS (n.) internal organ"
   }, 
   {
      id: 4030,
      word: "remloSDu'",
      name: "remloSDu' (n.) guts, bowels, entrails"
   }, 
   {
      id: 4031,
      word: "ren",
      name: "ren (v.) design, map out, plan"
   }, 
   {
      id: 4032,
      word: "renwI'",
      name: "renwI' (n.) architect"
   }, 
   {
      id: 4033,
      word: "renyarDaq",
      name: "renyarDaq (n.) psychic ability or abilities"
   }, 
   {
      id: 4034,
      word: "renyarDaq QeD",
      name: "renyarDaq QeD (n.) parapsychology"
   }, 
   {
      id: 4035,
      word: "rep",
      name: "rep (n.) hour"
   }, 
   {
      id: 4036,
      word: "rep'eSlaqram",
      name: "rep'eSlaqram (n.) mascot"
   }, 
   {
      id: 4037,
      word: "repnuj",
      name: "repnuj (n.) gum (oral anatomy)"
   }, 
   {
      id: 4038,
      word: "republIyqaDomInIqa'na",
      name: "republIyqaDomInIqa'na (n.) Dominican Republic"
   }, 
   {
      id: 4039,
      word: "req",
      name: "req (n.) wax"
   }, 
   {
      id: 4040,
      word: "reqwer",
      name: "reqwer (n.) shrimp-like animal"
   }, 
   {
      id: 4041,
      word: "ret",
      name: "ret (v.) be most recent"
   }, 
   {
      id: 4042,
      word: "ret",
      name: "ret (n.) time period ago (past)"
   }, 
   {
      id: 4043,
      word: "ret'aq",
      name: "ret'aq (n.) handle, hilt (of knife, bat'leth)"
   }, 
   {
      id: 4044,
      word: "retlaw",
      name: "retlaw (n.) dent, indentation"
   }, 
   {
      id: 4045,
      word: "retlh",
      name: "retlh (n.) area beside, area next to"
   }, 
   {
      id: 4046,
      word: "rev",
      name: "rev (v.) quote"
   }, 
   {
      id: 4047,
      word: "rewbe'",
      name: "rewbe' (n.) citizen"
   }, 
   {
      id: 4048,
      word: "rewve'",
      name: "rewve' (n.) air (everyday word)"
   }, 
   {
      id: 4049,
      word: "rewve' mIjDang",
      name: "rewve' mIjDang (n.) fan, handheld fan"
   }, 
   {
      id: 4050,
      word: "rey",
      name: "rey (v.) squeeze and stretch out (windbag instrument)"
   }, 
   {
      id: 4051,
      word: "rey'",
      name: "rey' (n.) a special performance or presentation"
   }, 
   {
      id: 4052,
      word: "reynalDo",
      name: "reynalDo (p.n.) Reynaldo"
   }, 
   {
      id: 4053,
      word: "ro",
      name: "ro (n.) trunk (of body), torso"
   }, 
   {
      id: 4054,
      word: "ro'",
      name: "ro' (n.) fist"
   }, 
   {
      id: 4055,
      word: "ro'Sa'",
      name: "ro'Sa' (n.) rose (a Terran flower)"
   }, 
   {
      id: 4056,
      word: "ro'leSlIb",
      name: "ro'leSlIb (n.) barnacle"
   }, 
   {
      id: 4057,
      word: "ro'qa'",
      name: "ro'qa' (n.) tonsil"
   }, 
   {
      id: 4058,
      word: "ro'qegh'Iwchab",
      name: "ro'qegh'Iwchab (n.) rokeg blood pie"
   }, 
   {
      id: 4059,
      word: "roD",
      name: "roD (adverb) usually, customarily, habitually, regularly"
   }, 
   {
      id: 4060,
      word: "roDSer",
      name: "roDSer (n.) dimension"
   }, 
   {
      id: 4061,
      word: "roDSon",
      name: "roDSon (n.) uvula"
   }, 
   {
      id: 4062,
      word: "roQ",
      name: "roQ (v.) put down"
   }, 
   {
      id: 4063,
      word: "roS",
      name: "roS (v.) lick"
   }, 
   {
      id: 4064,
      word: "roS",
      name: "roS (v.) use the third toe"
   }, 
   {
      id: 4065,
      word: "roSHa'",
      name: "roSHa' (v.) be paralyzed"
   }, 
   {
      id: 4066,
      word: "roSHa'moH",
      name: "roSHa'moH (v.) paralyze"
   }, 
   {
      id: 4067,
      word: "roSenQatlh",
      name: "roSenQatlh (p.n.) Rosencrantz"
   }, 
   {
      id: 4068,
      word: "roSghaH",
      name: "roSghaH (n.) DNA (Deoxyribonucleic acid)"
   }, 
   {
      id: 4069,
      word: "roSmaH",
      name: "roSmaH (n.) chromosome"
   }, 
   {
      id: 4070,
      word: "roSqa'QeD",
      name: "roSqa'QeD (n.) archaeology"
   }, 
   {
      id: 4071,
      word: "roSwI'",
      name: "roSwI' (n.) third toe"
   }, 
   {
      id: 4072,
      word: "rob'agh",
      name: "rob'agh (n.) hologram"
   }, 
   {
      id: 4073,
      word: "rober",
      name: "rober (n.) axis"
   }, 
   {
      id: 4074,
      word: "rober jan",
      name: "rober jan (n.) lathe"
   }, 
   {
      id: 4075,
      word: "robwIl",
      name: "robwIl (n.) nightmare"
   }, 
   {
      id: 4076,
      word: "rogh",
      name: "rogh (v.) ferment"
   }, 
   {
      id: 4077,
      word: "roghmoH",
      name: "roghmoH (v.) cause to ferment"
   }, 
   {
      id: 4078,
      word: "roghvaH",
      name: "roghvaH (n.) population"
   }, 
   {
      id: 4079,
      word: "roj",
      name: "roj (v.) make peace"
   }, 
   {
      id: 4080,
      word: "roj",
      name: "roj (n.) peace"
   }, 
   {
      id: 4081,
      word: "rojHom",
      name: "rojHom (n.) truce"
   }, 
   {
      id: 4082,
      word: "rojche'wI'",
      name: "rojche'wI' (p.n.) James Frederic Bisso"
   }, 
   {
      id: 4083,
      word: "rojmab",
      name: "rojmab (n.) peace treaty"
   }, 
   {
      id: 4084,
      word: "rojpup",
      name: "rojpup (n.) entropy"
   }, 
   {
      id: 4085,
      word: "rojpuqloD",
      name: "rojpuqloD (p.n.) Joel Peter Anderson"
   }, 
   {
      id: 4086,
      word: "rol",
      name: "rol (n.) beard"
   }, 
   {
      id: 4087,
      word: "rom",
      name: "rom (n.) accord"
   }, 
   {
      id: 4088,
      word: "rom'on",
      name: "rom'on (n.) zinc"
   }, 
   {
      id: 4089,
      word: "roma'",
      name: "roma' (n.) Rome"
   }, 
   {
      id: 4090,
      word: "romanI'ya'",
      name: "romanI'ya' (n.) Romania"
   }, 
   {
      id: 4091,
      word: "romta'",
      name: "romta' (n.) octave"
   }, 
   {
      id: 4092,
      word: "romton",
      name: "romton (n.) bracket, corbel"
   }, 
   {
      id: 4093,
      word: "romuluS",
      name: "romuluS (n.) Romulus"
   }, 
   {
      id: 4094,
      word: "romuluSngan",
      name: "romuluSngan (n.) Romulan"
   }, 
   {
      id: 4095,
      word: "ron",
      name: "ron (v.) roll, be rolling"
   }, 
   {
      id: 4096,
      word: "rong",
      name: "rong (v.) roast, grill, broil"
   }, 
   {
      id: 4097,
      word: "ronmoH",
      name: "ronmoH (v.) roll, throw"
   }, 
   {
      id: 4098,
      word: "rop",
      name: "rop (v.) be sick, be ill"
   }, 
   {
      id: 4099,
      word: "rop",
      name: "rop (n.) disease"
   }, 
   {
      id: 4100,
      word: "rop'a'",
      name: "rop'a' (n.) plague, epidemic, pandemic, major disease"
   }, 
   {
      id: 4101,
      word: "roptoj",
      name: "roptoj (n.) scar (result of some sort of disease, infection, etc.)"
   }, 
   {
      id: 4102,
      word: "ropyaH",
      name: "ropyaH (n.) infirmary"
   }, 
   {
      id: 4103,
      word: "ropyaH qach",
      name: "ropyaH qach (n.) hospital"
   }, 
   {
      id: 4104,
      word: "roq",
      name: "roq (v.) fragile, delicate, flimsy"
   }, 
   {
      id: 4105,
      word: "ror",
      name: "ror (v.) be fat, not lean"
   }, 
   {
      id: 4106,
      word: "rorgh",
      name: "rorgh (v.) be fantasy"
   }, 
   {
      id: 4107,
      word: "rotlh",
      name: "rotlh (v.) be tough"
   }, 
   {
      id: 4108,
      word: "rovDurgh",
      name: "rovDurgh (n.) teaching, precept"
   }, 
   {
      id: 4109,
      word: "ru'",
      name: "ru' (v.) be temporary"
   }, 
   {
      id: 4110,
      word: "ru'Ha'",
      name: "ru'Ha' (v.) be permanent"
   }, 
   {
      id: 4111,
      word: "ruDelya' rop'a'",
      name: "ruDelya' rop'a' (n.) Rudellian plague"
   }, 
   {
      id: 4112,
      word: "ruH",
      name: "ruH (v.) blush"
   }, 
   {
      id: 4113,
      word: "ruQ",
      name: "ruQ (v.) control manually, by hand"
   }, 
   {
      id: 4114,
      word: "ruS",
      name: "ruS (n.) bond"
   }, 
   {
      id: 4115,
      word: "ruS",
      name: "ruS (v.) have a positive charge, be positivily charged"
   }, 
   {
      id: 4116,
      word: "ruStay",
      name: "ruStay (n.) bonding ritual"
   }, 
   {
      id: 4117,
      word: "ruSvep",
      name: "ruSvep (n.) invitation"
   }, 
   {
      id: 4118,
      word: "rubyo'",
      name: "rubyo' (n.) politician"
   }, 
   {
      id: 4119,
      word: "ruch",
      name: "ruch (v.) proceed, go ahead, do it"
   }, 
   {
      id: 4120,
      word: "rugh",
      name: "rugh (n.) antimatter"
   }, 
   {
      id: 4121,
      word: "ruj",
      name: "ruj (v.) be physical"
   }, 
   {
      id: 4122,
      word: "run",
      name: "run (v.) be short (in stature)"
   }, 
   {
      id: 4123,
      word: "runpI'",
      name: "runpI' (n.) teapot"
   }, 
   {
      id: 4124,
      word: "rup",
      name: "rup (v.) fine, tax"
   }, 
   {
      id: 4125,
      word: "rup",
      name: "rup (vs2) ready, prepared (referring to beings)"
   }, 
   {
      id: 4126,
      word: "ruq",
      name: "ruq (v.) belch, burp, fart"
   }, 
   {
      id: 4127,
      word: "ruq'e'vet",
      name: "ruq'e'vet (n.) Ruk'evet (city in the Gevchok region)"
   }, 
   {
      id: 4128,
      word: "rur",
      name: "rur (v.) resemble, look like"
   }, 
   {
      id: 4129,
      word: "rura' pente'",
      name: "rura' pente' (p.n.) Rura Penthe (Klingon penal colony)"
   }, 
   {
      id: 4130,
      word: "ruryuD",
      name: "ruryuD (n.) rhinoceros-like animal"
   }, 
   {
      id: 4131,
      word: "rut",
      name: "rut (adverb) sometimes, occasionally"
   }, 
   {
      id: 4132,
      word: "rutlh",
      name: "rutlh (v.) be round"
   }, 
   {
      id: 4133,
      word: "rutlh",
      name: "rutlh (n.) wheel"
   }, 
   {
      id: 4134,
      word: "rutlh 'echlet",
      name: "rutlh 'echlet (n.) skateboard"
   }, 
   {
      id: 4135,
      word: "rutlh chab",
      name: "rutlh chab (n.) donut"
   }, 
   {
      id: 4136,
      word: "rutneD",
      name: "rutneD (n.) hoe"
   }, 
   {
      id: 4137,
      word: "ruv",
      name: "ruv (n.) justice"
   }, 
   {
      id: 4138,
      word: "ruv nay'",
      name: "ruv nay' (n.) dessert"
   }, 
   {
      id: 4139,
      word: "ruwanDa",
      name: "ruwanDa (n.) Rwanda"
   }, 
   {
      id: 4140,
      word: "tI",
      name: "tI (vp) imp: you (s/pl)-them"
   }, 
   {
      id: 4141,
      word: "tI",
      name: "tI (n.) vegetation, plants"
   }, 
   {
      id: 4142,
      word: "tI'",
      name: "tI' (v.) fix, repair"
   }, 
   {
      id: 4143,
      word: "tI'ang",
      name: "tI'ang (p.n.) T'Ong (name of a ship)"
   }, 
   {
      id: 4144,
      word: "tI'qa' vIghro'",
      name: "tI'qa' vIghro' (n.) tika cat, type of animal"
   }, 
   {
      id: 4145,
      word: "tI'rIl",
      name: "tI'rIl (n.) Trill"
   }, 
   {
      id: 4146,
      word: "tI'vIS",
      name: "tI'vIS (p.n.) T'vis"
   }, 
   {
      id: 4147,
      word: "tI'var",
      name: "tI'var (n.) pedal"
   }, 
   {
      id: 4148,
      word: "tI'yap",
      name: "tI'yap (n.) magnesium"
   }, 
   {
      id: 4149,
      word: "tIH",
      name: "tIH (n.) ray"
   }, 
   {
      id: 4150,
      word: "tIH",
      name: "tIH (n.) shaft (of spear)"
   }, 
   {
      id: 4151,
      word: "tIH javmaH",
      name: "tIH javmaH (n.) X-ray"
   }, 
   {
      id: 4152,
      word: "tIH wej",
      name: "tIH wej (n.) gamma ray (ray number 3)"
   }, 
   {
      id: 4153,
      word: "tIHmey",
      name: "tIHmey (n.) train tracks, railroad tracks"
   }, 
   {
      id: 4154,
      word: "tIQ",
      name: "tIQ (v.) be ancient"
   }, 
   {
      id: 4155,
      word: "tIS",
      name: "tIS (v.) be light (weight)"
   }, 
   {
      id: 4156,
      word: "tIch",
      name: "tIch (v.) insult"
   }, 
   {
      id: 4157,
      word: "tIgh",
      name: "tIgh (n.) custom"
   }, 
   {
      id: 4158,
      word: "tIghla'",
      name: "tIghla' (n.) t'gla"
   }, 
   {
      id: 4159,
      word: "tIj",
      name: "tIj (v.) board, go aboard"
   }, 
   {
      id: 4160,
      word: "tIjwI'ghom",
      name: "tIjwI'ghom (n.) boarding party"
   }, 
   {
      id: 4161,
      word: "tIl",
      name: "tIl (v.) salivate"
   }, 
   {
      id: 4162,
      word: "tIlqemchaw'",
      name: "tIlqemchaw' (n.) thingamajig"
   }, 
   {
      id: 4163,
      word: "tIn",
      name: "tIn (v.) be big"
   }, 
   {
      id: 4164,
      word: "tIng",
      name: "tIng (n.) southwestward, area toward the southwest (approx 220 degrees on terran 360 degree compass)"
   }, 
   {
      id: 4165,
      word: "tIngDagh",
      name: "tIngDagh (n.) type of stringed instrument"
   }, 
   {
      id: 4166,
      word: "tInmoH",
      name: "tInmoH (v.) enlarge"
   }, 
   {
      id: 4167,
      word: "tIpqan",
      name: "tIpqan (n.) ash, ashes"
   }, 
   {
      id: 4168,
      word: "tIq",
      name: "tIq (v.) be long, be lengthy (of an object)"
   }, 
   {
      id: 4169,
      word: "tIq",
      name: "tIq (n.) heart"
   }, 
   {
      id: 4170,
      word: "tIqleH",
      name: "tIqleH (n.) tik'leth - An edged weapon similar to Earth long sword."
   }, 
   {
      id: 4171,
      word: "tIqnagh",
      name: "tIqnagh (n.) tknag, type of animal"
   }, 
   {
      id: 4172,
      word: "tIqnagh lemDu'",
      name: "tIqnagh lemDu' (n.) Tknag hooves (food, always plural)"
   }, 
   {
      id: 4173,
      word: "tIquvma",
      name: "tIquvma (p.n.) T'Kuvma"
   }, 
   {
      id: 4174,
      word: "tIr",
      name: "tIr (v.) be arranged in a stack, be superimposed"
   }, 
   {
      id: 4175,
      word: "tIr",
      name: "tIr (n.) grain"
   }, 
   {
      id: 4176,
      word: "tIr ngat",
      name: "tIr ngat (n.) breadcrumbs"
   }, 
   {
      id: 4177,
      word: "tIr ngogh",
      name: "tIr ngogh (n.) bread"
   }, 
   {
      id: 4178,
      word: "tIr ngogh QaD",
      name: "tIr ngogh QaD (n.) toast"
   }, 
   {
      id: 4179,
      word: "tIr ngogh vutwI'",
      name: "tIr ngogh vutwI' (n.) baker (bread)"
   }, 
   {
      id: 4180,
      word: "tIrI'nIDaD tabey'gho je",
      name: "tIrI'nIDaD tabey'gho je (n.) Trinidad and Tobago"
   }, 
   {
      id: 4181,
      word: "tIro'ma Hol",
      name: "tIro'ma Hol (n.) Traumae"
   }, 
   {
      id: 4182,
      word: "tIv",
      name: "tIv (v.) enjoy"
   }, 
   {
      id: 4183,
      word: "tIw",
      name: "tIw (v.) react emotionally, behave emotionally"
   }, 
   {
      id: 4184,
      word: "tIy",
      name: "tIy (v.) be curly"
   }, 
   {
      id: 4185,
      word: "ta",
      name: "ta (n.) record"
   }, 
   {
      id: 4186,
      word: "ta'",
      name: "ta' (v.) accomplish"
   }, 
   {
      id: 4187,
      word: "ta'",
      name: "ta' (vs7) accomplished, done (aspect marker)"
   }, 
   {
      id: 4188,
      word: "ta'",
      name: "ta' (n.) deed, accomplishment"
   }, 
   {
      id: 4189,
      word: "ta'",
      name: "ta' (n.) emperor"
   }, 
   {
      id: 4190,
      word: "ta' Hol",
      name: "ta' Hol (n.) standard dialect"
   }, 
   {
      id: 4191,
      word: "ta' tlhIngan Hol",
      name: "ta' tlhIngan Hol (n.) standard dialect"
   }, 
   {
      id: 4192,
      word: "ta'SIghor",
      name: "ta'SIghor (p.n.) Kevin A. Geiselman's House"
   }, 
   {
      id: 4193,
      word: "ta'qo",
      name: "ta'qo (n.) taco"
   }, 
   {
      id: 4194,
      word: "ta'tuy",
      name: "ta'tuy (n.) emperorship"
   }, 
   {
      id: 4195,
      word: "taD",
      name: "taD (v.) be frozen"
   }, 
   {
      id: 4196,
      word: "taDmoH",
      name: "taDmoH (v.) freeze"
   }, 
   {
      id: 4197,
      word: "taH",
      name: "taH (v.) be at a negative angle"
   }, 
   {
      id: 4198,
      word: "taH",
      name: "taH (v.) continue, go on, endure, survive"
   }, 
   {
      id: 4199,
      word: "taH",
      name: "taH (vs7) continuous (aspect marker)"
   }, 
   {
      id: 4200,
      word: "taHqeq",
      name: "taHqeq (exclamation) (curse) epithet, insult"
   }, 
   {
      id: 4201,
      word: "taQ",
      name: "taQ (v.) be weird, bizarre, unnatural, maybe creepy"
   }, 
   {
      id: 4202,
      word: "taQbang",
      name: "taQbang (n.) exhaust"
   }, 
   {
      id: 4203,
      word: "taQbang",
      name: "taQbang (n.) slang for urine and/or fecal matter"
   }, 
   {
      id: 4204,
      word: "taS",
      name: "taS (n.) solution (liquid)"
   }, 
   {
      id: 4205,
      word: "taSman",
      name: "taSman (n.) ditch"
   }, 
   {
      id: 4206,
      word: "tab",
      name: "tab (v.) wane, ebb, dwindle (moon phases)"
   }, 
   {
      id: 4207,
      word: "tabHa'",
      name: "tabHa' (v.) wax (moon phase)"
   }, 
   {
      id: 4208,
      word: "tach",
      name: "tach (n.) bar, saloon, cocktail lounge"
   }, 
   {
      id: 4209,
      word: "tach",
      name: "tach (v.) turn over"
   }, 
   {
      id: 4210,
      word: "tagh",
      name: "tagh (v.) begin a process, initiate (proceedings), start a process"
   }, 
   {
      id: 4211,
      word: "tagh",
      name: "tagh (n.) lung"
   }, 
   {
      id: 4212,
      word: "tagha'",
      name: "tagha' (adverb) finally, at last"
   }, 
   {
      id: 4213,
      word: "taghqIj",
      name: "taghqIj (p.n.) Matt Treyvaud"
   }, 
   {
      id: 4214,
      word: "taj",
      name: "taj (n.) knife, dagger"
   }, 
   {
      id: 4215,
      word: "taj Hol",
      name: "taj Hol (n.) propaganda"
   }, 
   {
      id: 4216,
      word: "taj'IH",
      name: "taj'IH (p.n.) Astrid Jekat"
   }, 
   {
      id: 4217,
      word: "tajHommey",
      name: "tajHommey (n.) retractable small blades on a d'k tagh knife"
   }, 
   {
      id: 4218,
      word: "tajtIq",
      name: "tajtIq (n.) long bladed knife that is used like a sword"
   }, 
   {
      id: 4219,
      word: "tajvaj",
      name: "tajvaj (n.) angle"
   }, 
   {
      id: 4220,
      word: "tajvaj",
      name: "tajvaj (n.) corner of a room"
   }, 
   {
      id: 4221,
      word: "tal",
      name: "tal (n.) cannon"
   }, 
   {
      id: 4222,
      word: "talarngan",
      name: "talarngan (n.) Talarian (person)"
   }, 
   {
      id: 4223,
      word: "tallIt",
      name: "tallIt (n.) cobalt"
   }, 
   {
      id: 4224,
      word: "tam",
      name: "tam (v.) be quiet"
   }, 
   {
      id: 4225,
      word: "tam",
      name: "tam (v.) exchange, substitute"
   }, 
   {
      id: 4226,
      word: "tamghay",
      name: "tamghay (n.) light, luminescence, illumination"
   }, 
   {
      id: 4227,
      word: "tamghayQeD",
      name: "tamghayQeD (n.) optics"
   }, 
   {
      id: 4228,
      word: "tamler",
      name: "tamler (n.) element (in chemistry)"
   }, 
   {
      id: 4229,
      word: "tamler Sar",
      name: "tamler Sar (n.) isotope"
   }, 
   {
      id: 4230,
      word: "tamler qurme'mey",
      name: "tamler qurme'mey (n.) chemical formula"
   }, 
   {
      id: 4231,
      word: "tamler vInDa'",
      name: "tamler vInDa' (n.) isotope"
   }, 
   {
      id: 4232,
      word: "tamler wa'chaw",
      name: "tamler wa'chaw (n.) periodic table of the elements"
   }, 
   {
      id: 4233,
      word: "tamlerQeD",
      name: "tamlerQeD (n.) chemistry"
   }, 
   {
      id: 4234,
      word: "tammoH",
      name: "tammoH (v.) silence"
   }, 
   {
      id: 4235,
      word: "tanSanI'ya",
      name: "tanSanI'ya (n.) Tanzania"
   }, 
   {
      id: 4236,
      word: "tang",
      name: "tang (v.) trip, stumble"
   }, 
   {
      id: 4237,
      word: "tangqa'",
      name: "tangqa' (n.) bull-like animal, tangkar"
   }, 
   {
      id: 4238,
      word: "tanje'rIn",
      name: "tanje'rIn (n.) tangerine, clementine, orange-like fruit"
   }, 
   {
      id: 4239,
      word: "tap",
      name: "tap (v.) mash, squash"
   }, 
   {
      id: 4240,
      word: "tapqej",
      name: "tapqej (n.) cherry"
   }, 
   {
      id: 4241,
      word: "taq",
      name: "taq (v.) be scarred"
   }, 
   {
      id: 4242,
      word: "taq'ev",
      name: "taq'ev (n.) Take'ev (city or region)"
   }, 
   {
      id: 4243,
      word: "taqmoH",
      name: "taqmoH (v.) scar"
   }, 
   {
      id: 4244,
      word: "taqnar",
      name: "taqnar (n.) taknar, type of animal"
   }, 
   {
      id: 4245,
      word: "tar",
      name: "tar (n.) poison"
   }, 
   {
      id: 4246,
      word: "tarDIghaD",
      name: "tarDIghaD (n.) tardigrade"
   }, 
   {
      id: 4247,
      word: "targh",
      name: "targh (n.) targ"
   }, 
   {
      id: 4248,
      word: "targh tIq",
      name: "targh tIq (n.) heart of targ (food)"
   }, 
   {
      id: 4249,
      word: "targho'nI'",
      name: "targho'nI' (n.) tungsten (element)"
   }, 
   {
      id: 4250,
      word: "targhoroj",
      name: "targhoroj (n.) crab"
   }, 
   {
      id: 4251,
      word: "targhtlhuH",
      name: "targhtlhuH (p.n.) Bryce Platt"
   }, 
   {
      id: 4252,
      word: "tarleq",
      name: "tarleq (n.) herb"
   }, 
   {
      id: 4253,
      word: "tarngeb",
      name: "tarngeb (n.) uranium (element)"
   }, 
   {
      id: 4254,
      word: "tat",
      name: "tat (n.) ion"
   }, 
   {
      id: 4255,
      word: "tat taS",
      name: "tat taS (n.) electrolyte"
   }, 
   {
      id: 4256,
      word: "tatlh",
      name: "tatlh (v.) return (something)"
   }, 
   {
      id: 4257,
      word: "tav",
      name: "tav (v.) shake"
   }, 
   {
      id: 4258,
      word: "tav neH",
      name: "tav neH (v.) tinker (slang)"
   }, 
   {
      id: 4259,
      word: "taw",
      name: "taw (n.) road, street, path, etc (physical version of He)"
   }, 
   {
      id: 4260,
      word: "taw 'ay'",
      name: "taw 'ay' (n.) block (city block)"
   }, 
   {
      id: 4261,
      word: "taw'",
      name: "taw' (v.) be ridgy, embossed"
   }, 
   {
      id: 4262,
      word: "tawI'yan",
      name: "tawI'yan (n.) Tawi'yan"
   }, 
   {
      id: 4263,
      word: "tawleHnu'",
      name: "tawleHnu' (n.) hopeless situation"
   }, 
   {
      id: 4264,
      word: "tawleHnu' pogh",
      name: "tawleHnu' pogh (n.) emphatically hopeless situation"
   }, 
   {
      id: 4265,
      word: "tay",
      name: "tay (v.) be civilized"
   }, 
   {
      id: 4266,
      word: "tay",
      name: "tay (n.) ceremony, rite, ritual, honorific tai"
   }, 
   {
      id: 4267,
      word: "tay'",
      name: "tay' (v.) be together"
   }, 
   {
      id: 4268,
      word: "taygher",
      name: "taygher (n.) tiger"
   }, 
   {
      id: 4269,
      word: "taymey",
      name: "taymey (n.) section of a book or play or the like that's separate from the main portion of the work"
   }, 
   {
      id: 4270,
      word: "taymoH",
      name: "taymoH (v.) civilize"
   }, 
   {
      id: 4271,
      word: "tayqeq",
      name: "tayqeq (n.) civilization"
   }, 
   {
      id: 4272,
      word: "te'nIS",
      name: "te'nIS (n.) tennis"
   }, 
   {
      id: 4273,
      word: "teH",
      name: "teH (v.) be true"
   }, 
   {
      id: 4274,
      word: "teQ",
      name: "teQ (v.) assume"
   }, 
   {
      id: 4275,
      word: "teS",
      name: "teS (n.) ear (internal organ of hearing, inside head)"
   }, 
   {
      id: 4276,
      word: "teSra'",
      name: "teSra' (n.) tile (such as a Scrabble piece)"
   }, 
   {
      id: 4277,
      word: "teb",
      name: "teb (v.) fill"
   }, 
   {
      id: 4278,
      word: "teblaw'",
      name: "teblaw' (n.) jurisdiction"
   }, 
   {
      id: 4279,
      word: "tebwI'",
      name: "tebwI' (n.) food server in a Dok'e (fast-food restaurant)"
   }, 
   {
      id: 4280,
      word: "teghbat",
      name: "teghbat (n.) teg'bat, type of animal"
   }, 
   {
      id: 4281,
      word: "tej",
      name: "tej (n.) scientist"
   }, 
   {
      id: 4282,
      word: "tel",
      name: "tel (n.) wing"
   }, 
   {
      id: 4283,
      word: "tel'em",
      name: "tel'em (n.) mentor"
   }, 
   {
      id: 4284,
      word: "tellarngan",
      name: "tellarngan (n.) Tellarite"
   }, 
   {
      id: 4285,
      word: "telun Hovtay'",
      name: "telun Hovtay' (n.) Tellun Star System"
   }, 
   {
      id: 4286,
      word: "telya'",
      name: "telya' (n.) pancreas"
   }, 
   {
      id: 4287,
      word: "tem",
      name: "tem (v.) deny, contradict, disavow, claim as false"
   }, 
   {
      id: 4288,
      word: "tem",
      name: "tem (n.) electron"
   }, 
   {
      id: 4289,
      word: "tem chIjwI'",
      name: "tem chIjwI' (n.) diode"
   }, 
   {
      id: 4290,
      word: "tem lISwI'",
      name: "tem lISwI' (n.) transistor"
   }, 
   {
      id: 4291,
      word: "ten",
      name: "ten (v.) embark"
   }, 
   {
      id: 4292,
      word: "tengchaH",
      name: "tengchaH (n.) space station"
   }, 
   {
      id: 4293,
      word: "tennuS",
      name: "tennuS (n.) uncle, father's brother"
   }, 
   {
      id: 4294,
      word: "tennuSnal",
      name: "tennuSnal (n.) uncle, father's sister's husband"
   }, 
   {
      id: 4295,
      word: "tenwal",
      name: "tenwal (n.) page (in a book)"
   }, 
   {
      id: 4296,
      word: "tep",
      name: "tep (n.) cargo"
   }, 
   {
      id: 4297,
      word: "tepqengwI'",
      name: "tepqengwI' (n.) cargo carrier, cargo lift"
   }, 
   {
      id: 4298,
      word: "teq",
      name: "teq (v.) remove, take off"
   }, 
   {
      id: 4299,
      word: "teqSaS",
      name: "teqSaS (n.) Texas"
   }, 
   {
      id: 4300,
      word: "ter'eS",
      name: "ter'eS (p.n.) Terry Donnelly"
   }, 
   {
      id: 4301,
      word: "tera'",
      name: "tera' (n.) Earth"
   }, 
   {
      id: 4302,
      word: "tera' 'Insong majaj",
      name: "tera' 'Insong majaj (n.) cauliflower"
   }, 
   {
      id: 4303,
      word: "tera' 'arDeH",
      name: "tera' 'arDeH (n.) ivy (Terran)"
   }, 
   {
      id: 4304,
      word: "tera' 'oQqar qIj",
      name: "tera' 'oQqar qIj (n.) licorice (candy)"
   }, 
   {
      id: 4305,
      word: "tera' bIQ lung'a'",
      name: "tera' bIQ lung'a' (n.) alligator, crocodile"
   }, 
   {
      id: 4306,
      word: "tera' chuch mIl'oD",
      name: "tera' chuch mIl'oD (n.) polar bear"
   }, 
   {
      id: 4307,
      word: "tera' ghIch rop",
      name: "tera' ghIch rop (n.) common cold"
   }, 
   {
      id: 4308,
      word: "tera' majaj tIy",
      name: "tera' majaj tIy (n.) kale"
   }, 
   {
      id: 4309,
      word: "tera' na'ran",
      name: "tera' na'ran (n.) orange (fruit)"
   }, 
   {
      id: 4310,
      word: "tera' na'ran HuH",
      name: "tera' na'ran HuH (n.) marmalade"
   }, 
   {
      id: 4311,
      word: "tera' na'ran chang",
      name: "tera' na'ran chang (n.) marmalade"
   }, 
   {
      id: 4312,
      word: "tera' na'ran wIb",
      name: "tera' na'ran wIb (n.) lemon"
   }, 
   {
      id: 4313,
      word: "tera' na'ran wIblaw'",
      name: "tera' na'ran wIblaw' (n.) lime (fruit)"
   }, 
   {
      id: 4314,
      word: "tera' na'ran'a'",
      name: "tera' na'ran'a' (n.) grapefruit"
   }, 
   {
      id: 4315,
      word: "tera' peb'ot",
      name: "tera' peb'ot (n.) cucumber"
   }, 
   {
      id: 4316,
      word: "tera' qaw",
      name: "tera' qaw (n.) cow"
   }, 
   {
      id: 4317,
      word: "tera' qaw Ha'DIbaH",
      name: "tera' qaw Ha'DIbaH (n.) beef"
   }, 
   {
      id: 4318,
      word: "tera' targh",
      name: "tera' targh (n.) pig"
   }, 
   {
      id: 4319,
      word: "tera' targh Ha'DIbaH",
      name: "tera' targh Ha'DIbaH (n.) pork"
   }, 
   {
      id: 4320,
      word: "tera' tlhuH rop",
      name: "tera' tlhuH rop (n.) common cold"
   }, 
   {
      id: 4321,
      word: "tera' yav 'atlhqam",
      name: "tera' yav 'atlhqam (n.) mushroom"
   }, 
   {
      id: 4322,
      word: "tera'ngan",
      name: "tera'ngan (n.) Terran, Earther"
   }, 
   {
      id: 4323,
      word: "tet",
      name: "tet (v.) melt"
   }, 
   {
      id: 4324,
      word: "tetlh",
      name: "tetlh (v.) roll"
   }, 
   {
      id: 4325,
      word: "tetlh",
      name: "tetlh (n.) roll, list, scroll (not the writing surface)"
   }, 
   {
      id: 4326,
      word: "tetyub",
      name: "tetyub (n.) enamel, coating"
   }, 
   {
      id: 4327,
      word: "tev",
      name: "tev (n.) prize"
   }, 
   {
      id: 4328,
      word: "tevram",
      name: "tevram (p.n.) Susan Farmer"
   }, 
   {
      id: 4329,
      word: "tew",
      name: "tew (v.) be entwined, entwine"
   }, 
   {
      id: 4330,
      word: "tey",
      name: "tey (v.) scrape, be uncomfortably close (slang)"
   }, 
   {
      id: 4331,
      word: "tey'",
      name: "tey' (v.) confide"
   }, 
   {
      id: 4332,
      word: "tey'",
      name: "tey' (n.) cousin (mother's sister's child or father's brother's child), niece or nephew (man's brother's child"
   }, 
   {
      id: 4333,
      word: "tey'be'",
      name: "tey'be' (n.) female cousin (mother's sister's child or father's brother's child), niece (man's brother's daughter"
   }, 
   {
      id: 4334,
      word: "tey'loD",
      name: "tey'loD (n.) male cousin (mother's sister's son or father's brother's son), nephew (man's brother's son or woman'"
   }, 
   {
      id: 4335,
      word: "teybe'",
      name: "teybe' (v.) be comfortable, be easy"
   }, 
   {
      id: 4336,
      word: "teywI'",
      name: "teywI' (n.) file"
   }, 
   {
      id: 4337,
      word: "teywI' 'echlet",
      name: "teywI' 'echlet (n.) chalkboard or whiteboard or any similar surface that can be erased and reused"
   }, 
   {
      id: 4338,
      word: "tlhI'",
      name: "tlhI' (v.) sign, autograph"
   }, 
   {
      id: 4339,
      word: "tlhI'",
      name: "tlhI' (n.) signature, autograph"
   }, 
   {
      id: 4340,
      word: "tlhIH",
      name: "tlhIH (pronoun) you (pl)"
   }, 
   {
      id: 4341,
      word: "tlhIS",
      name: "tlhIS (v.) spit out"
   }, 
   {
      id: 4342,
      word: "tlhIb",
      name: "tlhIb (v.) be incompetent, be not skilled"
   }, 
   {
      id: 4343,
      word: "tlhIch",
      name: "tlhIch (n.) smoke"
   }, 
   {
      id: 4344,
      word: "tlhIghaq",
      name: "tlhIghaq (n.) trigak, type of animal"
   }, 
   {
      id: 4345,
      word: "tlhIj",
      name: "tlhIj (v.) apologize"
   }, 
   {
      id: 4346,
      word: "tlhIl",
      name: "tlhIl (v.) mine"
   }, 
   {
      id: 4347,
      word: "tlhIl",
      name: "tlhIl (n.) mineral"
   }, 
   {
      id: 4348,
      word: "tlhIlHal",
      name: "tlhIlHal (n.) mine"
   }, 
   {
      id: 4349,
      word: "tlhIlwI'",
      name: "tlhIlwI' (n.) miner"
   }, 
   {
      id: 4350,
      word: "tlhIm",
      name: "tlhIm (n.) carpet, rug, blanket, fabric wall hanging"
   }, 
   {
      id: 4351,
      word: "tlhImqaH",
      name: "tlhImqaH (n.) type of food, zilm'kach"
   }, 
   {
      id: 4352,
      word: "tlhIn",
      name: "tlhIn (v.) be particular, individual"
   }, 
   {
      id: 4353,
      word: "tlhIneng",
      name: "tlhIneng (n.) potassium"
   }, 
   {
      id: 4354,
      word: "tlhIng yoS",
      name: "tlhIng yoS (p.n.) Kling District"
   }, 
   {
      id: 4355,
      word: "tlhIngan",
      name: "tlhIngan (n.) Klingon"
   }, 
   {
      id: 4356,
      word: "tlhIngan 'IH qaD",
      name: "tlhIngan 'IH qaD (n.) Klingon beauty contest"
   }, 
   {
      id: 4357,
      word: "tlhIngan Hubbeq",
      name: "tlhIngan Hubbeq (n.) Klingon Defense Force"
   }, 
   {
      id: 4358,
      word: "tlhIngan wo'",
      name: "tlhIngan wo' (n.) Klingon Empire"
   }, 
   {
      id: 4359,
      word: "tlhIngan yejquv",
      name: "tlhIngan yejquv (n.) Klingon High Council"
   }, 
   {
      id: 4360,
      word: "tlhInja",
      name: "tlhInja (n.) Klin Zha"
   }, 
   {
      id: 4361,
      word: "tlhIq",
      name: "tlhIq (n.) stew"
   }, 
   {
      id: 4362,
      word: "tlhIv",
      name: "tlhIv (v.) be insubordinate"
   }, 
   {
      id: 4363,
      word: "tlha",
      name: "tlha (p.n.) Klaa"
   }, 
   {
      id: 4364,
      word: "tlha'",
      name: "tlha' (v.) chase, follow"
   }, 
   {
      id: 4365,
      word: "tlha'a",
      name: "tlha'a (p.n.) Klaa"
   }, 
   {
      id: 4366,
      word: "tlhaQ",
      name: "tlhaQ (v.) be funny"
   }, 
   {
      id: 4367,
      word: "tlhaS",
      name: "tlhaS (v.) fight, battle (relatively minor fight)"
   }, 
   {
      id: 4368,
      word: "tlhab",
      name: "tlhab (v.) be free, be independent"
   }, 
   {
      id: 4369,
      word: "tlhab",
      name: "tlhab (n.) freedom, independence"
   }, 
   {
      id: 4370,
      word: "tlhach",
      name: "tlhach (n.) faction, sect"
   }, 
   {
      id: 4371,
      word: "tlhach mu'mey",
      name: "tlhach mu'mey (n.) argot, jargon"
   }, 
   {
      id: 4372,
      word: "tlhach mu'mey",
      name: "tlhach mu'mey (n.) jargon"
   }, 
   {
      id: 4373,
      word: "tlhagh",
      name: "tlhagh (n.) fat from an animal"
   }, 
   {
      id: 4374,
      word: "tlhaghnay",
      name: "tlhaghnay (n.) Throgni"
   }, 
   {
      id: 4375,
      word: "tlhaj",
      name: "tlhaj (v.) process, parade, march"
   }, 
   {
      id: 4376,
      word: "tlham",
      name: "tlham (n.) gravity"
   }, 
   {
      id: 4377,
      word: "tlham",
      name: "tlham (n.) order, structure (societal) (slang)"
   }, 
   {
      id: 4378,
      word: "tlham",
      name: "tlham (v.) slide"
   }, 
   {
      id: 4379,
      word: "tlham rI'gheS",
      name: "tlham rI'gheS (n.) parachute"
   }, 
   {
      id: 4380,
      word: "tlhamI'",
      name: "tlhamI' (n.) geode"
   }, 
   {
      id: 4381,
      word: "tlhamchem",
      name: "tlhamchem (n.) gravitational field"
   }, 
   {
      id: 4382,
      word: "tlhan",
      name: "tlhan (v.) dig"
   }, 
   {
      id: 4383,
      word: "tlhap",
      name: "tlhap (v.) take"
   }, 
   {
      id: 4384,
      word: "tlhapqa'",
      name: "tlhapqa' (v.) retrieve, take again, resume taking"
   }, 
   {
      id: 4385,
      word: "tlhapragh",
      name: "tlhapragh (n.) monster"
   }, 
   {
      id: 4386,
      word: "tlhaq",
      name: "tlhaq (n.) chronometer, clock"
   }, 
   {
      id: 4387,
      word: "tlhar",
      name: "tlhar (v.) be allergic, be allergic to"
   }, 
   {
      id: 4388,
      word: "tlhargh",
      name: "tlhargh (v.) explore"
   }, 
   {
      id: 4389,
      word: "tlharwIl",
      name: "tlharwIl (n.) episode in a TV show"
   }, 
   {
      id: 4390,
      word: "tlharwIl",
      name: "tlharwIl (n.) link in a chain"
   }, 
   {
      id: 4391,
      word: "tlharwIl Duj",
      name: "tlharwIl Duj (n.) train car, railroad car"
   }, 
   {
      id: 4392,
      word: "tlhat",
      name: "tlhat (n.) grid"
   }, 
   {
      id: 4393,
      word: "tlhatlh",
      name: "tlhatlh (n.) type of food, gladst"
   }, 
   {
      id: 4394,
      word: "tlhavqop",
      name: "tlhavqop (n.) punctuation"
   }, 
   {
      id: 4395,
      word: "tlhaw",
      name: "tlhaw (v.) be inflamed"
   }, 
   {
      id: 4396,
      word: "tlhaw'",
      name: "tlhaw' (v.) hit (percussion instrument) with fist"
   }, 
   {
      id: 4397,
      word: "tlhaw'DIyuS",
      name: "tlhaw'DIyuS (p.n.) Claudius"
   }, 
   {
      id: 4398,
      word: "tlhawjoq",
      name: "tlhawjoq (n.) mantle (geology)"
   }, 
   {
      id: 4399,
      word: "tlhay",
      name: "tlhay (v.) embalm"
   }, 
   {
      id: 4400,
      word: "tlhay",
      name: "tlhay (n.) sleeve"
   }, 
   {
      id: 4401,
      word: "tlhay'",
      name: "tlhay' (v.) be tame, domesticated"
   }, 
   {
      id: 4402,
      word: "tlhay'qeq",
      name: "tlhay'qeq (n.) domestication"
   }, 
   {
      id: 4403,
      word: "tlhe'",
      name: "tlhe' (v.) turn"
   }, 
   {
      id: 4404,
      word: "tlheD",
      name: "tlheD (v.) depart"
   }, 
   {
      id: 4405,
      word: "tlheH",
      name: "tlheH (n.) spell (magical)"
   }, 
   {
      id: 4406,
      word: "tlheb",
      name: "tlheb (v.) urge, advocate, endorse"
   }, 
   {
      id: 4407,
      word: "tlhech",
      name: "tlhech (v.) investigate"
   }, 
   {
      id: 4408,
      word: "tlhechwI'",
      name: "tlhechwI' (n.) investigator"
   }, 
   {
      id: 4409,
      word: "tlhegh",
      name: "tlhegh (n.) line, rope"
   }, 
   {
      id: 4410,
      word: "tlhegh jIrmoHwI'",
      name: "tlhegh jIrmoHwI' (n.) windlass (literally: rope twister/rotator)"
   }, 
   {
      id: 4411,
      word: "tlheghmeQ",
      name: "tlheghmeQ (p.n.) Elizabeth C. Hoyt"
   }, 
   {
      id: 4412,
      word: "tlhej",
      name: "tlhej (v.) accompany"
   }, 
   {
      id: 4413,
      word: "tlhemqaDID",
      name: "tlhemqaDID (n.) bumpkin, yokel"
   }, 
   {
      id: 4414,
      word: "tlhen",
      name: "tlhen (v.) sound as, produce the sound of"
   }, 
   {
      id: 4415,
      word: "tlheng'IQ",
      name: "tlheng'IQ (n.) thranx plant"
   }, 
   {
      id: 4416,
      word: "tlhep",
      name: "tlhep (v.) be suspended, be dangling, be straight (hair)"
   }, 
   {
      id: 4417,
      word: "tlhepQe'",
      name: "tlhepQe' (n.) saliva"
   }, 
   {
      id: 4418,
      word: "tlher",
      name: "tlher (v.) be lumpy"
   }, 
   {
      id: 4419,
      word: "tlher'aq",
      name: "tlher'aq (n.) reef"
   }, 
   {
      id: 4420,
      word: "tlhetlh",
      name: "tlhetlh (v.) progress"
   }, 
   {
      id: 4421,
      word: "tlhevjaQ",
      name: "tlhevjaQ (n.) spear thrown with aid of a special tool"
   }, 
   {
      id: 4422,
      word: "tlhey'at",
      name: "tlhey'at (n.) spacetime"
   }, 
   {
      id: 4423,
      word: "tlho'",
      name: "tlho' (n.) appreciation, gratitude"
   }, 
   {
      id: 4424,
      word: "tlho'",
      name: "tlho' (v.) thank"
   }, 
   {
      id: 4425,
      word: "tlho' Huch",
      name: "tlho' Huch (n.) tip"
   }, 
   {
      id: 4426,
      word: "tlho'ren",
      name: "tlho'ren (n.) unit measure approx. one quart/litre"
   }, 
   {
      id: 4427,
      word: "tlhoD",
      name: "tlhoD (v.) be somewhat obscured, filtered, smudged, fuzzy"
   }, 
   {
      id: 4428,
      word: "tlhoQ",
      name: "tlhoQ (n.) conglomeration"
   }, 
   {
      id: 4429,
      word: "tlhoS",
      name: "tlhoS (adverb) almost, nearly, virtually, not quite, barely"
   }, 
   {
      id: 4430,
      word: "tlhob",
      name: "tlhob (v.) ask, request, plead"
   }, 
   {
      id: 4431,
      word: "tlhoch",
      name: "tlhoch (v.) contradict"
   }, 
   {
      id: 4432,
      word: "tlhogh",
      name: "tlhogh (v.) get married to, marry"
   }, 
   {
      id: 4433,
      word: "tlhogh",
      name: "tlhogh (n.) marriage"
   }, 
   {
      id: 4434,
      word: "tlhoj",
      name: "tlhoj (v.) realize"
   }, 
   {
      id: 4435,
      word: "tlhol",
      name: "tlhol (v.) be raw, be unprocessed"
   }, 
   {
      id: 4436,
      word: "tlhom",
      name: "tlhom (n.) dusk"
   }, 
   {
      id: 4437,
      word: "tlhom chum",
      name: "tlhom chum (n.) sunset (colourful sky seen at dusk)"
   }, 
   {
      id: 4438,
      word: "tlhombuS",
      name: "tlhombuS (n.) type of food, Klombus"
   }, 
   {
      id: 4439,
      word: "tlhon",
      name: "tlhon (n.) nostril"
   }, 
   {
      id: 4440,
      word: "tlhong",
      name: "tlhong (v.) barter, bargain"
   }, 
   {
      id: 4441,
      word: "tlhonghaD",
      name: "tlhonghaD (n.) klongat, type of animal"
   }, 
   {
      id: 4442,
      word: "tlhop",
      name: "tlhop (n.) front, area in front of"
   }, 
   {
      id: 4443,
      word: "tlhop",
      name: "tlhop (n.) public area"
   }, 
   {
      id: 4444,
      word: "tlhoqtlhal",
      name: "tlhoqtlhal (n.) favor"
   }, 
   {
      id: 4445,
      word: "tlhorgh",
      name: "tlhorgh (v.) be pungent (referring to food)"
   }, 
   {
      id: 4446,
      word: "tlhorghHa'",
      name: "tlhorghHa' (v.) be bland (referring to food)"
   }, 
   {
      id: 4447,
      word: "tlhot",
      name: "tlhot (v.) land on water (like a bird)"
   }, 
   {
      id: 4448,
      word: "tlhov",
      name: "tlhov (v.) wheeze"
   }, 
   {
      id: 4449,
      word: "tlhoy",
      name: "tlhoy (adverb) overly, to an excessive degree, excessively, too much"
   }, 
   {
      id: 4450,
      word: "tlhoy'",
      name: "tlhoy' (n.) wall, interior wall, interior face of exterior wall, territorial wall"
   }, 
   {
      id: 4451,
      word: "tlhoy' SaS",
      name: "tlhoy' SaS (n.) ceiling/floor between storeys"
   }, 
   {
      id: 4452,
      word: "tlhu'",
      name: "tlhu' (v.) be tempted"
   }, 
   {
      id: 4453,
      word: "tlhu'moH",
      name: "tlhu'moH (v.) tempt"
   }, 
   {
      id: 4454,
      word: "tlhu'roD",
      name: "tlhu'roD (n.) martyr"
   }, 
   {
      id: 4455,
      word: "tlhuD",
      name: "tlhuD (v.) emit (energy, radiation, etc.)"
   }, 
   {
      id: 4456,
      word: "tlhuDwI'",
      name: "tlhuDwI' (n.) slang for microwave device"
   }, 
   {
      id: 4457,
      word: "tlhuH",
      name: "tlhuH (v.) be exhilarated (slang), be stimulated (slang), be invigorated (slang)"
   }, 
   {
      id: 4458,
      word: "tlhuH",
      name: "tlhuH (n.) breath"
   }, 
   {
      id: 4459,
      word: "tlhuH",
      name: "tlhuH (v.) breathe"
   }, 
   {
      id: 4460,
      word: "tlhuHtuch",
      name: "tlhuHtuch (n.) armadillo-like creature"
   }, 
   {
      id: 4461,
      word: "tlhuQ",
      name: "tlhuQ (n.) tail"
   }, 
   {
      id: 4462,
      word: "tlhub",
      name: "tlhub (n.) climax"
   }, 
   {
      id: 4463,
      word: "tlhuch",
      name: "tlhuch (v.) exhaust"
   }, 
   {
      id: 4464,
      word: "tlhugh",
      name: "tlhugh (n.) a genre of music"
   }, 
   {
      id: 4465,
      word: "tlhum",
      name: "tlhum (v.) be constrained, bound"
   }, 
   {
      id: 4466,
      word: "tlhup",
      name: "tlhup (v.) whisper"
   }, 
   {
      id: 4467,
      word: "tlhur",
      name: "tlhur (v.) catch"
   }, 
   {
      id: 4468,
      word: "tlhut",
      name: "tlhut (v.) be stuffed"
   }, 
   {
      id: 4469,
      word: "tlhutlh",
      name: "tlhutlh (v.) drink"
   }, 
   {
      id: 4470,
      word: "to'",
      name: "to' (n.) tactics"
   }, 
   {
      id: 4471,
      word: "to'a'",
      name: "to'a' (n.) tangent (curve)"
   }, 
   {
      id: 4472,
      word: "to'baj",
      name: "to'baj (n.) tobbaj, type of animal"
   }, 
   {
      id: 4473,
      word: "to'nga",
      name: "to'nga (n.) Tonga"
   }, 
   {
      id: 4474,
      word: "to'qIpo'na Hol",
      name: "to'qIpo'na Hol (n.) Toki Pona"
   }, 
   {
      id: 4475,
      word: "to'ratlh",
      name: "to'ratlh (p.n.) Torath"
   }, 
   {
      id: 4476,
      word: "to'waQ",
      name: "to'waQ (n.) ligament, tendon"
   }, 
   {
      id: 4477,
      word: "toD",
      name: "toD (n.) rescue"
   }, 
   {
      id: 4478,
      word: "toD",
      name: "toD (v.) rescue, save"
   }, 
   {
      id: 4479,
      word: "toDDuj",
      name: "toDDuj (n.) rescue ship"
   }, 
   {
      id: 4480,
      word: "toDSaH",
      name: "toDSaH (exclamation) (curse) epithet, insult"
   }, 
   {
      id: 4481,
      word: "toDbaj",
      name: "toDbaj (p.n.) Michael McConnell"
   }, 
   {
      id: 4482,
      word: "toDuj",
      name: "toDuj (n.) courage, bravery"
   }, 
   {
      id: 4483,
      word: "toH",
      name: "toH (exclamation) so, well, aha!"
   }, 
   {
      id: 4484,
      word: "toQ",
      name: "toQ (n.) a bird of prey"
   }, 
   {
      id: 4485,
      word: "toQDuj",
      name: "toQDuj (n.) Bird of Prey (ship, vessel)"
   }, 
   {
      id: 4486,
      word: "toS",
      name: "toS (v.) climb"
   }, 
   {
      id: 4487,
      word: "toSwI' qal'aq",
      name: "toSwI' qal'aq (n.) climbing frame, jungle gym"
   }, 
   {
      id: 4488,
      word: "tob",
      name: "tob (v.) prove"
   }, 
   {
      id: 4489,
      word: "toba'qo",
      name: "toba'qo (n.) tobacco"
   }, 
   {
      id: 4490,
      word: "toch",
      name: "toch (v.) be actual, be concrete, be practical, be pragmatic, be applied"
   }, 
   {
      id: 4491,
      word: "toch",
      name: "toch (n.) palm (of hand)"
   }, 
   {
      id: 4492,
      word: "tochmu'",
      name: "tochmu' (n.) bribe"
   }, 
   {
      id: 4493,
      word: "togh",
      name: "togh (v.) count"
   }, 
   {
      id: 4494,
      word: "togho",
      name: "togho (n.) Togo"
   }, 
   {
      id: 4495,
      word: "toj",
      name: "toj (v.) deceive, trick, bluff"
   }, 
   {
      id: 4496,
      word: "tojbogh pa'",
      name: "tojbogh pa' (n.) holodeck"
   }, 
   {
      id: 4497,
      word: "tol",
      name: "tol (v.) go through, pass through, pass among"
   }, 
   {
      id: 4498,
      word: "tom",
      name: "tom (v.) tilt"
   }, 
   {
      id: 4499,
      word: "tomat naH",
      name: "tomat naH (n.) tomato"
   }, 
   {
      id: 4500,
      word: "tomat naHmey",
      name: "tomat naHmey (n.) tomatoes"
   }, 
   {
      id: 4501,
      word: "tomter",
      name: "tomter (n.) funnel"
   }, 
   {
      id: 4502,
      word: "tonSaw'",
      name: "tonSaw' (n.) fighting technique"
   }, 
   {
      id: 4503,
      word: "tongDuj",
      name: "tongDuj (n.) freighter"
   }, 
   {
      id: 4504,
      word: "toplIn",
      name: "toplIn (n.) topaline"
   }, 
   {
      id: 4505,
      word: "toppa'",
      name: "toppa' (n.) topah, type of animal"
   }, 
   {
      id: 4506,
      word: "toq",
      name: "toq (v.) be inhabited"
   }, 
   {
      id: 4507,
      word: "toqpISIn Hol",
      name: "toqpISIn Hol (n.) Tok Pisin"
   }, 
   {
      id: 4508,
      word: "toqvIr lung",
      name: "toqvIr lung (n.) tokvir loong, Tokvarian skink, type of animal"
   }, 
   {
      id: 4509,
      word: "toqwIn",
      name: "toqwIn (n.) (rubber) stamp"
   }, 
   {
      id: 4510,
      word: "tor",
      name: "tor (v.) kneel"
   }, 
   {
      id: 4511,
      word: "tor",
      name: "tor (v.) pitch (aircraft tilts nose up or down)"
   }, 
   {
      id: 4512,
      word: "torSIv",
      name: "torSIv (n.) fiction"
   }, 
   {
      id: 4513,
      word: "toral",
      name: "toral (p.n.) Toral"
   }, 
   {
      id: 4514,
      word: "toranto",
      name: "toranto (n.) Toronto"
   }, 
   {
      id: 4515,
      word: "torgh",
      name: "torgh (p.n.) Torg"
   }, 
   {
      id: 4516,
      word: "totlh",
      name: "totlh (n.) commodore"
   }, 
   {
      id: 4517,
      word: "tova'Daq",
      name: "tova'Daq (n.) mind sharing"
   }, 
   {
      id: 4518,
      word: "toy'",
      name: "toy' (v.) serve (a master)"
   }, 
   {
      id: 4519,
      word: "toy'wI'",
      name: "toy'wI' (n.) servant"
   }, 
   {
      id: 4520,
      word: "toy'wI''a'",
      name: "toy'wI''a' (n.) slave"
   }, 
   {
      id: 4521,
      word: "toyDal",
      name: "toyDal (n.) tactic"
   }, 
   {
      id: 4522,
      word: "tu",
      name: "tu (v.) blink"
   }, 
   {
      id: 4523,
      word: "tu",
      name: "tu (vp) you (pl)-me"
   }, 
   {
      id: 4524,
      word: "tu'",
      name: "tu' (v.) discover, find, observe, notice"
   }, 
   {
      id: 4525,
      word: "tu'HomI'raH",
      name: "tu'HomI'raH (n.) T'oohomIrah, something useless, useless thing"
   }, 
   {
      id: 4526,
      word: "tu'lIp",
      name: "tu'lIp (n.) tulip"
   }, 
   {
      id: 4527,
      word: "tu'lum",
      name: "tu'lum (n.) teacup (older form)"
   }, 
   {
      id: 4528,
      word: "tu'mI'",
      name: "tu'mI' (n.) sock (single)"
   }, 
   {
      id: 4529,
      word: "tu'nIS",
      name: "tu'nIS (n.) Tunisia"
   }, 
   {
      id: 4530,
      word: "tu'na",
      name: "tu'na (n.) tuna"
   }, 
   {
      id: 4531,
      word: "tu'qom",
      name: "tu'qom (n.) shape, form, appearance, configuration"
   }, 
   {
      id: 4532,
      word: "tuD",
      name: "tuD (v.) thunder"
   }, 
   {
      id: 4533,
      word: "tuH",
      name: "tuH (v.) be ashamed"
   }, 
   {
      id: 4534,
      word: "tuH",
      name: "tuH (n.) maneuver (military term)"
   }, 
   {
      id: 4535,
      word: "tuHmoH",
      name: "tuHmoH (v.) shame"
   }, 
   {
      id: 4536,
      word: "tuQ",
      name: "tuQ (v.) wear (clothes)"
   }, 
   {
      id: 4537,
      word: "tuQDoq",
      name: "tuQDoq (n.) mind sifter (Klingon psychic probe)"
   }, 
   {
      id: 4538,
      word: "tuQHa'moH",
      name: "tuQHa'moH (v.) undress"
   }, 
   {
      id: 4539,
      word: "tuQmoH",
      name: "tuQmoH (v.) put on (clothes)"
   }, 
   {
      id: 4540,
      word: "tuS",
      name: "tuS (v.) cough"
   }, 
   {
      id: 4541,
      word: "tuch",
      name: "tuch (v.) forbid"
   }, 
   {
      id: 4542,
      word: "tuch",
      name: "tuch (n.) the future (as a whole)"
   }, 
   {
      id: 4543,
      word: "tuch rIt",
      name: "tuch rIt (v.) to prophesize, see the future, know the future"
   }, 
   {
      id: 4544,
      word: "tuch rItwI'",
      name: "tuch rItwI' (n.) prophet"
   }, 
   {
      id: 4545,
      word: "tugh",
      name: "tugh (exclamation) hurry up!"
   }, 
   {
      id: 4546,
      word: "tugh",
      name: "tugh (adverb) soon"
   }, 
   {
      id: 4547,
      word: "tuj",
      name: "tuj (v.) be hot"
   }, 
   {
      id: 4548,
      word: "tuj",
      name: "tuj (n.) heat"
   }, 
   {
      id: 4549,
      word: "tuj 'otlh",
      name: "tuj 'otlh (n.) infrared, infrared radiation"
   }, 
   {
      id: 4550,
      word: "tuj muvwI'",
      name: "tuj muvwI' (n.) thermo-suture"
   }, 
   {
      id: 4551,
      word: "tujQeD",
      name: "tujQeD (n.) thermodynamics"
   }, 
   {
      id: 4552,
      word: "tul",
      name: "tul (v.) hope"
   }, 
   {
      id: 4553,
      word: "tum",
      name: "tum (n.) agency"
   }, 
   {
      id: 4554,
      word: "tun",
      name: "tun (v.) be soft"
   }, 
   {
      id: 4555,
      word: "tung",
      name: "tung (v.) discourage"
   }, 
   {
      id: 4556,
      word: "tungHa'",
      name: "tungHa' (v.) encourage"
   }, 
   {
      id: 4557,
      word: "tungyen",
      name: "tungyen (n.) concrete"
   }, 
   {
      id: 4558,
      word: "tungyen Say'qIS",
      name: "tungyen Say'qIS (n.) cement"
   }, 
   {
      id: 4559,
      word: "tup",
      name: "tup (v.) be conceptual, be abstract, be pure"
   }, 
   {
      id: 4560,
      word: "tup",
      name: "tup (n.) minute (of time)"
   }, 
   {
      id: 4561,
      word: "tuq",
      name: "tuq (n.) tribe, house, ancestral unit"
   }, 
   {
      id: 4562,
      word: "tuq Degh",
      name: "tuq Degh (n.) family crest"
   }, 
   {
      id: 4563,
      word: "tuqjIjQa'",
      name: "tuqjIjQa' (n.) United Kingdom"
   }, 
   {
      id: 4564,
      word: "tuqnIgh",
      name: "tuqnIgh (n.) a member of a house"
   }, 
   {
      id: 4565,
      word: "tuqvol",
      name: "tuqvol (n.) forehead (regional)"
   }, 
   {
      id: 4566,
      word: "tur",
      name: "tur (v.) carry out, conduct (a mission), perform (duties)"
   }, 
   {
      id: 4567,
      word: "turIqya'",
      name: "turIqya' (n.) Turkey"
   }, 
   {
      id: 4568,
      word: "turmIq",
      name: "turmIq (n.) urine"
   }, 
   {
      id: 4569,
      word: "turmIq 'enDeq",
      name: "turmIq 'enDeq (n.) urinary bladder"
   }, 
   {
      id: 4570,
      word: "turwI'",
      name: "turwI' (n.) server (computer)"
   }, 
   {
      id: 4571,
      word: "tut",
      name: "tut (n.) column"
   }, 
   {
      id: 4572,
      word: "tut Duj",
      name: "tut Duj (n.) lift, elevator"
   }, 
   {
      id: 4573,
      word: "tutlh",
      name: "tutlh (v.) be official"
   }, 
   {
      id: 4574,
      word: "tutlh",
      name: "tutlh (v.) be tattooed, have a tattoo"
   }, 
   {
      id: 4575,
      word: "tutlhmoH",
      name: "tutlhmoH (v.) tattoo"
   }, 
   {
      id: 4576,
      word: "tutren",
      name: "tutren (n.) joint pit, the space forming the acute angle of a flexing hinge/joint"
   }, 
   {
      id: 4577,
      word: "tuv",
      name: "tuv (v.) be patient"
   }, 
   {
      id: 4578,
      word: "tuva'lu",
      name: "tuva'lu (n.) Tuvalu"
   }, 
   {
      id: 4579,
      word: "tuy'",
      name: "tuy' (v.) spit"
   }, 
   {
      id: 4580,
      word: "uman",
      name: "uman (n.) Oman"
   }, 
   {
      id: 4581,
      word: "vI",
      name: "vI (vp) I-him/her/it/them"
   }, 
   {
      id: 4582,
      word: "vI'",
      name: "vI' (v.) accumulate"
   }, 
   {
      id: 4583,
      word: "vI'",
      name: "vI' (n.) decimal point"
   }, 
   {
      id: 4584,
      word: "vI'",
      name: "vI' (n.) marksmanship"
   }, 
   {
      id: 4585,
      word: "vI'",
      name: "vI' (n.) point (geometry)"
   }, 
   {
      id: 4586,
      word: "vI'Hop",
      name: "vI'Hop (n.) indirect object"
   }, 
   {
      id: 4587,
      word: "vI'Ir",
      name: "vI'Ir (n.) tide"
   }, 
   {
      id: 4588,
      word: "vI'ba'om",
      name: "vI'ba'om (n.) masterpiece"
   }, 
   {
      id: 4589,
      word: "vI'chI",
      name: "vI'chI (n.) Fiji"
   }, 
   {
      id: 4590,
      word: "vI'laS",
      name: "vI'laS (n.) fog, mist"
   }, 
   {
      id: 4591,
      word: "vI'laywar",
      name: "vI'laywar (n.) mesh"
   }, 
   {
      id: 4592,
      word: "vID",
      name: "vID (v.) be belligerent"
   }, 
   {
      id: 4593,
      word: "vID'Ir",
      name: "vID'Ir (n.) baffle"
   }, 
   {
      id: 4594,
      word: "vIH",
      name: "vIH (v.) move, be in motion"
   }, 
   {
      id: 4595,
      word: "vIHbe'",
      name: "vIHbe' (n.) A paralyzing poison that leaves no trace. Word literally means not move"
   }, 
   {
      id: 4596,
      word: "vIQ",
      name: "vIQ (v.) suffocate"
   }, 
   {
      id: 4597,
      word: "vIQmoH",
      name: "vIQmoH (v.) smother"
   }, 
   {
      id: 4598,
      word: "vIS",
      name: "vIS (vs9) while"
   }, 
   {
      id: 4599,
      word: "vIb",
      name: "vIb (v.) move through time toward the future, propagate"
   }, 
   {
      id: 4600,
      word: "vIbHa'",
      name: "vIbHa' (v.) move through time toward the past"
   }, 
   {
      id: 4601,
      word: "vIghro'",
      name: "vIghro' (n.) v'gro', cat, type of animal"
   }, 
   {
      id: 4602,
      word: "vIj",
      name: "vIj (n.) thruster"
   }, 
   {
      id: 4603,
      word: "vIl",
      name: "vIl (v.) be ridgy, be cool (slang)"
   }, 
   {
      id: 4604,
      word: "vIl",
      name: "vIl (n.) someone or something one can always find around, speed bump-like"
   }, 
   {
      id: 4605,
      word: "vIlHom",
      name: "vIlHom (n.) ridge (forehead)"
   }, 
   {
      id: 4606,
      word: "vIlInHoD",
      name: "vIlInHoD (n.) bird capable of mimicking speech"
   }, 
   {
      id: 4607,
      word: "vIlaDelvIya'",
      name: "vIlaDelvIya' (p.n.) Philadelphia"
   }, 
   {
      id: 4608,
      word: "vIlaStIn",
      name: "vIlaStIn (n.) Palestine"
   }, 
   {
      id: 4609,
      word: "vIlle'",
      name: "vIlle' (n.) minion, follower, disciple, fan, admirer"
   }, 
   {
      id: 4610,
      word: "vIn",
      name: "vIn (n.) cousin, niece or nephew"
   }, 
   {
      id: 4611,
      word: "vInDa'",
      name: "vInDa' (n.) compatriot, community member, cohort, fellow citizen"
   }, 
   {
      id: 4612,
      word: "vIncha'",
      name: "vIncha' (n.) furnace"
   }, 
   {
      id: 4613,
      word: "vIng",
      name: "vIng (v.) whine"
   }, 
   {
      id: 4614,
      word: "vIno'va' qurgh",
      name: "vIno'va' qurgh (n.) finova bean(s)"
   }, 
   {
      id: 4615,
      word: "vInpu'",
      name: "vInpu' (n.) cousins, a group of tey' and lor"
   }, 
   {
      id: 4616,
      word: "vIp",
      name: "vIp (vs2) afraid"
   }, 
   {
      id: 4617,
      word: "vIq",
      name: "vIq (n.) battle, combat (abstract)"
   }, 
   {
      id: 4618,
      word: "vIqSIS",
      name: "vIqSIS (p.n.) Vixis"
   }, 
   {
      id: 4619,
      word: "vIqraq",
      name: "vIqraq (n.) artifact, work of art"
   }, 
   {
      id: 4620,
      word: "vIraS",
      name: "vIraS (n.) France"
   }, 
   {
      id: 4621,
      word: "vIrgh",
      name: "vIrgh (v.) rip (up), slash, tear (up), gash"
   }, 
   {
      id: 4622,
      word: "vIrveq",
      name: "vIrveq (n.) terrorism"
   }, 
   {
      id: 4623,
      word: "vIt",
      name: "vIt (v.) tell the truth"
   }, 
   {
      id: 4624,
      word: "vIt",
      name: "vIt (n.) truth"
   }, 
   {
      id: 4625,
      word: "vItHay'",
      name: "vItHay' (n.) the truth test"
   }, 
   {
      id: 4626,
      word: "vItlh",
      name: "vItlh (v.) be high, be great (in quantity, size, intensity)"
   }, 
   {
      id: 4627,
      word: "vItlhIS",
      name: "vItlhIS (p.n.) Vixis"
   }, 
   {
      id: 4628,
      word: "vItlhpach",
      name: "vItlhpach (n.) scalp"
   }, 
   {
      id: 4629,
      word: "vIttlhegh",
      name: "vIttlhegh (n.) proverb"
   }, 
   {
      id: 4630,
      word: "vIychorgh",
      name: "vIychorgh (n.) juice, sap of a plant"
   }, 
   {
      id: 4631,
      word: "vIyetnam",
      name: "vIyetnam (n.) Vietnam"
   }, 
   {
      id: 4632,
      word: "va",
      name: "va (exclamation) (curse) general invective"
   }, 
   {
      id: 4633,
      word: "va'chum",
      name: "va'chum (n.) sponge (for cleaning)"
   }, 
   {
      id: 4634,
      word: "va'nuch",
      name: "va'nuch (n.) heel"
   }, 
   {
      id: 4635,
      word: "vaD",
      name: "vaD (v.) be flexible"
   }, 
   {
      id: 4636,
      word: "vaD",
      name: "vaD (ns5) for"
   }, 
   {
      id: 4637,
      word: "vaH",
      name: "vaH (n.) sheath, knife case, holster, cover, envelope"
   }, 
   {
      id: 4638,
      word: "vaHbo'",
      name: "vaHbo' (n.) lava"
   }, 
   {
      id: 4639,
      word: "vaQ",
      name: "vaQ (v.) be aggressive"
   }, 
   {
      id: 4640,
      word: "vaQ",
      name: "vaQ (v.) be effective, be vigorous"
   }, 
   {
      id: 4641,
      word: "vaS",
      name: "vaS (v.) be wide, broad"
   }, 
   {
      id: 4642,
      word: "vaS",
      name: "vaS (n.) hall, assembly hall"
   }, 
   {
      id: 4643,
      word: "vaS'a'",
      name: "vaS'a' (n.) Great Hall"
   }, 
   {
      id: 4644,
      word: "vabDot",
      name: "vabDot (adverb) moreover, in addition, even, including, also"
   }, 
   {
      id: 4645,
      word: "vagh",
      name: "vagh (n.) fifth tone of nonatonic musical scale"
   }, 
   {
      id: 4646,
      word: "vagh",
      name: "vagh (number) five, 5"
   }, 
   {
      id: 4647,
      word: "vagh reD 'Impey'",
      name: "vagh reD 'Impey' (n.) pyramid with five-sided base"
   }, 
   {
      id: 4648,
      word: "vagh reD mey'",
      name: "vagh reD mey' (n.) pentagon (lit: five wall polygon)"
   }, 
   {
      id: 4649,
      word: "vaj",
      name: "vaj (adverb) so, then, thus, in that case"
   }, 
   {
      id: 4650,
      word: "vaj",
      name: "vaj (n.) the notion of being a warrior, warriorhood"
   }, 
   {
      id: 4651,
      word: "val",
      name: "val (v.) be clever, be smart, be intelligent"
   }, 
   {
      id: 4652,
      word: "valQIS",
      name: "valQIS (p.n.) Valkris"
   }, 
   {
      id: 4653,
      word: "valQav",
      name: "valQav (n.) iris (of the eye)"
   }, 
   {
      id: 4654,
      word: "valqe'",
      name: "valqe' (n.) bat-like creature"
   }, 
   {
      id: 4655,
      word: "valtIn",
      name: "valtIn (n.) proton"
   }, 
   {
      id: 4656,
      word: "vam",
      name: "vam (ns4) this"
   }, 
   {
      id: 4657,
      word: "van",
      name: "van (v.) end (an event, voyage, battle, play, opera, story, song, etc.)"
   }, 
   {
      id: 4658,
      word: "van",
      name: "van (v.) salute"
   }, 
   {
      id: 4659,
      word: "van",
      name: "van (n.) tribute"
   }, 
   {
      id: 4660,
      word: "van Hew",
      name: "van Hew (n.) monument, memorial (sculpture)"
   }, 
   {
      id: 4661,
      word: "van bom",
      name: "van bom (n.) anthem, hymn"
   }, 
   {
      id: 4662,
      word: "van qach",
      name: "van qach (n.) momument, memorial (building)"
   }, 
   {
      id: 4663,
      word: "van'a'",
      name: "van'a' (n.) award"
   }, 
   {
      id: 4664,
      word: "vanI'la'",
      name: "vanI'la' (n.) vanilla"
   }, 
   {
      id: 4665,
      word: "vang",
      name: "vang (v.) act, take action"
   }, 
   {
      id: 4666,
      word: "vanuwa'tu",
      name: "vanuwa'tu (n.) Vanuatu"
   }, 
   {
      id: 4667,
      word: "vanya",
      name: "vanya (p.n.) Chris Atherton"
   }, 
   {
      id: 4668,
      word: "vaq",
      name: "vaq (v.) mock"
   }, 
   {
      id: 4669,
      word: "vaq'aj cha'",
      name: "vaq'aj cha' (n.) Vaq’aj II"
   }, 
   {
      id: 4670,
      word: "var",
      name: "var (v.) be stingy, miserly"
   }, 
   {
      id: 4671,
      word: "varHa'",
      name: "varHa' (v.) be generous"
   }, 
   {
      id: 4672,
      word: "varghwI'",
      name: "varghwI' (n.) Changeling/Founder"
   }, 
   {
      id: 4673,
      word: "varqo'eng",
      name: "varqo'eng (n.) polynomial expression"
   }, 
   {
      id: 4674,
      word: "vatIqan veng",
      name: "vatIqan veng (n.) Vatican"
   }, 
   {
      id: 4675,
      word: "vatlh",
      name: "vatlh (v.) coil"
   }, 
   {
      id: 4676,
      word: "vatlh",
      name: "vatlh (number) hundred"
   }, 
   {
      id: 4677,
      word: "vatlh DIS poH",
      name: "vatlh DIS poH (n.) century"
   }, 
   {
      id: 4678,
      word: "vatlh'uy'",
      name: "vatlh'uy' (number) 100 million"
   }, 
   {
      id: 4679,
      word: "vatlhSaghan",
      name: "vatlhSaghan (number) 100 billion"
   }, 
   {
      id: 4680,
      word: "vatlhbIp",
      name: "vatlhbIp (number) 10 million"
   }, 
   {
      id: 4681,
      word: "vatlhmoH",
      name: "vatlhmoH (v.) roll up"
   }, 
   {
      id: 4682,
      word: "vatlhvI'",
      name: "vatlhvI' (n.) percent"
   }, 
   {
      id: 4683,
      word: "vatwam",
      name: "vatwam (n.) spout"
   }, 
   {
      id: 4684,
      word: "vav",
      name: "vav (n.) father"
   }, 
   {
      id: 4685,
      word: "vavnI'",
      name: "vavnI' (n.) grandfather"
   }, 
   {
      id: 4686,
      word: "vaw",
      name: "vaw (v.) be ambitious, determined, motivated"
   }, 
   {
      id: 4687,
      word: "vay",
      name: "vay (v.) fight, battle (midlevel ferocity)"
   }, 
   {
      id: 4688,
      word: "vay'",
      name: "vay' (n.) somebody, someone, something, anybody, anyone, anything"
   }, 
   {
      id: 4689,
      word: "vayya'",
      name: "vayya' (n.) isosceles triangle"
   }, 
   {
      id: 4690,
      word: "ve'",
      name: "ve' (v.) travel with a purpose, for a specific reason; travel on a mission"
   }, 
   {
      id: 4691,
      word: "ve'meyI'",
      name: "ve'meyI' (n.) voltage (electric)"
   }, 
   {
      id: 4692,
      word: "veD",
      name: "veD (n.) fur"
   }, 
   {
      id: 4693,
      word: "veDDIr",
      name: "veDDIr (n.) pelt (skin with fur still attached)"
   }, 
   {
      id: 4694,
      word: "veH",
      name: "veH (n.) boundary"
   }, 
   {
      id: 4695,
      word: "veH tIn",
      name: "veH tIn (n.) great barrier"
   }, 
   {
      id: 4696,
      word: "veQ",
      name: "veQ (n.) garbage"
   }, 
   {
      id: 4697,
      word: "veQDuj",
      name: "veQDuj (n.) garbage scow"
   }, 
   {
      id: 4698,
      word: "veS",
      name: "veS (n.) war, warfare"
   }, 
   {
      id: 4699,
      word: "veSDuj",
      name: "veSDuj (n.) warship"
   }, 
   {
      id: 4700,
      word: "veStay",
      name: "veStay (n.) honorific vestai"
   }, 
   {
      id: 4701,
      word: "veb",
      name: "veb (v.) be next (in a series, sequence)"
   }, 
   {
      id: 4702,
      word: "vech",
      name: "vech (v.) cross, span"
   }, 
   {
      id: 4703,
      word: "vegh",
      name: "vegh (v.) go through (an open door, a tunnel, etc.)"
   }, 
   {
      id: 4704,
      word: "vel",
      name: "vel (v.) cover, coat, mask"
   }, 
   {
      id: 4705,
      word: "velSo'",
      name: "velSo' (n.) chromium"
   }, 
   {
      id: 4706,
      word: "velSo' 'uSqan",
      name: "velSo' 'uSqan (n.) stainless steel"
   }, 
   {
      id: 4707,
      word: "velqa'",
      name: "velqa' (n.) replica"
   }, 
   {
      id: 4708,
      word: "vem",
      name: "vem (n.) print, mark, tracks, image or pattern left in the dirt from stepping on it"
   }, 
   {
      id: 4709,
      word: "vem",
      name: "vem (v.) wake up, cease sleeping"
   }, 
   {
      id: 4710,
      word: "vem'eq",
      name: "vem'eq (n.) a bird that feeds almost exclusively on the serpent worm from which qagh is made"
   }, 
   {
      id: 4711,
      word: "vemmoH",
      name: "vemmoH (v.) light a fire, lit. wake up, cause to wake up"
   }, 
   {
      id: 4712,
      word: "vemmoH",
      name: "vemmoH (v.) wake up (someone)"
   }, 
   {
      id: 4713,
      word: "ven",
      name: "ven (v.) be nerdy, be really into something"
   }, 
   {
      id: 4714,
      word: "veneSwe'la'",
      name: "veneSwe'la' (n.) Venezuela"
   }, 
   {
      id: 4715,
      word: "veng",
      name: "veng (n.) city"
   }, 
   {
      id: 4716,
      word: "veng wa'DIch",
      name: "veng wa'DIch (n.) First City (capital of Kronos)"
   }, 
   {
      id: 4717,
      word: "veng wa'DIch Sep",
      name: "veng wa'DIch Sep (n.) First City region"
   }, 
   {
      id: 4718,
      word: "vengHom",
      name: "vengHom (n.) village"
   }, 
   {
      id: 4719,
      word: "vep",
      name: "vep (n.) proclamation, notification, announcement, and the like"
   }, 
   {
      id: 4720,
      word: "veqlargh",
      name: "veqlargh (n.) devil, demon, Fek'lhr"
   }, 
   {
      id: 4721,
      word: "veqtal",
      name: "veqtal (n.) VeK'tal"
   }, 
   {
      id: 4722,
      word: "ver",
      name: "ver (v.) be dizzy"
   }, 
   {
      id: 4723,
      word: "ver",
      name: "ver (v.) be spiral"
   }, 
   {
      id: 4724,
      word: "veragh",
      name: "veragh (n.) rivet"
   }, 
   {
      id: 4725,
      word: "veranchISqo",
      name: "veranchISqo (p.n.) Francisco"
   }, 
   {
      id: 4726,
      word: "verengan",
      name: "verengan (n.) Ferengi"
   }, 
   {
      id: 4727,
      word: "verengan Ha'DIbaH",
      name: "verengan Ha'DIbaH (n.) Ferengi dog - a classic insult"
   }, 
   {
      id: 4728,
      word: "vergh",
      name: "vergh (v.) dock"
   }, 
   {
      id: 4729,
      word: "vergh",
      name: "vergh (n.) dock, port (seaport, airport, spaceport)"
   }, 
   {
      id: 4730,
      word: "vetlh",
      name: "vetlh (n.) cockroach"
   }, 
   {
      id: 4731,
      word: "vetlh",
      name: "vetlh (ns4) that"
   }, 
   {
      id: 4732,
      word: "vev",
      name: "vev (v.) insert, put in"
   }, 
   {
      id: 4733,
      word: "vev",
      name: "vev (v.) pin, attach or fasten with a pin"
   }, 
   {
      id: 4734,
      word: "vey",
      name: "vey (n.) set, pack, package"
   }, 
   {
      id: 4735,
      word: "vey'",
      name: "vey' (v.) be comfortable, be plentiful"
   }, 
   {
      id: 4736,
      word: "vey'Ha'",
      name: "vey'Ha' (v.) be uncomfortable, be meager"
   }, 
   {
      id: 4737,
      word: "vo'",
      name: "vo' (ns5) from"
   }, 
   {
      id: 4738,
      word: "vo'",
      name: "vo' (v.) propel"
   }, 
   {
      id: 4739,
      word: "vo'nung",
      name: "vo'nung (n.) phase (of a wave)"
   }, 
   {
      id: 4740,
      word: "vo'yajer",
      name: "vo'yajer (p.n.) Voyager"
   }, 
   {
      id: 4741,
      word: "voD",
      name: "voD (v.) drill, bore"
   }, 
   {
      id: 4742,
      word: "voDchuch",
      name: "voDchuch (n.) spiderlike bug"
   }, 
   {
      id: 4743,
      word: "voDleH",
      name: "voDleH (n.) emperor"
   }, 
   {
      id: 4744,
      word: "voDmeH jan",
      name: "voDmeH jan (n.) drill"
   }, 
   {
      id: 4745,
      word: "voHDajbo'",
      name: "voHDajbo' (n.) ransom"
   }, 
   {
      id: 4746,
      word: "voQ",
      name: "voQ (v.) choke"
   }, 
   {
      id: 4747,
      word: "voQSIp",
      name: "voQSIp (n.) nitrogen"
   }, 
   {
      id: 4748,
      word: "voSpegh Sep",
      name: "voSpegh Sep (n.) Vospeg region"
   }, 
   {
      id: 4749,
      word: "vogh",
      name: "vogh (n.) somewhere"
   }, 
   {
      id: 4750,
      word: "vol",
      name: "vol (n.) pane, panel, sheet (not for bed)"
   }, 
   {
      id: 4751,
      word: "volapuq Hol",
      name: "volapuq Hol (n.) Volapük"
   }, 
   {
      id: 4752,
      word: "volchaH",
      name: "volchaH (n.) shoulder"
   }, 
   {
      id: 4753,
      word: "voltImaD",
      name: "voltImaD (p.n.) Voltimand"
   }, 
   {
      id: 4754,
      word: "von",
      name: "von (v.) trap, entrap"
   }, 
   {
      id: 4755,
      word: "vong",
      name: "vong (v.) hypnotize"
   }, 
   {
      id: 4756,
      word: "vonlu'",
      name: "vonlu' (v.) fail utterly (slang)"
   }, 
   {
      id: 4757,
      word: "voq",
      name: "voq (v.) trust, have faith in"
   }, 
   {
      id: 4758,
      word: "voq",
      name: "voq (p.n.) Voq"
   }, 
   {
      id: 4759,
      word: "voqHa'",
      name: "voqHa' (v.) distrust"
   }, 
   {
      id: 4760,
      word: "vor",
      name: "vor (v.) cure"
   }, 
   {
      id: 4761,
      word: "vorgh",
      name: "vorgh (v.) be previous"
   }, 
   {
      id: 4762,
      word: "vortIbraS",
      name: "vortIbraS (p.n.) Fortinbras"
   }, 
   {
      id: 4763,
      word: "votlh",
      name: "votlh (v.) be narcissistic"
   }, 
   {
      id: 4764,
      word: "vov",
      name: "vov (v.) grapple, wrestle, tussle"
   }, 
   {
      id: 4765,
      word: "voveng",
      name: "voveng (n.) gland"
   }, 
   {
      id: 4766,
      word: "voy",
      name: "voy (v.) clone (something)"
   }, 
   {
      id: 4767,
      word: "vu'",
      name: "vu' (v.) manage"
   }, 
   {
      id: 4768,
      word: "vu'wI'",
      name: "vu'wI' (n.) manager"
   }, 
   {
      id: 4769,
      word: "vuD",
      name: "vuD (n.) opinion"
   }, 
   {
      id: 4770,
      word: "vuHbIn",
      name: "vuHbIn (n.) lymph"
   }, 
   {
      id: 4771,
      word: "vuQ",
      name: "vuQ (v.) fascinate"
   }, 
   {
      id: 4772,
      word: "vuS",
      name: "vuS (v.) limit"
   }, 
   {
      id: 4773,
      word: "vub",
      name: "vub (n.) hostage"
   }, 
   {
      id: 4774,
      word: "vuj",
      name: "vuj (v.) expel, eject"
   }, 
   {
      id: 4775,
      word: "vul",
      name: "vul (v.) be unconscious"
   }, 
   {
      id: 4776,
      word: "vulqan",
      name: "vulqan (n.) Vulcan (planet)"
   }, 
   {
      id: 4777,
      word: "vulqangan",
      name: "vulqangan (n.) Vulcan (person)"
   }, 
   {
      id: 4778,
      word: "vum",
      name: "vum (n.) contemptible or despicable person, scumbag, bastard"
   }, 
   {
      id: 4779,
      word: "vum",
      name: "vum (v.) work, toil"
   }, 
   {
      id: 4780,
      word: "vun",
      name: "vun (v.) order (in a restaurant, from a catalog, etc.)"
   }, 
   {
      id: 4781,
      word: "vung",
      name: "vung (v.) cyclone, hurricane"
   }, 
   {
      id: 4782,
      word: "vup",
      name: "vup (v.) pity"
   }, 
   {
      id: 4783,
      word: "vur",
      name: "vur (v.) be modern, up-to-date, state-of-the-art"
   }, 
   {
      id: 4784,
      word: "vut",
      name: "vut (v.) cook, prepare food or beverage"
   }, 
   {
      id: 4785,
      word: "vut'un",
      name: "vut'un (n.) flat-bottomed pot for food preparation (regional)"
   }, 
   {
      id: 4786,
      word: "vutmeH 'un",
      name: "vutmeH 'un (n.) flat-bottomed pot for food preparation (regional)"
   }, 
   {
      id: 4787,
      word: "vutpa'",
      name: "vutpa' (n.) galley, kitchen on a ship, food preparation room"
   }, 
   {
      id: 4788,
      word: "vuv",
      name: "vuv (v.) respect"
   }, 
   {
      id: 4789,
      word: "vuy",
      name: "vuy (v.) be helpful, be supportive"
   }, 
   {
      id: 4790,
      word: "wI",
      name: "wI (vp) we-him/her/it"
   }, 
   {
      id: 4791,
      word: "wI'",
      name: "wI' (ns4) my (noun capable of using language)"
   }, 
   {
      id: 4792,
      word: "wI'",
      name: "wI' (vs9) one who does, thing which does"
   }, 
   {
      id: 4793,
      word: "wI'qIypI'DIya",
      name: "wI'qIypI'DIya (n.) Wikipedia"
   }, 
   {
      id: 4794,
      word: "wID",
      name: "wID (v.) massacre (connotes indiscriminate killing)"
   }, 
   {
      id: 4795,
      word: "wIH",
      name: "wIH (v.) be ruthless"
   }, 
   {
      id: 4796,
      word: "wIb",
      name: "wIb (v.) be sour, be bitter, be tart"
   }, 
   {
      id: 4797,
      word: "wIch",
      name: "wIch (n.) myth"
   }, 
   {
      id: 4798,
      word: "wIgh",
      name: "wIgh (n.) genius"
   }, 
   {
      id: 4799,
      word: "wIj",
      name: "wIj (v.) farm"
   }, 
   {
      id: 4800,
      word: "wIj",
      name: "wIj (ns4) my"
   }, 
   {
      id: 4801,
      word: "wIjwI' ngeb",
      name: "wIjwI' ngeb (n.) scarecrow"
   }, 
   {
      id: 4802,
      word: "wIl",
      name: "wIl (v.) be short (in length)"
   }, 
   {
      id: 4803,
      word: "wIl",
      name: "wIl (n.) spike"
   }, 
   {
      id: 4804,
      word: "wIlHay",
      name: "wIlHay (n.) hinge (of a door), spine (of a book)"
   }, 
   {
      id: 4805,
      word: "wIlle'",
      name: "wIlle' (n.) joint"
   }, 
   {
      id: 4806,
      word: "wIllul",
      name: "wIllul (n.) a game somewhat similar to bowling"
   }, 
   {
      id: 4807,
      word: "wIlpuq",
      name: "wIlpuq (n.) pudding"
   }, 
   {
      id: 4808,
      word: "wIlyam",
      name: "wIlyam (p.n.) William"
   }, 
   {
      id: 4809,
      word: "wItlh",
      name: "wItlh (v.) break (something) off"
   }, 
   {
      id: 4810,
      word: "wItte'",
      name: "wItte' (n.) mathematical equation"
   }, 
   {
      id: 4811,
      word: "wIv",
      name: "wIv (n.) choice"
   }, 
   {
      id: 4812,
      word: "wIv",
      name: "wIv (v.) select, choose"
   }, 
   {
      id: 4813,
      word: "wIy",
      name: "wIy (n.) tactical display"
   }, 
   {
      id: 4814,
      word: "wIyqap",
      name: "wIyqap (n.) row, line (of people or things not expected to be in motion)"
   }, 
   {
      id: 4815,
      word: "wa'",
      name: "wa' (number) one, 1"
   }, 
   {
      id: 4816,
      word: "wa'DIch",
      name: "wa'DIch (number) first"
   }, 
   {
      id: 4817,
      word: "wa'Hu'",
      name: "wa'Hu' (n.) yesterday"
   }, 
   {
      id: 4818,
      word: "wa'SIngtanDIySIy",
      name: "wa'SIngtanDIySIy (p.n.) Washington, DC"
   }, 
   {
      id: 4819,
      word: "wa'chaw",
      name: "wa'chaw (n.) spreadsheet, table"
   }, 
   {
      id: 4820,
      word: "wa'lIS",
      name: "wa'lIS (p.n.) Walsh"
   }, 
   {
      id: 4821,
      word: "wa'lay",
      name: "wa'lay (n.) mass"
   }, 
   {
      id: 4822,
      word: "wa'lay HoS nger",
      name: "wa'lay HoS nger (n.) theory of relativity"
   }, 
   {
      id: 4823,
      word: "wa'leS",
      name: "wa'leS (n.) tomorrow"
   }, 
   {
      id: 4824,
      word: "wa'logh",
      name: "wa'logh (adverb) once"
   }, 
   {
      id: 4825,
      word: "wa'maH",
      name: "wa'maH (number) ten"
   }, 
   {
      id: 4826,
      word: "wa'ngoQ",
      name: "wa'ngoQ (n.) manganese"
   }, 
   {
      id: 4827,
      word: "waDwach",
      name: "waDwach (n.) scarf (head)"
   }, 
   {
      id: 4828,
      word: "waH",
      name: "waH (v.) taste, try out (food), try out, test, use experimentally"
   }, 
   {
      id: 4829,
      word: "waQ",
      name: "waQ (n.) months from now"
   }, 
   {
      id: 4830,
      word: "waQ",
      name: "waQ (v.) obstruct"
   }, 
   {
      id: 4831,
      word: "waS",
      name: "waS (v.) be wrong, awry"
   }, 
   {
      id: 4832,
      word: "wab",
      name: "wab (n.) sound, noise"
   }, 
   {
      id: 4833,
      word: "wab choHwI'",
      name: "wab choHwI' (n.) synthesizer"
   }, 
   {
      id: 4834,
      word: "wab labwI'",
      name: "wab labwI' (n.) radio transmitter"
   }, 
   {
      id: 4835,
      word: "wab naQ",
      name: "wab naQ (n.) vowel"
   }, 
   {
      id: 4836,
      word: "wab poD",
      name: "wab poD (n.) consonant"
   }, 
   {
      id: 4837,
      word: "wab qoSta' 'aplo'",
      name: "wab qoSta' 'aplo' (n.) cassette"
   }, 
   {
      id: 4838,
      word: "wabDo",
      name: "wabDo (n.) Mach"
   }, 
   {
      id: 4839,
      word: "wagh",
      name: "wagh (v.) be expensive"
   }, 
   {
      id: 4840,
      word: "wal",
      name: "wal (v.) vibrate, be in a state of vibration"
   }, 
   {
      id: 4841,
      word: "wam",
      name: "wam (v.) hunt, fish"
   }, 
   {
      id: 4842,
      word: "wamwI'",
      name: "wamwI' (n.) hunter"
   }, 
   {
      id: 4843,
      word: "wan",
      name: "wan (v.) be straight"
   }, 
   {
      id: 4844,
      word: "wanI'",
      name: "wanI' (n.) phenomenon, event, occurrence"
   }, 
   {
      id: 4845,
      word: "wang",
      name: "wang (v.) wink"
   }, 
   {
      id: 4846,
      word: "waq",
      name: "waq (n.) shoe"
   }, 
   {
      id: 4847,
      word: "waqboch",
      name: "waqboch (n.) a bird with a very long beak"
   }, 
   {
      id: 4848,
      word: "war",
      name: "war (n.) column (in a table or spreadsheet)"
   }, 
   {
      id: 4849,
      word: "warjun",
      name: "warjun (n.) type of knife (used for food preparation)"
   }, 
   {
      id: 4850,
      word: "watlh",
      name: "watlh (v.) be pure"
   }, 
   {
      id: 4851,
      word: "watlhmoH",
      name: "watlhmoH (v.) smelt"
   }, 
   {
      id: 4852,
      word: "watrIn",
      name: "watrIn (n.) lubricant (general term)"
   }, 
   {
      id: 4853,
      word: "wav",
      name: "wav (v.) divide"
   }, 
   {
      id: 4854,
      word: "wavre'",
      name: "wavre' (n.) pulsar"
   }, 
   {
      id: 4855,
      word: "waw'",
      name: "waw' (n.) base (military term)"
   }, 
   {
      id: 4856,
      word: "way",
      name: "way (v.) be striped"
   }, 
   {
      id: 4857,
      word: "way'",
      name: "way' (v.) parry, deflect a lunge"
   }, 
   {
      id: 4858,
      word: "way'ar",
      name: "way'ar (n.) chaos"
   }, 
   {
      id: 4859,
      word: "we'lIS",
      name: "we'lIS (n.) Wales"
   }, 
   {
      id: 4860,
      word: "weH",
      name: "weH (v.) raid"
   }, 
   {
      id: 4861,
      word: "weQ",
      name: "weQ (n.) candle"
   }, 
   {
      id: 4862,
      word: "weQmoQnaQ",
      name: "weQmoQnaQ (n.) world wide web, www"
   }, 
   {
      id: 4863,
      word: "weS",
      name: "weS (v.) lose, no longer have, suffer a reduction of"
   }, 
   {
      id: 4864,
      word: "weSjech",
      name: "weSjech (n.) fabric, cloth, textile"
   }, 
   {
      id: 4865,
      word: "weSjech ba'Suq Duj",
      name: "weSjech ba'Suq Duj (n.) hot air balloon"
   }, 
   {
      id: 4866,
      word: "web",
      name: "web (v.) be chaotic, disorganized"
   }, 
   {
      id: 4867,
      word: "web",
      name: "web (v.) be disgraced"
   }, 
   {
      id: 4868,
      word: "wech",
      name: "wech (v.) serve fermented food at its peak"
   }, 
   {
      id: 4869,
      word: "wegh",
      name: "wegh (v.) confine"
   }, 
   {
      id: 4870,
      word: "wej",
      name: "wej (adverb) not yet"
   }, 
   {
      id: 4871,
      word: "wej",
      name: "wej (number) three, 3"
   }, 
   {
      id: 4872,
      word: "wejDIch",
      name: "wejDIch (number) third"
   }, 
   {
      id: 4873,
      word: "wejHa'",
      name: "wejHa' (adverb) already"
   }, 
   {
      id: 4874,
      word: "wejbe'",
      name: "wejbe' (n.) nitrate"
   }, 
   {
      id: 4875,
      word: "wejpuH",
      name: "wejpuH (exclamation) charming (used only ironically)"
   }, 
   {
      id: 4876,
      word: "wejwa'",
      name: "wejwa' (n.) flavor, taste"
   }, 
   {
      id: 4877,
      word: "wel",
      name: "wel (v.) owe (someone)"
   }, 
   {
      id: 4878,
      word: "welwelwel",
      name: "welwelwel (exclamation) sound made by a stereotypic targh"
   }, 
   {
      id: 4879,
      word: "wem",
      name: "wem (v.) violate"
   }, 
   {
      id: 4880,
      word: "wem",
      name: "wem (n.) violation"
   }, 
   {
      id: 4881,
      word: "wen",
      name: "wen (n.) months ago"
   }, 
   {
      id: 4882,
      word: "wep",
      name: "wep (n.) jacket, coat, blouse"
   }, 
   {
      id: 4883,
      word: "wep",
      name: "wep (n.) shirt with sleeves, blouse (regional)"
   }, 
   {
      id: 4884,
      word: "wep buq",
      name: "wep buq (n.) coat pouch, pocket"
   }, 
   {
      id: 4885,
      word: "weq",
      name: "weq (v.) hit (percussion instrument) with palm"
   }, 
   {
      id: 4886,
      word: "wer",
      name: "wer (v.) be creased, be wrinkled"
   }, 
   {
      id: 4887,
      word: "wermoH",
      name: "wermoH (v.) crease, wrinkle"
   }, 
   {
      id: 4888,
      word: "wev",
      name: "wev (n.) row (in a table or spreadsheet)"
   }, 
   {
      id: 4889,
      word: "wev",
      name: "wev (v.) sketch, doodle"
   }, 
   {
      id: 4890,
      word: "wevpev",
      name: "wevpev (n.) wheat-like plant"
   }, 
   {
      id: 4891,
      word: "wew",
      name: "wew (v.) glow"
   }, 
   {
      id: 4892,
      word: "wey",
      name: "wey (n.) company (military unit)"
   }, 
   {
      id: 4893,
      word: "wo'",
      name: "wo' (n.) empire"
   }, 
   {
      id: 4894,
      word: "wo'rIv",
      name: "wo'rIv (p.n.) Worf"
   }, 
   {
      id: 4895,
      word: "woD",
      name: "woD (v.) be hollow"
   }, 
   {
      id: 4896,
      word: "woD",
      name: "woD (v.) throw away"
   }, 
   {
      id: 4897,
      word: "woH",
      name: "woH (v.) pick up"
   }, 
   {
      id: 4898,
      word: "woQ",
      name: "woQ (n.) authority, political power"
   }, 
   {
      id: 4899,
      word: "woS",
      name: "woS (n.) chin"
   }, 
   {
      id: 4900,
      word: "woSwa'",
      name: "woSwa' (n.) armadillo-like animal, hedgehog-like animal"
   }, 
   {
      id: 4901,
      word: "woSwa' ghew",
      name: "woSwa' ghew (n.) woodlouse-like bug, pillbug-like bug, rolling bug"
   }, 
   {
      id: 4902,
      word: "wob",
      name: "wob (v.) hurl a spear by means of a chetvi"
   }, 
   {
      id: 4903,
      word: "woch",
      name: "woch (v.) be tall"
   }, 
   {
      id: 4904,
      word: "wogh",
      name: "wogh (v.) transgress, do more than is acceptable"
   }, 
   {
      id: 4905,
      word: "woj",
      name: "woj (n.) radiation"
   }, 
   {
      id: 4906,
      word: "woj",
      name: "woj (v.) sterilize"
   }, 
   {
      id: 4907,
      word: "woj tlhuD",
      name: "woj tlhuD (v.) be radioactive, lit."
   }, 
   {
      id: 4908,
      word: "wol",
      name: "wol (v.) be creased, be folded"
   }, 
   {
      id: 4909,
      word: "wolmoH",
      name: "wolmoH (v.) crease, fold"
   }, 
   {
      id: 4910,
      word: "wom",
      name: "wom (v.) peck"
   }, 
   {
      id: 4911,
      word: "won",
      name: "won (v.) hesitate"
   }, 
   {
      id: 4912,
      word: "won jat",
      name: "won jat (v.) stutter, stammer"
   }, 
   {
      id: 4913,
      word: "wonmugh",
      name: "wonmugh (n.) alley"
   }, 
   {
      id: 4914,
      word: "wontoy",
      name: "wontoy (n.) ideal"
   }, 
   {
      id: 4915,
      word: "woq",
      name: "woq (v.) confirm, substantiate, corroborate"
   }, 
   {
      id: 4916,
      word: "wornagh",
      name: "wornagh (n.) warnog, Klingon ale"
   }, 
   {
      id: 4917,
      word: "wot",
      name: "wot (n.) verb"
   }, 
   {
      id: 4918,
      word: "wot chuS",
      name: "wot chuS (n.) non-stative verb"
   }, 
   {
      id: 4919,
      word: "wot tam",
      name: "wot tam (n.) stative verb"
   }, 
   {
      id: 4920,
      word: "wov",
      name: "wov (v.) be light, be bright"
   }, 
   {
      id: 4921,
      word: "wov'on",
      name: "wov'on (n.) memory, recollection"
   }, 
   {
      id: 4922,
      word: "wovmoH",
      name: "wovmoH (v.) light, enlighten"
   }, 
   {
      id: 4923,
      word: "wovmoHwI'",
      name: "wovmoHwI' (n.) light (device, eg lamp)"
   }, 
   {
      id: 4924,
      word: "wu'",
      name: "wu' (v.) be mystical, be esoteric, be occult"
   }, 
   {
      id: 4925,
      word: "wu'DIy",
      name: "wu'DIy (n.) beaver-like creature"
   }, 
   {
      id: 4926,
      word: "wu'tIbIS",
      name: "wu'tIbIS (n.) superstition"
   }, 
   {
      id: 4927,
      word: "wuD",
      name: "wuD (v.) snore"
   }, 
   {
      id: 4928,
      word: "wuH",
      name: "wuH (v.) skim, glide, skate, skid"
   }, 
   {
      id: 4929,
      word: "wuQ",
      name: "wuQ (v.) have a headache"
   }, 
   {
      id: 4930,
      word: "wuS",
      name: "wuS (n.) lip"
   }, 
   {
      id: 4931,
      word: "wun",
      name: "wun (v.) be unprotected, be vulnerable"
   }, 
   {
      id: 4932,
      word: "wup",
      name: "wup (v.) burst into song"
   }, 
   {
      id: 4933,
      word: "wuq",
      name: "wuq (v.) decide"
   }, 
   {
      id: 4934,
      word: "wuqwI'",
      name: "wuqwI' (n.) juror"
   }, 
   {
      id: 4935,
      word: "wuqwI' ghom",
      name: "wuqwI' ghom (n.) jury"
   }, 
   {
      id: 4936,
      word: "wutlh",
      name: "wutlh (n.) underground"
   }, 
   {
      id: 4937,
      word: "wuv",
      name: "wuv (v.) depend on, rely on"
   }, 
   {
      id: 4938,
      word: "wuvchuq",
      name: "wuvchuq (v.) be entangled (quantum physics, but maybe more general)"
   }, 
   {
      id: 4939,
      word: "yI",
      name: "yI (vp) imp: you (s/pl)-him/her/it/0"
   }, 
   {
      id: 4940,
      word: "yI'",
      name: "yI' (v.) speak in an honorable or respectful fashion"
   }, 
   {
      id: 4941,
      word: "yI'De'",
      name: "yI'De' (n.) cervid-like animal"
   }, 
   {
      id: 4942,
      word: "yI'var",
      name: "yI'var (n.) treatment, therapy"
   }, 
   {
      id: 4943,
      word: "yIH",
      name: "yIH (n.) tribble"
   }, 
   {
      id: 4944,
      word: "yIQ",
      name: "yIQ (v.) be wet"
   }, 
   {
      id: 4945,
      word: "yIS",
      name: "yIS (n.) speed of light"
   }, 
   {
      id: 4946,
      word: "yISra'el",
      name: "yISra'el (n.) Israel"
   }, 
   {
      id: 4947,
      word: "yIb",
      name: "yIb (n.) vent"
   }, 
   {
      id: 4948,
      word: "yIn",
      name: "yIn (n.) life"
   }, 
   {
      id: 4949,
      word: "yIn",
      name: "yIn (v.) live"
   }, 
   {
      id: 4950,
      word: "yIn 'eSqa'",
      name: "yIn 'eSqa' (n.) environmental suit"
   }, 
   {
      id: 4951,
      word: "yInSIp",
      name: "yInSIp (n.) oxygen"
   }, 
   {
      id: 4952,
      word: "yInbogh",
      name: "yInbogh (v.) alive, that lives"
   }, 
   {
      id: 4953,
      word: "yInbogh lom",
      name: "yInbogh lom (n.) zombie"
   }, 
   {
      id: 4954,
      word: "yInroH",
      name: "yInroH (n.) life signs"
   }, 
   {
      id: 4955,
      word: "yIntagh",
      name: "yIntagh (exclamation) (curse) epithet, insult"
   }, 
   {
      id: 4956,
      word: "yIntagh",
      name: "yIntagh (n.) life-support system"
   }, 
   {
      id: 4957,
      word: "yIr",
      name: "yIr (v.) gather"
   }, 
   {
      id: 4958,
      word: "yIr'ach",
      name: "yIr'ach (n.) close friend"
   }, 
   {
      id: 4959,
      word: "yIrIDngan",
      name: "yIrIDngan (n.) Yiridian (person)"
   }, 
   {
      id: 4960,
      word: "yIt",
      name: "yIt (v.) walk"
   }, 
   {
      id: 4961,
      word: "yItQet",
      name: "yItQet (n.) petroleum, crude oil"
   }, 
   {
      id: 4962,
      word: "yItlh",
      name: "yItlh (v.) be strict, severe, firm, stern, authoritarian."
   }, 
   {
      id: 4963,
      word: "yItlhHa'",
      name: "yItlhHa' (v.) lenient, indulgent"
   }, 
   {
      id: 4964,
      word: "yItram",
      name: "yItram (n.) whistle (hand-held device) with a clear sound"
   }, 
   {
      id: 4965,
      word: "yIv",
      name: "yIv (v.) chew"
   }, 
   {
      id: 4966,
      word: "yIv",
      name: "yIv (v.) chew, annoy (slang), bother (slang), irk (slang), irritate (slang)"
   }, 
   {
      id: 4967,
      word: "yIvbeH",
      name: "yIvbeH (n.) sleeveless shirt (regional)"
   }, 
   {
      id: 4968,
      word: "yIvbeH",
      name: "yIvbeH (n.) tunic, blouse"
   }, 
   {
      id: 4969,
      word: "yIvbeH naQHa'",
      name: "yIvbeH naQHa' (n.) vest, waistcoat"
   }, 
   {
      id: 4970,
      word: "ya",
      name: "ya (n.) tactical officer"
   }, 
   {
      id: 4971,
      word: "ya'rIS",
      name: "ya'rIS (n.) echo"
   }, 
   {
      id: 4972,
      word: "yaD",
      name: "yaD (n.) teen (slang), teenager (slang), adolescent (slang), youth (slang), young adult (slang)"
   }, 
   {
      id: 4973,
      word: "yaD",
      name: "yaD (n.) toe, sword (slang)"
   }, 
   {
      id: 4974,
      word: "yaDpach",
      name: "yaDpach (n.) toenail"
   }, 
   {
      id: 4975,
      word: "yaH",
      name: "yaH (v.) be taken away"
   }, 
   {
      id: 4976,
      word: "yaH",
      name: "yaH (n.) duty station, station"
   }, 
   {
      id: 4977,
      word: "yaS",
      name: "yaS (n.) officer"
   }, 
   {
      id: 4978,
      word: "yaS cha'DIch",
      name: "yaS cha'DIch (n.) second officer"
   }, 
   {
      id: 4979,
      word: "yaS cha'DIch",
      name: "yaS cha'DIch (n.) second officer (on a ship)"
   }, 
   {
      id: 4980,
      word: "yaS wa'DIch",
      name: "yaS wa'DIch (n.) first officer"
   }, 
   {
      id: 4981,
      word: "yaS wa'DIch",
      name: "yaS wa'DIch (n.) first officer (on a ship)"
   }, 
   {
      id: 4982,
      word: "yab",
      name: "yab (n.) mind, brain"
   }, 
   {
      id: 4983,
      word: "yab qoD",
      name: "yab qoD (n.) subconscious mind"
   }, 
   {
      id: 4984,
      word: "yabHuj",
      name: "yabHuj (p.n.) Volker Tanger"
   }, 
   {
      id: 4985,
      word: "yach",
      name: "yach (v.) pet, stroke"
   }, 
   {
      id: 4986,
      word: "yach",
      name: "yach (v.) strum (a stringed instrument)"
   }, 
   {
      id: 4987,
      word: "yagh",
      name: "yagh (n.) organism"
   }, 
   {
      id: 4988,
      word: "yaj",
      name: "yaj (v.) understand"
   }, 
   {
      id: 4989,
      word: "yajHa'",
      name: "yajHa' (v.) misinterpret"
   }, 
   {
      id: 4990,
      word: "yalwoD",
      name: "yalwoD (n.) momentum"
   }, 
   {
      id: 4991,
      word: "yam",
      name: "yam (v.) be assimilated, be incorporated, be subsumed"
   }, 
   {
      id: 4992,
      word: "yamqeq",
      name: "yamqeq (n.) assmilation"
   }, 
   {
      id: 4993,
      word: "yamtaw",
      name: "yamtaw (n.) line"
   }, 
   {
      id: 4994,
      word: "yamtaw job",
      name: "yamtaw job (n.) jagged line, zigzagging line"
   }, 
   {
      id: 4995,
      word: "yan",
      name: "yan (n.) bow (slang)"
   }, 
   {
      id: 4996,
      word: "yan",
      name: "yan (n.) sword"
   }, 
   {
      id: 4997,
      word: "yan",
      name: "yan (v.) wield or use or manipulate a sword"
   }, 
   {
      id: 4998,
      word: "yang",
      name: "yang (n.) image from a (rubber) stamp"
   }, 
   {
      id: 4999,
      word: "yanwI'",
      name: "yanwI' (n.) swordfighter"
   }, 
   {
      id: 5000,
      word: "yanwo'",
      name: "yanwo' (n.) nest"
   }, 
   {
      id: 5001,
      word: "yap",
      name: "yap (v.) be enough, be sufficient"
   }, 
   {
      id: 5002,
      word: "yar",
      name: "yar (v.) flirt with"
   }, 
   {
      id: 5003,
      word: "yarno",
      name: "yarno (p.n.) Jarno Peschier"
   }, 
   {
      id: 5004,
      word: "yatlh",
      name: "yatlh (v.) be pregnant"
   }, 
   {
      id: 5005,
      word: "yatqap",
      name: "yatqap (n.) a gray (sometimes white) bird that can travel particularly long distances without pausing"
   }, 
   {
      id: 5006,
      word: "yav",
      name: "yav (n.) ground"
   }, 
   {
      id: 5007,
      word: "yavDuj",
      name: "yavDuj (n.) ground ship (car)"
   }, 
   {
      id: 5008,
      word: "yay",
      name: "yay (n.) sketch, doodle"
   }, 
   {
      id: 5009,
      word: "yay",
      name: "yay (n.) victory, triumph"
   }, 
   {
      id: 5010,
      word: "yay mIr",
      name: "yay mIr (n.) winning streak"
   }, 
   {
      id: 5011,
      word: "yay'",
      name: "yay' (v.) be shocked, be dumbfounded"
   }, 
   {
      id: 5012,
      word: "yayal",
      name: "yayal (n.) nickel (element)"
   }, 
   {
      id: 5013,
      word: "ye",
      name: "ye (v.) holy, be sacred"
   }, 
   {
      id: 5014,
      word: "yeb",
      name: "yeb (n.) wrist (also slang term of deprecation)"
   }, 
   {
      id: 5015,
      word: "yegh",
      name: "yegh (v.) be spotted, be polka-dotted"
   }, 
   {
      id: 5016,
      word: "yej",
      name: "yej (n.) assembly, council"
   }, 
   {
      id: 5017,
      word: "yej'an",
      name: "yej'an (n.) society (scholarly) - smaller than yejHaD"
   }, 
   {
      id: 5018,
      word: "yejHaD",
      name: "yejHaD (n.) institute, institution - larger than yej'an"
   }, 
   {
      id: 5019,
      word: "yejquv",
      name: "yejquv (n.) High Council"
   }, 
   {
      id: 5020,
      word: "yelmo'",
      name: "yelmo' (n.) membrane"
   }, 
   {
      id: 5021,
      word: "yelneHSIQ",
      name: "yelneHSIQ (n.) vanadium (element)"
   }, 
   {
      id: 5022,
      word: "yelvew",
      name: "yelvew (n.) texture"
   }, 
   {
      id: 5023,
      word: "yem",
      name: "yem (v.) sin"
   }, 
   {
      id: 5024,
      word: "yemDeq",
      name: "yemDeq (n.) canvas"
   }, 
   {
      id: 5025,
      word: "yemghaw",
      name: "yemghaw (n.) tadpole"
   }, 
   {
      id: 5026,
      word: "yep",
      name: "yep (v.) be careful"
   }, 
   {
      id: 5027,
      word: "yepHa'",
      name: "yepHa' (v.) be careless"
   }, 
   {
      id: 5028,
      word: "yeq",
      name: "yeq (v.) cooperate"
   }, 
   {
      id: 5029,
      word: "yer",
      name: "yer (n.) domain, holdings, territory"
   }, 
   {
      id: 5030,
      word: "yergho",
      name: "yergho (n.) wall of a city (from yer+gho)"
   }, 
   {
      id: 5031,
      word: "yeru'Sala'yIm",
      name: "yeru'Sala'yIm (n.) Jerusalem"
   }, 
   {
      id: 5032,
      word: "yetmoS",
      name: "yetmoS (n.) gravel"
   }, 
   {
      id: 5033,
      word: "yev",
      name: "yev (v.) pause"
   }, 
   {
      id: 5034,
      word: "yo",
      name: "yo (v.) slap, hit with palm"
   }, 
   {
      id: 5035,
      word: "yo'",
      name: "yo' (n.) fleet (of ships)"
   }, 
   {
      id: 5036,
      word: "yo'SeH yaHnIv",
      name: "yo'SeH yaHnIv (n.) Operations Command"
   }, 
   {
      id: 5037,
      word: "yo'gha'",
      name: "yo'gha' (n.) yoga"
   }, 
   {
      id: 5038,
      word: "yo'ghur",
      name: "yo'ghur (n.) yogurt"
   }, 
   {
      id: 5039,
      word: "yoD",
      name: "yoD (n.) shield"
   }, 
   {
      id: 5040,
      word: "yoD",
      name: "yoD (v.) shield"
   }, 
   {
      id: 5041,
      word: "yoD'egh",
      name: "yoD'egh (v.) shield oneself"
   }, 
   {
      id: 5042,
      word: "yoDtargh",
      name: "yoDtargh (p.n.) R.B Franklin"
   }, 
   {
      id: 5043,
      word: "yoH",
      name: "yoH (v.) be brave"
   }, 
   {
      id: 5044,
      word: "yoHwI'",
      name: "yoHwI' (n.) brave one"
   }, 
   {
      id: 5045,
      word: "yoHwI'",
      name: "yoHwI' (n.) the brave"
   }, 
   {
      id: 5046,
      word: "yoS",
      name: "yoS (n.) district, area (within a country)"
   }, 
   {
      id: 5047,
      word: "yob",
      name: "yob (v.) harvest"
   }, 
   {
      id: 5048,
      word: "yoghIp",
      name: "yoghIp (n.) asthma"
   }, 
   {
      id: 5049,
      word: "yoghan",
      name: "yoghan (n.) renaissance, revival"
   }, 
   {
      id: 5050,
      word: "yoj",
      name: "yoj (n.) judgment"
   }, 
   {
      id: 5051,
      word: "yol",
      name: "yol (n.) conflict"
   }, 
   {
      id: 5052,
      word: "yomIj",
      name: "yomIj (n.) neutron"
   }, 
   {
      id: 5053,
      word: "yon",
      name: "yon (v.) be satisfied"
   }, 
   {
      id: 5054,
      word: "yong",
      name: "yong (v.) get in"
   }, 
   {
      id: 5055,
      word: "yong'el",
      name: "yong'el (n.) psychedelic"
   }, 
   {
      id: 5056,
      word: "yong'el tlhugh QoQ",
      name: "yong'el tlhugh QoQ (n.) Acid Punk"
   }, 
   {
      id: 5057,
      word: "yonmoH",
      name: "yonmoH (v.) satisfy"
   }, 
   {
      id: 5058,
      word: "yopwaH",
      name: "yopwaH (n.) pants, trousers"
   }, 
   {
      id: 5059,
      word: "yopwaH buq",
      name: "yopwaH buq (n.) pant (trouser) pouch, pocket"
   }, 
   {
      id: 5060,
      word: "yoq",
      name: "yoq (n.) humanoid"
   }, 
   {
      id: 5061,
      word: "yoq'eD",
      name: "yoq'eD (n.) stool"
   }, 
   {
      id: 5062,
      word: "yor",
      name: "yor (v.) sulk, mope, pout"
   }, 
   {
      id: 5063,
      word: "yor",
      name: "yor (n.) top (exterior)"
   }, 
   {
      id: 5064,
      word: "yorgh",
      name: "yorgh (n.) shelf, bookshelf, fixed or non-fixed (general term)"
   }, 
   {
      id: 5065,
      word: "yorqej",
      name: "yorqej (n.) nomad"
   }, 
   {
      id: 5066,
      word: "yoruba' Hol",
      name: "yoruba' Hol (n.) Yoruba"
   }, 
   {
      id: 5067,
      word: "yot",
      name: "yot (v.) invade"
   }, 
   {
      id: 5068,
      word: "yot",
      name: "yot (n.) invasion, raid, incursion"
   }, 
   {
      id: 5069,
      word: "yotlh",
      name: "yotlh (n.) field (of land)"
   }, 
   {
      id: 5070,
      word: "yotlh",
      name: "yotlh (n.) park (e.g., recreational)"
   }, 
   {
      id: 5071,
      word: "yov",
      name: "yov (v.) charge (military term)"
   }, 
   {
      id: 5072,
      word: "yoy",
      name: "yoy (v.) be upside down"
   }, 
   {
      id: 5073,
      word: "yoymoH",
      name: "yoymoH (v.) invert, turn upside-down, flip"
   }, 
   {
      id: 5074,
      word: "yoymoHwI'",
      name: "yoymoHwI' (n.) inverter"
   }, 
   {
      id: 5075,
      word: "yu",
      name: "yu (n.) first (and last) tone of nonatonic musical scale"
   }, 
   {
      id: 5076,
      word: "yu'",
      name: "yu' (v.) question, interrogate"
   }, 
   {
      id: 5077,
      word: "yu'egh",
      name: "yu'egh (n.) microwave (device)"
   }, 
   {
      id: 5078,
      word: "yu'egh",
      name: "yu'egh (n.) wave"
   }, 
   {
      id: 5079,
      word: "yu'egh mach",
      name: "yu'egh mach (n.) microwave (radiation)"
   }, 
   {
      id: 5080,
      word: "yu'muD",
      name: "yu'muD (n.) form (to be filled out)"
   }, 
   {
      id: 5081,
      word: "yuD",
      name: "yuD (v.) be dishonest"
   }, 
   {
      id: 5082,
      word: "yuDHa'",
      name: "yuDHa' (v.) be honest"
   }, 
   {
      id: 5083,
      word: "yuHSIQ",
      name: "yuHSIQ (n.) titanium"
   }, 
   {
      id: 5084,
      word: "yuQ",
      name: "yuQ (n.) planet"
   }, 
   {
      id: 5085,
      word: "yuQHom",
      name: "yuQHom (n.) planetoid"
   }, 
   {
      id: 5086,
      word: "yuQQeD",
      name: "yuQQeD (n.) geography"
   }, 
   {
      id: 5087,
      word: "yuQjIjDIvI'",
      name: "yuQjIjDIvI' (n.) United Federation of Planets"
   }, 
   {
      id: 5088,
      word: "yuQjIjQa'",
      name: "yuQjIjQa' (n.) United Federation of Planets"
   }, 
   {
      id: 5089,
      word: "yuQtej",
      name: "yuQtej (n.) geographer"
   }, 
   {
      id: 5090,
      word: "yub",
      name: "yub (n.) husk, rind, peel, shell (of fruit, nut)"
   }, 
   {
      id: 5091,
      word: "yuch",
      name: "yuch (n.) chocolate"
   }, 
   {
      id: 5092,
      word: "yugh",
      name: "yugh (v.) include, consist of, be composed of (in chemistry)"
   }, 
   {
      id: 5093,
      word: "yul",
      name: "yul (v.) be itchy"
   }, 
   {
      id: 5094,
      word: "yup",
      name: "yup (v.) pump"
   }, 
   {
      id: 5095,
      word: "yupma'",
      name: "yupma' (n.) festival"
   }, 
   {
      id: 5096,
      word: "yuq",
      name: "yuq (v.) outwit, outsmart"
   }, 
   {
      id: 5097,
      word: "yur",
      name: "yur (n.) distant cousin, niece or nephew (second cousin, grand-nephew, etc.)"
   }, 
   {
      id: 5098,
      word: "yuryum",
      name: "yuryum (n.) yurium (explosive)"
   }, 
   {
      id: 5099,
      word: "yut",
      name: "yut (v.) distract, create a diversion"
   }, 
   {
      id: 5100,
      word: "yutlhegh",
      name: "yutlhegh (n.) spectrum, musical scale, range"
   }, 
   {
      id: 5101,
      word: "yuv",
      name: "yuv (v.) push"
   }, 
   {
      id: 5102,
      word: "yuvtlhe'",
      name: "yuvtlhe' (n.) lid, cover, cap"
   }, 
   {
      id: 5103,
      word: "yuvwan",
      name: "yuvwan (n.) community"
   }, 
   {
      id: 5104,
      word: "yuwey",
      name: "yuwey (n.) continent"
   }, 
];